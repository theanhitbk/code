import React, { useState } from 'react';
import {View, Text, Image, Pressable} from 'react-native';
import {scale} from 'react-native-size-matters';
import {appColors} from '../utils/appColors';
import Label from './Label';
import {SimpleStepper} from 'react-native-simple-stepper';
import { currencyFormat } from '../utils/HelperFunctions';
import Feather from 'react-native-vector-icons/dist/Feather';
import { Checkbox } from 'react-native-paper';

export default function CheckOutItem({ 
  renderBagge, hideSteper,noBg, image, name, price,
  quantity, onUpdateToCart, onRemoveFromCart, item,
  toggleItem, selectedItems
}) {

  const _valueChanged = value => {
    if(value > 0) {
      var step = 1;
      if(quantity > value) {
        step = -1;
      }

      onUpdateToCart({...item, quantity: step}, step);
    }
  };

  return (
    <View
      style={{
        flexDirection: 'row',
        backgroundColor:  noBg ?  'transparent':   appColors.WHITE,
        borderColor: appColors.lightGray,
        borderTopWidth: 2,
        borderBottomWidth: 2,
        paddingVertical: scale(10),
        paddingHorizontal: scale(2)
        //borderRadius: scale(  5 )
      }}>
        <View style={{justifyContent: 'center'}}>
        <Checkbox
          status={selectedItems.includes(item.id) ? 'checked' : 'unchecked'}
          onPress={() => {toggleItem(item.id)}}
          style={{alignSelf: "center"}}
        />
        </View>
      <Image
        style={{
          height: scale(100),
          width: scale(100),
           borderRadius:  scale(noBg ? 5 : 0),
          //backgroundColor:appColors.darkGray
        }}
        source={{uri: image}}
      />

      <View
        style={{
          flex: 1,
          marginLeft: scale(10),
          justifyContent: 'space-between',
          paddingBottom: scale(10),
        }}>
        <Text numberOfLines={1} style={{fontSize: scale(14), fontWeight: '400', flexShrink: 1}}>{name}</Text>
        <Label
          text={currencyFormat(price) + ' đ'}
          style={{
            fontFamily: "UVNTinTucHepThemBold",
            fontSize: scale(20),
            fontWeight: '500',
            color: appColors.black,
            paddingVertical: scale(10)
          }}
        />

        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 1, justifyContent: 'flex-start'}}>
          {!hideSteper&& <SimpleStepper
            containerStyle={{
              backgroundColor: appColors.WHITE,
              flexDirection: 'row',
              borderColor: appColors.gray,
              borderWidth: 1,
              borderRadius: scale(5),
              overflow: 'hidden',
              alignItems: 'center',
              // paddingHorizontal: scale(20),
              height: scale(30), 
              width: scale(105)
            }}
            initialValue={quantity}
            minimumValue={1}
            incrementStepStyle={{padding: scale(7), opacity: scale(0.4), borderLeftWidth: 1, borderColor: appColors.gray}}
            decrementStepStyle={{padding: scale(7), opacity: scale(0.4), borderRightWidth: 1, borderColor: appColors.gray}}
            incrementImageStyle={{height: scale(20), width: scale(20)}}
            decrementImageStyle={{height: scale(20), width: scale(20)}}
            showText
            wraps={true}
            renderText={() => <Label text={quantity} style={{paddingHorizontal: scale(12)}}/>}
            separatorStyle={{}} 
            valueChanged={value => _valueChanged(value)}
          />}
          </View>
          <View style={{justifyContent: 'flex-end', alignSelf: 'center'}}>
            <Pressable onPress={() => onRemoveFromCart(item)}>
              <Feather name='trash' size={scale(20)}/>
            </Pressable>
          </View>
        </View>
        {renderBagge&&renderBagge()}
      </View>
    </View>
  );
}
