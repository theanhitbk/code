import React from 'react'
import { StyleSheet, Text, View,SafeAreaView, ImageBackground, Pressable, Image, TouchableOpacity } from 'react-native'
import { scale } from 'react-native-size-matters'
import Feather from 'react-native-vector-icons/dist/Feather'
import { appColors } from '../../utils/appColors'

export default function BookingHeader({children, title, isback, navigation}) {
    return (
        <SafeAreaView style={styles.container}>
            <View style={{
                textAlignVertical: 'center',
                height: scale(110),
                backgroundColor: '#f7f7f7',
                position: 'relative'
            }}>
                <ImageBackground
                source={require('../../static/images/header_bg.png')}
                resizeMode="stretch"
                style={styles.background}
                >
                    <View style={{
                        flex: 1,
                        alignItems: 'center',
                        justifyContent: 'center',
                        marginBottom: scale(10)
                    }}>
                        {isback && <View style={{flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', marginStart: scale(15)}}>
                                <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                                    <Feather name="chevron-left" size={scale(20)} color={appColors.WHITE} />
                                </TouchableOpacity>
                            </View>
                            <View style={{flex: 3, justifyContent: 'flex-start'}}>
                                <Text style={{
                                    fontFamily: 'Oswald-Bold',
                                    color: appColors.WHITE,
                                    fontSize: scale(20),
                                    fontWeight: '400',
                                }}>{title}</Text>
                            </View>
                        </View>
                        }
                        {!isback && 
                            <Text style={{
                                fontFamily: 'Oswald-Bold',
                                color: appColors.WHITE,
                                fontSize: scale(20),
                                fontWeight: '400',
                            }}>{title}</Text>
                        }
                        <View style={{
                            position: 'absolute',
                            right: scale(20),
                            }}>
                            <Pressable onPress={() => navigation.navigate('Home')}>
                                <Image
                                    source={require('../../static/images/icon-home.png')}
                                    style={{ height: 24, resizeMode: 'cover', width: 24 }}
                                />
                            </Pressable>
                        </View>
                    </View>
                </ImageBackground>
                <View style={{
                        flex: 1,
                        alignItems: 'center',
                        marginTop: scale(-16)
                    }}>
                    {children}
                </View>
            </View>
        </SafeAreaView>
    )
}
const styles = StyleSheet.create({
    container:{
        //flex:1,
        backgroundColor: appColors.WHITE
    },
    background: {
        height: scale(90),
        backgroundColor: '#f7f7f7',
    },
})