import { api } from './api';
import { USER_AUTH_INFO, USER_CHECK_PHONE, USER_LOGIN, USER_RESET_PASSWORD } from './config';

export const login = async (params) => {
    const result = await api.post(USER_LOGIN, params, {crossDomain : true});
    return result.data;
}

export const checkPhone = async (params) => {
    const result = await api.post(USER_CHECK_PHONE, params, {crossDomain : true});
    return result.data;
}

export const resetPassword = async (params) => {
    const result = await api.post(USER_RESET_PASSWORD, params, {crossDomain : true});
    return result.data;
}

export const fetchUserInfo = () => {
    return api.get(USER_AUTH_INFO);
}