import { api } from './api';
import { FEATURED_PRODUCTS_URL, GET_PRODUCT_URL, PRODUCTS_BY_CATEGORY, SEARCH_PRODUCTS_URL } from './config';

export const getProducts = async (params) => {
    const URL=`${PRODUCTS_BY_CATEGORY}/${params.category_id}`
    console.log('query params', URL)
    const result = await api.get(URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getProduct = async (params) => {
    const URL=`${GET_PRODUCT_URL}/${params}`
    try {
        const result = await api.get(URL, {params: params}, {crossDomain : true});
        return result.data.data;
    } catch(error) {
        console.log(error)
    }

    return null;
}

export const getFeaturedProducts = async (params) => {
    try {
        const result = await api.get(FEATURED_PRODUCTS_URL, {params: params}, {crossDomain : true});
        return result.data.data;
    } catch (error) {
        console.log(error)
    }

    return [];
}

export const searchProducts = async (params) => {
    const result = await api.get(SEARCH_PRODUCTS_URL, {params: params}, {crossDomain : true});
    return result.data.data;
}
