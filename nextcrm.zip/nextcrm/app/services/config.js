import {BASE_API_URL} from '../../app.json';

export const USER_TOKEN = 'USER_TOKEN';
export const DEVICE_STORAGE_KEY = 'DEVICE_STORAGE_KEY';

export const HOME_URL = `${BASE_API_URL}getBannerImage`

export const CATEGORIES_URL=`${BASE_API_URL}categories`
export const HOT_CATEGORIES_URL=`${BASE_API_URL}categoryHot`
export const PRODUCTS_BY_CATEGORY=`${BASE_API_URL}productInCategory`
export const GET_PRODUCT_URL=`${BASE_API_URL}products`
export const FEATURED_PRODUCTS_URL=`${BASE_API_URL}productsHot`
export const SEARCH_PRODUCTS_URL=`${BASE_API_URL}searchProduct`
export const USER_CHECK_PHONE=`${BASE_API_URL}auth/checkPhone`
export const USER_RESET_PASSWORD=`${BASE_API_URL}auth/resetPassword`
export const USER_LOGIN=`${BASE_API_URL}auth/login`
export const USER_AUTH_INFO=`${BASE_API_URL}member/{id}`
export const USER_REGISTER=`${BASE_API_URL}auth/create`
export const USER_HRM_ATTENDACES=`${BASE_API_URL}hrm/attendances`

// Order 
export const ADD_ORDER_URL=`${BASE_API_URL}auth/user/addOrder`
export const GET_ORDERS_URL=`${BASE_API_URL}auth/user/orders`
export const GET_ORDER_URL=`${BASE_API_URL}auth/orders/`

// Shipping
export const GET_CITIES_URL=`${BASE_API_URL}province`
export const GET_DISTRICTS_URL=`${BASE_API_URL}district`
export const GET_COMMUNES_URL=`${BASE_API_URL}commune`
export const SHIPPING_URL=`${BASE_API_URL}shippingMethod`
export const SHIPPING_ADDRESS_URL=`${BASE_API_URL}auth/user/address`
export const ADD_ADDRESS_URL=`${BASE_API_URL}auth/user/newAddress`
export const UPDATE_ADDRESS_URL=`${BASE_API_URL}auth/user/saveAddress`
export const REMOVE_ADDRESS_URL=`${BASE_API_URL}auth/user/deleteAddress`
export const GET_ADDRESS_URL=`${BASE_API_URL}auth/user/editAddress/`

// Booking URL
export const CONTRACT_LIST_URL=`${BASE_API_URL}auth/book/member_order`
export const BRANCH_LIST_URL=`${BASE_API_URL}auth/book/member_branch`
export const BOOKING_LIST_URL=`${BASE_API_URL}mobile/member-booking-pt`
export const PT_LIST_URL=`${BASE_API_URL}auth/book/list_pt`
export const SCHEDULE_LIST_URL=`${BASE_API_URL}auth/book/scheduler_pt`


export const GET_BOOKS_URL=`${BASE_API_URL}auth/book/member_booking_pt`
export const BOOK_ADD_URL=`${BASE_API_URL}auth/book/add_booking_pt`
export const BOOK_UPDATE_URL=`${BASE_API_URL}auth/book/edit_booking_pt/`
export const BOOK_DELETE_URL=`${BASE_API_URL}auth/book/delete_booking_pt/`
export const BOOK_INFO_URL=`${BASE_API_URL}auth/book/booking_pt/`

//CMS
export const CMS_CATEGORIES_URL=`${BASE_API_URL}cmsCategory`
export const CMS_CATEGORY_URL=`${BASE_API_URL}detailCmsCategory/`
export const CMS_POST_URL=`${BASE_API_URL}detailPostCmsCategory/`