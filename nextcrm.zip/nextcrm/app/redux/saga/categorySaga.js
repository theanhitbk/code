import { call, put, takeLatest } from 'redux-saga/effects'
import { GET_CATEGORIES,GET_CMS_CATEGORIES,GET_POSTS_CATEGORY,GET_DETAIL_POST_CATEGORY,GET_HOT_CATEGORIES,SET_CATEGORIES, SET_CMS_CATEGORIES, SET_POSTS_CATEGORY, SET_DETAIL_POST_CATEGORY, SET_HOT_CATEGORIES } from '../categoryAction'
import * as catApis from '../../services/categoryApis';
 
export function* workerGetCategories(action) {
  try {
    const result = yield call(catApis.getCategories, action.params)
    yield put({type: SET_CATEGORIES, payload: result.data})
  } catch(error) {
    yield put({type: SET_CATEGORIES, payload: []})
  }
  
}
export function* watcherGetCategories() {
  yield takeLatest(GET_CATEGORIES, workerGetCategories)
}

export function* workerGetHotCategories(action) {
  try {
    const result = yield call(catApis.getHotCategories, action.params)
    yield put({type: SET_HOT_CATEGORIES, payload: result.data})
  } catch (error) {
    console.log(error)
    yield put({type: SET_HOT_CATEGORIES, payload: []})
  }
  
}
export function* watcherGetHotCategories() {
  yield takeLatest(GET_HOT_CATEGORIES, workerGetHotCategories)
}

export function* workerGetCmsCategories(action) {
  try {
    const result = yield call(catApis.getCmsCategories, action.params)
    yield put({type: SET_CMS_CATEGORIES, payload: result.data.cmsCategory})
  } catch(error) {
    yield put({type: SET_CMS_CATEGORIES, payload: []})
  }
  
}
export function* watcherGetCmsCategories() {
  yield takeLatest(GET_CMS_CATEGORIES, workerGetCmsCategories)
}

export function* workerGetCmsCategory(action) {
  try {
    const result = yield call(catApis.getCmsCategory, action.params)
    yield put({type: SET_POSTS_CATEGORY, payload: result.data.posts})
  } catch(error) {
    yield put({type: SET_POSTS_CATEGORY, payload: []})
  }
  
}
export function* watcherGetCmsCategory() {
  yield takeLatest(GET_POSTS_CATEGORY, workerGetCmsCategory)
}

export function* workerGetCmsPost(action) {
  try {
    const result = yield call(catApis.getCmsPost, action.params)
    yield put({type: SET_DETAIL_POST_CATEGORY, payload: result.data.postDetail})
  } catch(error) {
    yield put({type: SET_DETAIL_POST_CATEGORY, payload: null})
  }
  
}
export function* watcherGetCmsPost() {
  yield takeLatest(GET_DETAIL_POST_CATEGORY, workerGetCmsPost)
}