import { put, call, fork, takeLatest } from 'redux-saga/effects';
import * as types from '../actionTypes';
import * as bookApis from '../../services/bookApis';
import { logout } from '../loginAction';

export function* workerGetBooks(action) {
  try {
      const result = yield call(bookApis.getMemberBooks, action.params) 
      yield put({ type: types.SET_BOOKS, payload: result.data })
  } catch(error) {
    yield put({ type: types.SET_BOOKS, payload: [] })
  }
}
export function* watcherGetBooks() {
  yield takeLatest(types.GET_BOOKS,workerGetBooks)
}

export function* workerGetMemberBranchs(action) {
  try {
    const result = yield call(bookApis.getMemberBranchs, action.params)
    yield put({type: types.SET_MEMBER_BRANCH, payload: result.data})
  } catch (error) {
    yield put({type: types.SET_MEMBER_BRANCH, payload: []})
  }
}

export function* watcherGetMemberBranchs() {
  yield takeLatest(types.GET_MEMBER_BRANCH, workerGetMemberBranchs)
}

export function* workerGetMemberOrders(action) {
  try {
    const result = yield call(bookApis.getMemberOrders, action.params)
    yield put({type: types.SET_MEMBER_ORDER, payload: result.data})
  } catch (error) {
    yield put({type: types.SET_MEMBER_ORDER, payload: []})
  }
}

export function* watcherGetMemberOrders() {
  yield takeLatest(types.GET_MEMBER_ORDER, workerGetMemberOrders)
}

export function* workerGetPTList(action) {
  try {
    const result = yield call(bookApis.getPTList, action.params)
    action.onSuccess(result);
    yield put({type: types.SET_PT_LIST, payload: result})
  } catch (error) {
    yield put({type: types.SET_PT_LIST, payload: []})
  }
}

export function* watcherGetPTList() {
  yield takeLatest(types.GET_PT_LIST, workerGetPTList)
}

export function* workerGetPTSchedules(action) {
  try {
    const result = yield call(bookApis.getPTSchedules, action.params)
    console.log('schedule::', result.data, action.params)
    if(result.meta.status_code === 0) {
      action.onSuccess(result.data)
    } else {
      action.onError(result.meta.message)    
    }
    yield put({type: types.SET_PT_SCHEDULES, payload: result.data})
  } catch (error) {
    action.onError(error)
  }
}

export function* watcherGetPTSchedules() {
  yield takeLatest(types.GET_PT_SCHEDULES, workerGetPTSchedules)
}

export function* addBooking(action) {
  try {
      const result = yield call(bookApis.addBooking, action.params)
      console.log(action.params, result);
      if(result.meta.status_code === 0) {
          action.onSuccess(result)
      } else {
          action.onError(result)    
      }
  } catch (error) {
      action.onError(error)
  }
}

export function* watcherBooking() {
  yield takeLatest(types.ADD_BOOK, addBooking)
}

export function* updateBooking(action) {
  try {
      const result = yield call(bookApis.updateBooking, action.params)
      if(result.meta.status_code === 0) {
          action.onSuccess(result)
      } else {
          action.onError(result)    
      }
  } catch (error) {
      action.onError(error)
  }
}

export function* watcherUpdateBooking() {
  yield takeLatest(types.EDIT_BOOK, updateBooking)
}

export function* workerGetBook(action) {
  try {
    const result = yield call(bookApis.getBooking, action.params)
    yield put({type: types.SET_BOOK, payload: result.data})
  } catch (error) {
    yield put({type: types.SET_BOOK, payload: null})
  }
}

export function* watcherGetBook() {
  yield takeLatest(types.GET_BOOK, workerGetBook)
}

export function* resetOldBook () {  
  yield takeLatest(types.RESET_BOOK)
}

export function* removeBooking(action) {
  try {
      const result = yield call(bookApis.removeBooking, action.params)
      if(result.meta.status_code === 0) {
          action.onSuccess(result)
      } else {
          action.onError(result)    
      }
  } catch (error) {
      action.onError(error)
  }
}

export function* watcherRemoveBooking() {
  yield takeLatest(types.REMOVE_BOOK, removeBooking)
}