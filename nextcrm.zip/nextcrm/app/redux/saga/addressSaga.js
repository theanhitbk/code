import { call, put, takeLatest } from 'redux-saga/effects'
import * as shipApis from '../../services/shippingApis';
import { GET_CITIES, GET_COMMUNES, GET_DISTRICTS, SET_CITIES, SET_COMMUNES, SET_DISTRICTS } from '../addressAction';
 
export function* workerGetCities(action) {
  try {
    const result = yield call(shipApis.getCities, action.params)
    yield put({type: SET_CITIES, payload: result.data})
  } catch (error) {
    console.log(error);
    yield put({type: SET_CITIES, payload: []})
  }
  
}
export function* watcherGetCities() {
  yield takeLatest(GET_CITIES, workerGetCities)
}

export function* workerGetDistricts(action) {
  try {
    const result = yield call(shipApis.getDistricts, action.params)
    yield put({type: SET_DISTRICTS, payload: result.data})
  } catch (error) {
    console.log(error);
    yield put({type: SET_DISTRICTS, payload: []})
  }
  
}
export function* watcherGetDistricts() {
  yield takeLatest(GET_DISTRICTS, workerGetDistricts)
}

export function* workerGetCommunes(action) {
  try {
    const result = yield call(shipApis.getCommunes, action.params)
    yield put({type: SET_COMMUNES, payload: result.data})
  } catch (error) {
    console.log(error);
    yield put({type: SET_COMMUNES, payload: []})
  }
  
}
export function* watcherGetCommunes() {
  yield takeLatest(GET_COMMUNES, workerGetCommunes)
}
