import { put, call, fork, takeLatest } from 'redux-saga/effects';
import * as homeApis from '../../services/homeApis';
import { SET_HOMES, GET_HOMES } from '../homeAction';

export function* workerGetHomeDatas(action) {
  try {
      const result = yield call(homeApis.getHomeData, action.params)
      yield put({ type:SET_HOMES, payload: result.data })
  } catch(error) {
    yield put({ type:SET_HOMES, payload: [] })
  }
}

export function* watcherGetHomeDatas() {
  yield takeLatest(GET_HOMES, workerGetHomeDatas)
}