export const GET_SHIPPING = "GET_SHIPPING" // ACTION TYPE 
export const SET_SHIPPING = 'SET_SHIPPING'
export const ADD_SHIPPING_ADDRESS = 'ADD_SHIPPING_ADDRESS'
export const GET_SHIPPING_ADDRESS = 'GET_SHIPPING_ADDRESS'
export const SET_SHIPPING_ADDRESS = 'SET_SHIPPING_ADDRESS'

export const getShippingMethod = ()=>({
    type: GET_SHIPPING,
}) 

export const getShippingAddress = () => ({
    type: GET_SHIPPING_ADDRESS
})

export const addShippingAddress = (data, onSuccess, onError) => ({
    type: ADD_SHIPPING_ADDRESS,
    params: data,
    onSuccess,
    onError
})