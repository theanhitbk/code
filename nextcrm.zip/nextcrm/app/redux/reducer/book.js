import * as types from '../actionTypes';

const intialState = {
    books :[],
    book: {},
    branchList: [],
    orderList: [],
    ptList: [],
    ptSchedules: [],
}

export default (state = intialState, action) => {
    const {type,payload} =action
    switch (type) {
        case types.GET_BOOKS:
            return {
                ...state,
            };
        case types.SET_BOOKS:
            return {
                ...state,
                books : [...payload]
            };
        case types.SET_MEMBER_BRANCH:
            return {
                ...state,
                branchList : [...payload]
            };
        case types.SET_MEMBER_ORDER:
            return {
                ...state,
                orderList : [...payload]
            };
        case types.SET_PT_LIST:
        //case types.GET_PT_LIST:
            return {
                ...state,
                ptList : [...payload]
            };
        case types.SET_PT_SCHEDULES:
            return {
                ...state,
                ptSchedules : [...payload]
            };
        case types.SET_BOOK:
            return {
                ...state,
                book: {...payload}
            };
        case types.REMOVE_BOOK:
            return {
                ...state,
                book: {}
            };
        case types.RESET_BOOK:
            return {
                ...state,
                books :[],
                book: {},
                branchList: [],
                orderList: [],
                ptList: [],
                ptSchedules: [],
            };
        default:
            return state;
    }
};