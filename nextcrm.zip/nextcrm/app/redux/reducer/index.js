import {combineReducers} from 'redux';
import cart from './cart';
import error from './error';
import products from './products';
import login from './login';
import book from './book';
import home from './home';
import categories from './categories';
import shippings from './shippings';
import orders from './orders';
import address from './address';

export default combineReducers({
  error,
  home,
  login,
  cart,
  book,
  products,
  categories,
  shippings,
  orders,
  address
});
