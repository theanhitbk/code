import { GET_DISTRICTS, SET_CITIES, SET_COMMUNES, SET_DISTRICTS } from "../addressAction";

const intialState = {
    cities :[],
    districts: [],
    loadingDist: false,
    communes: []
}

export default (state = intialState, action) => {
    const {type,payload} =action
    switch (type) {
        case SET_CITIES: 
            let cityList = [];
            payload.forEach(c => {
                cityList.push({value: c.matp, label: c.name})
            })
            return {
                ...state,
                cities : cityList
            };
        case GET_DISTRICTS:
            return {
                ...state,
                loadingDist: true
            }
        case SET_DISTRICTS: 
            let dists = [];
            payload.forEach(d => {
                dists.push({value: d.maqh, label: d.name});
            })
            return {
                ...state,
                districts : dists,
                loadingDist: false
            };
        case SET_COMMUNES: 
            let comm = [];
            payload.forEach(d => {
                comm.push({value: d.xaid, label: d.name});
            })
            return {
                ...state,
                communes : comm
            };
        default:
            return state;
    }
};