export const GET_PTS="GET_PTS"
export const SET_PTS="SET_PTS"

export const GET_PT="GET_PT"
export const SET_PT="SET_PT"

export const getPts = (branchId)=>({
    type: GET_PTS,
    payload: branchId
}) 

export const getPt = (id) => ({
    type: GET_PT,
    payload: id
})
