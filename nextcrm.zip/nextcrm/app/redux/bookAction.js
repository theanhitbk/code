import * as types from './actionTypes';

export const addBook = (book) => ({
    type: types.ADD_BOOK,
    payload: book
})

export const getBooks = ()=>({
    type: types.GET_BOOKS,
}) 

export const getBook = (id) => ({
    type: types.GET_BOOK,
    payload: id,
    params: {id: id}
})

export const getMemberBranchs = () => ({
    type: types.GET_MEMBER_BRANCH
})

export const getMemberOrders = () => ({
    type: types.GET_MEMBER_ORDER,
})

export const setMemberBranchs = (data) => ({
    type: types.SET_MEMBER_BRANCH,
    payload: data
})

export const setMemberOrders = (data) => ({
    type: types.SET_MEMBER_ORDER,
    payload: data
})

export const setPTList = (data) => ({
    type: types.SET_PT_LIST,
    payload: data
})

export const getPTList = (id, onSuccess) => ({
    type: types.GET_PT_LIST,
    payload: id,
    params: {order_id: id},
    onSuccess
})

export const setPTSchedules = (data) => ({
    type: types.SET_PT_SCHEDULES,
    payload: data
})

export const getPTSchedules = (data, onSuccess, onError) => ({
    type: types.GET_PT_SCHEDULES,
    params: data,
    onSuccess,
    onError
})

export const addBooking = (params, onSuccess, onError) => ({
    type: types.ADD_BOOK,
    params,
    onSuccess,
    onError
})

export const updateBooking = (params, onSuccess, onError) => ({
    type: types.EDIT_BOOK,
    params,
    onSuccess,
    onError
})

export const removeBooking = (params, onSuccess, onError) => ({
    type: types.REMOVE_BOOK,
    params,
    onSuccess,
    onError
})

export const resetOldBook = () => ({
    type: types.RESET_BOOK
})