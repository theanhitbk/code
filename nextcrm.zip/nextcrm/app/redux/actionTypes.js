// you can add your action type here
export const SET_ERROR="SET_ERROR"
export const SET_ERROR_SUCCESS="SET_ERROR_SUCCESS"
export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const CHECK_PHONE = 'CHECK_PHONE'
export const LOGIN_REQUESTING = 'LOGIN_REQUESTING'
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_ERROR = 'LOGIN_ERROR'
export const RESET_PASSWORD = 'RESET_PASSWORD'
export const SET_USER_INFO = 'SET_USET_INFO'
export const FETCH_USER_INFO = 'FETCH_USER_INFO'

// books
export const FETCH_MEMBER_BRANCH = 'FETCH_MEMBER_BRANCH'
export const FETCH_MEMBER_ORDER = 'FETCH_MEMBER_ORDER'

export const GET_BOOKS="GET_BOOKS"
export const SET_BOOKS="SET_BOOKS"

export const GET_BOOK="GET_BOOK"
export const SET_BOOK="SET_BOOK"
export const ADD_BOOK = "ADD_BOOK"
export const EDIT_BOOK="EDIT_BOOK"
export const REMOVE_BOOK = "REMOVE_BOOK"
export const RESET_BOOK = "RESET_BOOK"

export const GET_MEMBER_BRANCH = 'GET_MEMBER_BRANCH';
export const GET_MEMBER_ORDER = 'GET_MEMBER_ORDER';
export const SET_MEMBER_BRANCH = 'SET_MEMBER_BRANCH';
export const SET_MEMBER_ORDER = 'SET_MEMBER_ORDER';
export const SET_PT_LIST = 'SET_PT_LIST';
export const GET_PT_LIST = 'GET_PT_LIST';
export const SET_PT_SCHEDULES = 'SET_PT_SCHEDULES';
export const GET_PT_SCHEDULES = 'GET_PT_SCHEDULES';