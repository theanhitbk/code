export const GET_HOMES="GET_HOMES"
export const SET_HOMES="SET_HOMES"

export const getHomeDatas = () => ({
    type: GET_HOMES
})
