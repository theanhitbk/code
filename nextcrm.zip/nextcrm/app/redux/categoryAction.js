export const GET_CATEGORIES="GET_CATEGORIES"
export const SET_CATEGORIES="SET_CATEGORIES"
export const GET_HOT_CATEGORIES="GET_HOT_CATEGORIES"
export const SET_HOT_CATEGORIES="SET_HOT_CATEGORIES"

export const GET_CMS_CATEGORIES="GET_CMS_CATEGORIES"
export const SET_CMS_CATEGORIES="SET_CMS_CATEGORIES"

export const GET_POSTS_CATEGORY="GET_POSTS_CATEGORY"
export const SET_POSTS_CATEGORY="SET_POSTS_CATEGORY"

export const GET_DETAIL_POST_CATEGORY="GET_DETAIL_POST_CATEGORY"
export const SET_DETAIL_POST_CATEGORY="SET_DETAIL_POST_CATEGORY"

export const getCategories = ()=>({
    type: GET_CATEGORIES,
}) 

export const getHotCategories = ()=>({
    type: GET_HOT_CATEGORIES,
}) 


export const getCmsCategories = ()=>({
    type: GET_CMS_CATEGORIES,
}) 

export const getDetailCategory = (id)=>({
    type: GET_POSTS_CATEGORY,
    params: {id: id}
}) 

export const getDetailPostCategory = (id)=>({
    type: GET_DETAIL_POST_CATEGORY,
    params: {id: id}
}) 
