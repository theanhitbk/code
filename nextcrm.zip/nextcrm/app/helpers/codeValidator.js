export function codeValidator(name) {
    if (!name) return "Mã khách hàng không được để trống !"
    return ''
}