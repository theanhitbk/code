export function mobileValidator(mobile) {
    if (!mobile) return "Số điện thoại không được để trống."
    return ''
  }