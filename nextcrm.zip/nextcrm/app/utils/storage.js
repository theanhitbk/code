import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEVICE_STORAGE_KEY, USER_TOKEN } from '../services/config';

export const setData = async (key, value) => {
  try {
    await AsyncStorage.setItem(`@${key}:key`, `${value}`);
    return true;
  } catch (error) {
    return false;
  }
};

export const getData = async (key) => {
  try {
    const value = await AsyncStorage.getItem(`@${key}:key`);
    if (value !== null) {
      return value;
    }
    return '';
  } catch (error) {
    return '';
  }
};

export const saveToken = async (value) => {
  try {
    await AsyncStorage.setItem(`@${USER_TOKEN}:key`, `${value}`);
    return true;
  } catch (error) {
    return false;
  }
};

export const clearToken = async () => saveToken('');

export const clearAll = async () => await AsyncStorage.clear();

export const getToken = async () => {
  try {
    const value = await AsyncStorage.getItem(`@${USER_TOKEN}:key`);
    if (value !== null) {
      return value;
    }
    return '';
  } catch (error) {
    return '';
  }
};

export const saveDeviceToken = async (value) => {
  try {
    await AsyncStorage.setItem(`@${DEVICE_STORAGE_KEY}:key`, `${value}`);
    return true;
  } catch (error) {
    return false;
  }
};

export const clearDeviceToken = async () => saveDeviceToken('');

export const getDeviceToken = async () => {
  try {
    const value = await AsyncStorage.getItem(`@${DEVICE_STORAGE_KEY}:key`);
    if (value !== null) {
      return value;
    }
    return '';
  } catch (error) {
    return '';
  }
};