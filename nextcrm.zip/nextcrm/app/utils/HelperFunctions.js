import {Platform, Dimensions} from 'react-native';

const Screen = Dimensions.get('window');
export const SCREEN_WIDTH = Screen.width;
export const SCREEN_HEIGHT = Screen.height;
export const isIOS = Platform.OS === 'ios';
export const isAndroid = Platform.OS === 'android';
export const isMWeb = Platform.OS === 'web';

export const logErrorWithMessage = (message, errorSource) => {
  if (__DEV__) {
    console.log(message, errorSource);
  }
};

export const dateFormat = (date) => {
  const dateObj = new Date(date);
    const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
    // const monthNames = ["January", "February", "March", "April", "May", "June",
    //   "July", "August", "September", "October", "November", "December"];
    const monthNames = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    const month = monthNames[dateObj.getMonth()];
    const dayName = days[dateObj.getDay()];
    const day = String(dateObj.getDate()).padStart(2, '0');
    const year = dateObj.getFullYear();
    const output = 'Hôm nay, ' + dayName + '(' + day  + '/'+ month +')';//  + '/' + year + ')';
    return output;
};

export const dateStringFormat = (date) => {
  const dateObj = new Date(date);
    const fullDays = ['Chủ nhật', 'Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'];
    const monthNames = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    const month = monthNames[dateObj.getMonth()];
    const dayName = fullDays[dateObj.getDay()];
    const day = String(dateObj.getDate()).padStart(2, '0');
    let prefix = '';
    const curr = new Date();
    const n = String(curr.getDate()).padStart(2, '0');
    
    if(n == day ) {
      prefix = ' Hôm nay, ';
    }

    if(n + 1 == day ) {
      prefix = ' Ngày mai, ';
    }

    if(n + 2 == day ) {
      prefix = ' Ngày kia, ';
    }
    const output = prefix + dayName + ', ' + day  + '/'+ month +'';//  + '/' + year + ')';
    return output;
};

export const getListDate = () => {
  const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
  const curr = new Date();
  const n = curr.getDay();
  const first = curr.getDate();// - curr.getDay(); // First day is the day of the month - the day of the week
  const last = first + 5; // last day is the first day + 6
  const listDays = [];
  let name = 'Hôm nay,' + days[n] + '(' + curr.getDate() + '/' + (curr.getMonth() + 1) + ')';
  listDays.push({name: name, value: curr, is_weekend: [0,6].includes(n)});

  let cloned = new Date();
  let dd = new Date(cloned.setDate(cloned.getDate() + 1));
  name = 'Ngày mai,' + days[dd.getDay()] + '(' + dd.getDate() + '/' + (dd.getMonth() + 1) + ')'
  listDays.push({name: name, value: dd, is_weekend: [0,6].includes(dd.getDay())});

  let clon = new Date();
  let ddd = new Date(clon.setDate(clon.getDate() + 2));
  name = 'Ngày kia,' + days[ddd.getDay()] + '(' + ddd.getDate() + '/' + (ddd.getMonth() + 1) + ')';
  listDays.push({name: name, value: ddd, is_weekend: [0,6].includes(ddd.getDay())});

  let clon1 = new Date();
  let ddd1 = new Date(clon1.setDate(ddd.getDate() + 1));
  name = days[ddd1.getDay()] + '(' + ddd1.getDate() + '/' + (ddd1.getMonth() + 1) + ')';
  listDays.push({name: name, value: ddd1, is_weekend: [0,6].includes(ddd1.getDay())});

  let clon2 = new Date();
  let ddd2 = new Date(clon.setDate(ddd.getDate() + 2));
  name = days[ddd2.getDay()] + '(' + ddd2.getDate() + '/' + (ddd2.getMonth() + 1) + ')';
  listDays.push({name: name, value: ddd2, is_weekend: [0,6].includes(ddd2.getDay())});

  let clon3 = new Date();
  let ddd3 = new Date(clon3.setDate(ddd.getDate() + 3));
  name = days[ddd3.getDay()] + '(' + ddd3.getDate() + '/' + (ddd3.getMonth() + 1) + ')';
  listDays.push({name: name, value: ddd3, is_weekend: [0,6].includes(ddd3.getDay())});

// console.log(ddd.getDate())
//   for(var i = ddd.getDate() + 1; i <= last; i++) {
//     let dd = new Date(ddd.setDate(i));
//     let name = days[dd.getDay()] + '(' + dd.getDate() + '/' + (dd.getMonth() + 1) + ')';
//     listDays.push({name: name, value: dd, is_weekend: [0,6].includes(dd.getDay())});
//   }

  return listDays;
};

export const currencyFormat = (value) => {
  const output = value.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1.').slice(0, -3);
  return output;
};

export const isRealValue = (obj) => {
 return obj && obj !== 'null' && obj !== 'undefined';
}