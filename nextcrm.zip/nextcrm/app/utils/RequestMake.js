export default async (url,options)=>{
   const result = await fetch(url,options).then(response=> response.json())
   return result
}