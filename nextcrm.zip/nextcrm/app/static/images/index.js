export const backIcon = require('./back_arrow_icon.png');
export const closeIcon = require('./close_icon.png');
export const menuIcon = require('./menu_black.png');
export const crossIcon = require('./cross_icon.png');
export const searchIcon = require('./search_icon.png');
export const whiteMenuIcon = require('./menu.png');