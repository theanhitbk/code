import React, { useCallback, useEffect, useState } from 'react';
import { Image, ImageBackground, Linking, Pressable, StyleSheet, Text, View } from "react-native";
import { ScrollView } from 'react-native-gesture-handler';
import { SafeAreaView } from 'react-native-safe-area-context';
import { scale } from 'react-native-size-matters';
import { connect } from 'react-redux';
import { getBook, removeBooking } from '../../redux/bookAction';
import { appColors } from "../../utils/appColors";
import Feather from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import { dateFormat, dateStringFormat } from '../../utils/HelperFunctions';

function BookResultScreen({userInfo, book, config, getBook$, removeBooking$, route:{params}, navigation}) {

    useEffect(() => {
        getBook$(params.item.id)
    }, []);

    const onSuccess = (result) => {
        navigation.goBack()
    };

    const onError = (error) => {
        navigation.goBack()
    };

    if(Object.keys(book).length !== 0) {
        return (
            <>
                <SafeAreaView style={styles.container}>
                <View style={{
                    textAlignVertical: 'center',
                    height: scale(110),
                    backgroundColor: '#f7f7f7',
                    position: 'relative'
                }}>
                    <ImageBackground
                    source={require('../../static/images/header_bg.png')}
                    resizeMode="stretch"
                    style={styles.background}
                    >
                        <View style={{
                            flex: 1,
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginBottom: scale(10)
                        }}>
                            <Text style={{
                                color: appColors.WHITE,
                                fontSize: scale(20),
                                fontWeight: '400',
                            }}>{book.branch_name}</Text>
                            <View style={{
                                position: 'absolute',
                                right: scale(20),
                                }}>
                                <Pressable onPress={() => navigation.navigate('Home')}>
                                    <Image
                                        source={require('../../static/images/icon-home.png')}
                                        style={{ height: 24, resizeMode: 'cover', width: 24 }}
                                    />
                                </Pressable>
                            </View>
                        </View>
                    </ImageBackground>
                </View>
                <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled>
                    <View style={{
                            flex: 1,
                            // alignItems: 'center',
                            marginHorizontal: scale(10),
                            justifyContent: 'flex-start'
                        }}>
                        <View style={{flex: 1, flexDirection: 'row'}}>
                            <Text style={{
                                color: appColors.ORANGE, fontSize: scale(28),
                                fontWeight: 'bold',
                            }}>Đặt lịch thành công</Text>
                            <Image
                                source={require('../../static/images/loa.png')}
                                style={{ height: 45, resizeMode: 'stretch', width: 45, marginHorizontal: scale(10) }}
                            />
                            <Text style={{
                                borderBottomColor: appColors.lightGray,
                                borderBottomWidth: scale(1),
                            }}></Text>
                        </View>
                        <View style={{marginVertical: scale(30)}}>
                            <View style={{
                                borderBottomColor: appColors.lightGray,
                                borderBottomWidth: scale(1),
                                paddingBottom: scale(20)
                            }}>
                                <View style={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    paddingBottom: scale(20)
                                }}>
                                    <Image source={{uri: book.branch_avatar}} 
                                        style={{
                                            width: scale(160),
                                            height: scale(120)
                                        }}
                                    />
                                    <View style={{
                                        flexShrink: 1,
                                        marginLeft: scale(5)
                                    }}>
                                        <Text style={{
                                            fontFamily: 'OpenSans-Bold',
                                            color: appColors.black, 
                                            fontSize: scale(16),
                                        }}>{book.branch_address}</Text>
                                        <Text style={{
                                            fontFamily: 'OpenSans-Regular',
                                            color: appColors.darkGray,
                                            fontSize: scale(14),
                                            paddingVertical: scale(0)
                                        }}>{book.description}</Text>
                                    </View>
                                </View>
                                <View style={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-around',
                                    alignItems: 'center',
                                    paddingBottom: scale(20)
                                }}>
                                    <Pressable onPress={() => {Linking.openURL(`https://maps.google.com/?q=${book.branch_address}`);}}
                                    style={{
                                        flexDirection: 'row',
                                        borderColor: appColors.darkGray,
                                        borderWidth: 1,
                                        borderRadius: scale(7),
                                        paddingHorizontal: scale(10),
                                        paddingVertical: scale(6),
                                        alignItems: 'center'
                                    }}
                                    >
                                        <Feather name='map-pin' size={20} />
                                        <Text style={{
                                            paddingLeft: scale(7),
                                            fontFamily: 'OpenSans-Bold',
                                            fontSize: scale(14)
                                        }}>Chỉ đường</Text>
                                    </Pressable>
                                    <Pressable onPress={() => {Linking.openURL(`tel:${config.phoneNumber}`);}}
                                    style={{
                                        flexDirection: 'row',
                                        borderColor: appColors.darkGray,
                                        borderWidth: 1,
                                        borderRadius: scale(7),
                                        paddingHorizontal: scale(10),
                                        paddingVertical: scale(6),
                                        alignItems: 'center'
                                    }}
                                    >
                                        <Feather name='phone' size={20} />
                                        <Text style={{
                                            paddingLeft: scale(7),
                                            fontFamily: 'OpenSans-Bold',
                                            fontSize: scale(14)
                                        }}>Gọi điện</Text>
                                    </Pressable>
                                </View>
                            </View>

                            <View style={{
                                color: appColors.black,
                                paddingVertical: scale(15)
                            }}>
                                <Text style={{
                                    flexDirection: 'row', 
                                    fontSize: scale(14),
                                }}>
                                    <Text style={{fontFamily: 'OpenSans-Regular'}}>Hẹn gặp {userInfo.sex === 0 ? 'chị' : 'anh'} {userInfo.name} </Text>
                                    (<Text style={{fontFamily: 'OpenSans-Bold', color: '#FE6600'}}>{userInfo.phone}</Text>) vào lúc:
                                </Text>
                                <Text style={{
                                    flexDirection: 'row', 
                                    fontFamily: 'OpenSans-Bold', 
                                    color: '#FE6600',
                                    fontSize: scale(14),
                                    paddingVertical: scale(5)
                                }}>{book.date_time.substring(11, 16)} {dateStringFormat(book.date_time.substring(0, 10))}</Text>
                            </View>
                        </View>
                        <View style={{
                            borderTopColor: appColors.lightGray,
                            borderTopWidth: scale(10),
                            borderBottomColor: appColors.lightGray,
                            borderBottomWidth: scale(10),
                            paddingVertical: scale(10)
                        }}>
                            <View style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between'
                            }}>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{
                                        color: appColors.black, fontSize: scale(18),
                                        fontWeight: 'bold',
                                    }}>{book.pt_name}</Text>
                                    <Text style={{
                                        color: appColors.darkGray,
                                        fontSize: scale(14),
                                    }}>{book.description}</Text>
                                </View>
                                <Image source={{uri: book.pt_avatar}} style={{
                                    width: 100,
                                    height: 100,
                                    borderRadius: scale(50)
                                }}/>
                            </View>
                        </View>
                        <View style={{
                        }}>
                            <Text style={{
                                color: appColors.black, fontSize: scale(18),
                                fontWeight: 'bold',
                                paddingVertical: scale(10)
                            }}>Hướng dẫn huỷ / đổi lịch</Text>
                            <Text style={{
                                color: appColors.darkGray,
                                fontSize: scale(14),
                                paddingBottom: scale(20)
                            }}>Nếu anh/chị đến muộn quá 10 phút chúng em sẽ rời lịch đặt sang khung giờ sau để anh/chị có thời gian trải nghiệm thoải mái hơn</Text>
                        </View>
                        <View style={styles.descriptionContainer}>
                            <Feather name='refresh-ccw' size={scale(20)} color={appColors.black}
                                style={{alignSelf: 'center', fontWeight: 'bold'}}
                            />
                            <Text numberOfLines={1} style={styles.textDescription}>Đổi lịch</Text>
                            <Ionicons name="caret-forward-outline" size={scale(20)} color={appColors.black}
                                style={{alignSelf: 'center'}}
                            />
                        </View>
                        <Pressable onPress={() => removeBooking$({id: book.id}, onSuccess, onError)}>
                            <View style={styles.descriptionContainer}>
                                <Feather name='x-circle' size={scale(20)} color={appColors.black}
                                    style={{alignSelf: 'center', fontWeight: 'bold'}}
                                />
                                <Text numberOfLines={1} style={styles.textDescription}>Huỷ lịch</Text>
                                <Ionicons name="caret-forward-outline" size={scale(20)} color={appColors.black}
                                    style={{alignSelf: 'center'}}
                                />
                            </View>
                        </Pressable>
                    </View>
                </ScrollView>
            </SafeAreaView>
            </>
        )
    }

    return (<></>)
}

const mapStateToProps = (state) => ({
    userInfo: state.login.userInfo,
    book : state.book.book,
    config: state.home.config,
});
const mapDispatchToProps = { 
    getBook$: getBook,
    removeBooking$: removeBooking
};
  
export default connect(mapStateToProps, mapDispatchToProps)(BookResultScreen);

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor: appColors.WHITE,
    },
    background: {
        height: scale(110),
        backgroundColor: appColors.WHITE
    },
    descriptionContainer:{
        flexDirection: 'row',
        alignItems: 'center',
        paddingRight: 70,
        borderTopColor: '#e8e8e8',
        borderTopWidth: 1,
        paddingHorizontal: scale(5),
        paddingVertical: scale(18),
        borderRadius: 7,
        flexShrink: 1,
        fontWeight: 'bold'
      },
      textDescription: {
        marginLeft: 10,
        color: appColors.black,
        width: '100%',
        fontSize: scale(14),
      },
})