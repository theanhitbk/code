import React,{useState,useEffect, useCallback} from 'react'
import { View, Text, StyleSheet, ImageBackground, Image, Platform } from 'react-native'
import ReduxWrapper from '../../utils/ReduxWrapper';
import { scale } from 'react-native-size-matters';
import { theme } from '../../core/theme'
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useFocusEffect } from '@react-navigation/native';
import NetInfo from "@react-native-community/netinfo";
import { clearToken, getToken } from '../../utils/storage';
import { AlertHelper } from '../../utils/AlertHelper';

function Welcome({logout, navigation}) {

  useFocusEffect(useCallback(() => {
    NetInfo.fetch().then(state => {
      // console.log("Connection type", state.type);
      // console.log("Is connected?", state.isConnected);
      if(!state.isConnected) {
        AlertHelper.show('Lỗi kết nối! Kiểm tra lại kết nội mạng')
      }
    });

    getToken().then((token) => {
     if(token.length === 0) {
        clearToken();
        logout();
     } else {
      navigation.navigate("Home")
     }
    });
  }, []));
  
    return (
      <ImageBackground
          source={require('../../static/images/splash.png')}
          resizeMode="stretch"
          style={styles.background}
        >
          <View style={{
            flex: 1,
            justifyContent:'flex-end'
          }}>
            <Image source={require('../../static/images/logo_1.png')} 
              style={{
                flex: 1, 
                alignItems: 'center',
                resizeMode: 'contain', 
                alignSelf: 'center', 
                width: '60%'
              }}/>
          </View>
        <View style={{justifyContent:'flex-end', flex: 1}}>
          <TouchableOpacity 
            style={{
              width: '100%',
              justifyContent:'center',
              height: Platform.OS == 'ios' ? 180 : 120,
              alignItems: 'center',
            }}
            onPress={() => navigation.navigate('Login')}
          >
            {/* <ImageBackground
              source={require('../../static/images/btn.png')}
              style={{
                justifyContent: 'center',
                resizeMode: 'center',
              }}
            > */}
              <Text style={styles.buttonTextStyle}>Đăng nhập/Đăng ký</Text>
            {/* </ImageBackground> */}
          </TouchableOpacity>
        </View>
      </ImageBackground>
    )
}

export default ReduxWrapper(Welcome)

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
    width: '100%',
    backgroundColor: theme.colors.surface,
  },
  buttonTextStyle: {
    fontFamily: "Oswald-Regular",
    color: '#fff',
    paddingVertical: Platform.OS == 'ios' ? 13 : 13,
    paddingHorizontal: Platform.OS == 'ios' ? 65 : 72,
    fontSize: 24,
    textTransform: 'uppercase',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FE8600',//'#068944',
    borderRadius: scale(25)
  },
  forgotPassword: {
    width: '100%',
    alignItems: 'flex-end',
    marginBottom: 100,
    paddingVertical: scale(5)
  },
  row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  forgot: {
    fontSize: 13,
    color: theme.colors.secondary,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
  view: {
    position: 'absolute',
    backgroundColor: 'transparent'
  },
  touchable: {
    borderWidth: 1,
    // borderRadius: scale(15),
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    // backgroundColor: '#fff',
    flex: 1,
  },
  text: {
    fontSize: 18,
    textAlign: 'center'
  }
})