import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, TouchableOpacity, Image} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import {appColors, shadow} from '../../utils/appColors';
import { useFocusEffect } from '@react-navigation/native';
import { getDetailCategory, getDetailPostCategory } from '../../redux/categoryAction';
import { connect } from 'react-redux';
import {BASE_URL} from '../../../app.json';
import BookingHeader from '../../components/BookingHeader';

function NewsList({posts, getCmsCategory$, getDetailPostCategory$, route: {params}, navigation}) {
  
  const NewsCard = ({post}) => {
    const {image, descriptions} = post;
    return (
      <View style={{flex: 1}}>
        <TouchableOpacity onPress={() => {
          getDetailPostCategory$(post.id)
          navigation.navigate('NewsDetail', {item: post})
        }}>
            <View style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginHorizontal: scale(5),
                borderBottomColor: appColors.darkGray,
                borderBottomWidth: 1,
                paddingVertical: scale(5),
            }}>
                <View style={{
                    // flex: 1, 
                    // flexDirection: 'row', 
                    // position: 'relative',
                    
                }}>
                <Image source={{uri: BASE_URL + image}} 
                    style={{
                        flex: 1,
                        resizeMode: 'contain', 
                        // alignSelf: 'stretch', 
                        height: scale(100),
                        width: scale(120)
                    }}
                />
                </View>
                <View style={{
                    flex: 1,
                    alignItems: 'flex-start',
                    flexShrink: 1,
                    justifyContent: 'flex-start',
                    marginHorizontal: scale(5),
                    paddingLeft: scale(5)
                }}>
                    <Text ellipsizeMode='tail' numberOfLines={1}
                    style={{
                        fontFamily: "OpenSans-Bold",
                        justifyContent: 'flex-start',
                        fontWeight: '700',
                        fontSize: scale(14),
                    }}>{descriptions.title}</Text>
                    <Text ellipsizeMode='tail' numberOfLines={4}>{descriptions.description}</Text>
                </View>
            </View>
        </TouchableOpacity>
      </View>
    );
  };
  const [refreshing, setRefreshing] = useState(false);

  const wait = (timeout) => {
    return new Promise(resolve => {
        setTimeout(resolve, timeout);
    });
  }

  const onRefresh = useCallback(() => {
        setRefreshing(true);
        getCmsCategory$(params.item.id);
        wait(2000).then(() => setRefreshing(false));
  }, []);

  useFocusEffect(useCallback(() => {
    // getCmsCategory$(params.item.id);
  }, []));

  return (
    <SafeAreaView  style={styles.container}>
        <BookingHeader title={'NextCRM Booking'} navigation={navigation}>
            <Text style={{
                color: appColors.BLACK,
                fontSize: scale(20),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>{params.item.title}</Text>
        </BookingHeader>

        <FlatList
          refreshing={refreshing} 
          onRefresh={onRefresh}
          keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_${item.id}`}
          ItemSeparatorComponent={() => <View style={{padding: scale(2)}} />}
          data={posts}
          renderItem={({item, index}) => <NewsCard key={index} post={item} />}
        />
    </SafeAreaView>
  );
}

const mapStateToProps = (state) => ({
    posts : state.categories.cmsPostCategories,
 });
 const mapDispatchToProps = {
   getCmsCategory$: getDetailCategory,
   getDetailPostCategory$: getDetailPostCategory
 };
 
 export default connect(mapStateToProps, mapDispatchToProps)(NewsList);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE,
    },
  contentContiner: {
    //paddingVertical: scale(3),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(5),
    borderBottomWidth: scale(1.2),
    borderBottomColor: '#FE8800',
    paddingVertical: scale(10),
    ...shadow,
  },
});
