import React, { createRef, useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, Image, ImageBackground, Pressable, ScrollView, SafeAreaView} from 'react-native';
import {scale} from 'react-native-size-matters';
import {SimpleStepper} from 'react-native-simple-stepper';
import Container from '../../components/Container';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ActionSheet from "react-native-actions-sheet";
import BottomButtons from '../../components/BottomButtons';
import {connect} from 'react-redux';
import {addToCart} from '../../redux/cartAction';
import { currencyFormat, isRealValue } from '../../utils/HelperFunctions';
import Spinner from '../../components/Spinner';
import { getProduct } from '../../redux/productAction';
import CustomHeader from '../../components/CustomHeader';
import WebView from 'react-native-webview';
import {BASE_URL} from '../../../app.json';
import { FlatListSlider } from 'react-native-flatlist-slider';
import { useFocusEffect } from '@react-navigation/native';

function ProductDetails({product, imageList, cartItems ,addToCart$, getProduct$, navigation, route:{params}}) {
  let HTML = `
    <!doctype html>
    <html>
        <head>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700%7CLato%7CKalam:300,400,700" />
          <style>
            body {
              font-size: 38px;
            }
            
            h2 {
              text-align: left !important;
            }
            h2 span {
              font-size: 40px !important;
            }
          </style>
        </head>
        <body>
            ###content###
        </body>
    </html>
    `

  //item
  const actionSheetRef = createRef();
  const [qty, setQty] = useState(1);
  const [goCart, setGoCart] = useState(false);
  const [opened, setOpen] = useState(false);

  useEffect(() => {
    getProduct$(params.item.id)
  }, [])
  
  const onAddToCart = () => {
    addToCart$({...product, quantity:1});
  };
  const _renderBottom = () => {
    return (
      <BottomButtons
        onPress={() => {
          onAddToCart();
          navigation.navigate('Cart');
        }}
        price={product.price}
        buttonLabel="Thêm giỏ hàng"
      />
    );
  };

  if(!isRealValue(product?.descriptions)) {
    return <Spinner />
  }

  return (
    <>
      <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>         
        <View
          style={{
            paddingHorizontal: scale(5),
            paddingVertical: scale(4),
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: appColors.WHITE,
            borderBottomColor: '#E8E8E8',
            borderBottomWidth: 1
          }}>
          <Pressable onPress={() => navigation.navigate('Shop')}>
            <Feather
              name="chevron-left"
              size={scale(25)}
              color={appColors.black}
            />
          </Pressable>
          <Text numberOfLines={1} ellipsizeMode='tail' style={{
            fontFamily: 'OpenSans-SemiBold',
            fontSize: scale(17),
            flexShrink: 1
          }}>{product.descriptions.name}</Text>
          <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <Pressable
            onPress={() => navigation.navigate('Filters')}
              style={{
                borderRadius: scale(25),
                backgroundColor: '#E8E8E8',
                height: scale(40),
                width: scale(40),
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Feather name="search" size={scale(18)} color={appColors.black} />
            </Pressable>
            <Pressable
              onPress={() => navigation.navigate('Cart')}
              style={{
                borderRadius: scale(25),
                backgroundColor: '#E8E8E8',
                height: scale(40),
                width: scale(40),
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: scale(5),
                position: 'relative'
              }}>
              <Feather name="shopping-cart" size={scale(18)} color={appColors.black} />
              {cartItems.length > 0 && <View style={{
                position: 'absolute', 
                top: -2, 
                right: 0, 
                width: scale(16),
                height: scale(16),
                backgroundColor: appColors.RED, 
                borderRadius: scale(10),
                paddingHorizontal: 5,
                paddingVertical: 1.5,
                alignItems: 'center'
              }}>
                <Text style={{
                  color: appColors.WHITE, 
                  fontSize: scale(10),
                }}>{cartItems.length}</Text>
              </View>
              }
            </Pressable>
            <Pressable onPress={() => {
              let bo = opened;
              setOpen(!bo);
            }}
              style={{
                borderRadius: scale(25),
                backgroundColor: '#E8E8E8',
                height: scale(40),
                width: scale(40),
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Feather name="more-vertical" size={scale(18)} color={appColors.black} />
            </Pressable>
            <View style={{top: 25}}>
            <CustomHeader opened={opened} setOpen={setOpen} />
            </View>
          </View>
        </View>

        <ScrollView contentContainerStyle={{flexGrow:1}} nestedScrollEnabled showsHorizontalScrollIndicator={false} showsVerticalScrollIndicator={false}>
          <Image source={{uri: product.image}} style={{height: scale(300)}}/>
            {/* {imageList.length > 0 && <FlatListSlider 
              data={imageList} 
              height={360}
              // contentContainerStyle={{paddingHorizontal: 16}}
              indicatorContainerStyle={{position:'absolute', bottom: -20}}
              //indicatorActiveColor={'#8e44ad'}
              //indicatorInActiveColor={'#ffffff'}
              // indicatorActiveWidth={10}
              indicatorActiveWidth={15}
              indicatorStyle={{width: 0, height: 0, borderRadius: 50}}
              inactiveDotStyle={{width:scale(20)}}
              animation
              onPress={item => console.log('testt')}
            />} */}
            

              <View style={{flex: 1,paddingVertical: scale(0), paddingHorizontal: scale(10)}}>
                  <Label
                    text={currencyFormat(product.price_promotion ? product.price_promotion : product.price) + ' đ'}
                  style={{
                    fontFamily: 'Oswald-Bold', 
                    fontSize: scale(30), 
                    color: '#FE6600',
                    marginBottom: scale(10)
                  }}
                />
                {product.price_promotion && product.price_promotion < product.price &&
                <View style={{flexDirection: 'row'}}>
                <Label
                    text={currencyFormat(product.price) + ' đ'}
                  style={{
                    fontFamily: 'Oswald-Regular', 
                    fontSize: scale(20), 
                    color: appColors.gray,
                    textDecorationLine: 'line-through', 
                    // textDecorationStyle: 'solid',
                    //borderColor: appColors.LIGHT_GREY,
                    //borderWidth: 1,
                    marginRight: 10
                  }}
                />
                <Label
                    text={'Giảm ' + Math.round(((product.price - product.price_promotion) / product.price) * 100) + '%'}
                  style={{
                    fontFamily: 'Oswald-Regular', 
                    fontSize: scale(16), 
                    color: appColors.BLACK,
                    borderColor: appColors.LIGHT_GREY,
                    borderRadius: scale(5),
                    backgroundColor: appColors.YELLOW,
                    paddingHorizontal: scale(10),
                    paddingVertical: scale(5),
                    alignItems: 'center'
                  }}
                />
                </View>
                }

                <Label
                  text={product.descriptions.name}
                  style={{
                    fontFamily: 'OpenSans-Bold',
                    fontSize: scale(16),
                  }}
                />
                <WebView
                    originWhitelist={['*']}
                    source={{ 
                      html: HTML.replace('###content###', product.descriptions.content??''),
                      baseUrl: BASE_URL
                    }}
                    scalesPageToFit={(Platform.OS === 'ios') ? false : true}
                    javaScriptEnabled={true}
                    javaScriptEnabledAndroid={true}
                />
              </View>            


              {/* <View
                style={{
                  paddingVertical: scale(10),
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <View style={styles.sizeContainer}>
                  <Label text="Size" style={{fontSize: scale(15)}} />
                  <Label
                    text="XL"
                    style={{fontWeight: '700', fontSize: scale(15)}}
                  />
                </View>

                <View style={styles.sizeContainer}>
                  <Label text="Colour" style={{fontSize: scale(15)}} />
                  <View style={styles.itemColor} />
                </View>
              </View> */}

              {/* <View style={{paddingVertical: scale(20)}}>
                <TitleComp heading={'Details'} />
                <View style={{paddingVertical: scale(20)}}>
                  <Label
                    text={detail}
                    style={{fontSize: scale(14), lineHeight: scale(25)}}
                  />
                </View>
              </View>
              <View>
                <TitleComp heading={'Reviews'} />
                <Pressable
                  onPress={() => navigation.navigate('WriteReview', {name})}>
                  <Label text="Write your review" style={styles.wrtitle} />
                </Pressable>

                <ReviewComp />
              </View> */}

        </ScrollView>
      </SafeAreaView>

      <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        // bottom: scale(15),
        // paddingHorizontal: scale(20),
        backgroundColor: appColors.white,
        borderTopColor: appColors.lightGray,
        borderTopWidth: scale(1),
        height: scale(80)
      }}>
        <View style={{
          flex: 1,
          justifyContent: 'flex-start'
        }}>
          <Pressable onPress={() => {
            setGoCart(false);
            actionSheetRef.current?.setModalVisible();
          }}>
            <View style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              textAlignVertical: 'center',
              marginHorizontal: scale(10)
            }}>
              <Feather name='shopping-cart' size={scale(18)} />
            <Text style={{
              fontFamily: 'UVNTinTucHepThemBold',
              textTransform: 'uppercase', 
              fontSize: scale(16),
            }}>Thêm giỏ hàng</Text>
            </View>
          </Pressable>
        </View>
        <View style={{
          flex: 1,
          backgroundColor: '#fe6700',
          justifyContent: 'center',
          height: '100%'
        }}>
          <Pressable onPress={() => {
            setGoCart(true);
            actionSheetRef.current?.setModalVisible();
          }}>
            <View style={{
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Text style={{
                fontFamily: 'UVNTinTucHepThemBold',
                textTransform: 'uppercase', 
                fontSize: scale(21.06),
                fontWeight: 'bold',
                paddingBottom: scale(12)
              }}>Mua ngay</Text>
              <Text style={{
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(11),
              }}>Không ưng đổi ngay</Text>
            </View>
          </Pressable>
        </View>
      </View>

      <ActionSheet
          initialOffsetFromBottom={0.6}
          ref={actionSheetRef}
          statusBarTranslucent
          bounceOnOpen={true}
          drawUnderStatusBar={true}
          bounciness={4}
          gestureEnabled={true}
          defaultOverlayOpacity={0.3}>
          <View
            style={{
              paddingHorizontal: 0,
            }}>
            <View style={[styles.container, {paddingHorizontal: 12,}]}>
                <Image source={{uri: product.image}} style={{width: scale(100), height: scale(100)}}/>
                <View style={{paddingHorizontal: scale(20)}}>
                    <Label
                      text={currencyFormat(product.price??0) + ' đ'}
                    style={{
                      fontFamily: 'UVNTinTucHepThemBold', 
                      fontSize: scale(21), color: '#FE6600'
                    }}
                  />
                  {product.price_promotion && product.price_promotion < product.price && <View style={{
                    alignItems: 'center', 
                    justifyContent: 'center',
                    backgroundColor: '#fe6700', 
                    borderRadius: scale(6), 
                    marginTop: scale(15)
                  }}>
                    <Label
                      text={'Giảm ' + Math.round(((product.price - product.price_promotion) / product.price) * 100) + '%'}
                      style={{
                        fontFamily: 'UVNTinTucHepThemBold',
                        fontSize: scale(14), 
                        color: appColors.BLACK,
                        // paddingHorizontal: scale(3), 
                        paddingVertical: scale(4)
                      }}
                    />
                  </View>
                  }
              </View>
            </View>

            <ScrollView
              nestedScrollEnabled={false}
              onMomentumScrollEnd={() => {
                actionSheetRef.current?.handleChildScrollEnd();
              }}
              style={styles.scrollview}>
              
              <View style={styles.footer}>
                <View style={{
                  flexDirection: 'row', 
                  justifyContent: 'space-between', 
                  marginBottom: scale(30),
                  alignItems: 'center',
                  paddingHorizontal: scale(12)
                }}>
                  <Text style={{
                    fontFamily: 'UVNTinTucHepThemBold',
                    fontSize: scale(18)
                  }}>Số lượng</Text>
                  <SimpleStepper
                    containerStyle={{
                      backgroundColor: appColors.WHITE,
                      flexDirection: 'row',
                      borderColor: appColors.gray,
                      borderWidth: 1,
                      borderRadius: scale(5),
                      overflow: 'hidden',
                      alignItems: 'center',
                      // paddingHorizontal: scale(20),
                      height: scale(30), 
                      width: scale(105)
                    }}
                    initialValue={1}
                    minimumValue={1}
                    incrementStepStyle={{padding: scale(7), opacity: scale(0.4), borderLeftWidth: 1, borderColor: appColors.gray}}
                    decrementStepStyle={{padding: scale(7), opacity: scale(0.4), borderRightWidth: 1, borderColor: appColors.gray}}
                    incrementImageStyle={{height: scale(20), width: scale(20)}}
                    decrementImageStyle={{height: scale(20), width: scale(20)}}
                    showText
                    wraps={true}
                    renderText={() => <Label text={qty} style={{paddingHorizontal: scale(12)}}/>}
                    separatorStyle={{}} 
                    valueChanged={value => setQty(value)}
                  />
                </View>
                
                <Pressable onPress={() => {
                  actionSheetRef.current?.setModalVisible(false);
                  addToCart$({...product, quantity: qty});
                  setQty(1);
                  if(goCart) {
                    navigation.navigate('Cart');
                  }
                }}>
                  <View style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlignVertical: 'center',
                    backgroundColor: '#fe6700',
                    width: '100%',
                    borderRadius: scale(0)
                  }}>
                    <Feather name='shopping-cart' size={scale(20)} />
                    <Text style={{
                      textTransform: 'uppercase', 
                      fontSize: scale(16),
                      fontFamily: 'Oswald-Bold',
                      paddingHorizontal: scale(10),
                      paddingVertical: scale(10)
                    }}>Thêm giỏ hàng</Text>
                  </View>
                </Pressable>
                
              </View>
            </ScrollView>
            
          </View>
      </ActionSheet>
      {/* {_renderBottom()} */}
    </>
  );
}

const mapStateToProps = (state) => ({
   cartItems : state.cart.cartItems,
   product: state.products.product,
   imageList: state.products.imageList
});
const mapDispatchToProps = {
  addToCart$: addToCart,
  getProduct$: getProduct,
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductDetails);
const styles = StyleSheet.create({
  sizeContainer: {
    flex: 0.47,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: appColors.white,
    padding: scale(10),
    paddingHorizontal: scale(20),
    borderRadius: scale(20),
    borderWidth: scale(0.4),
    borderColor: appColors.gray,
  },
  itemColor: {
    height: scale(20),
    width: scale(20),
    backgroundColor: appColors.primary,
    borderRadius: scale(5),
  },
  wrtitle: {
    paddingVertical: scale(10),
    fontSize: scale(14),
    color: appColors.primary,
  },
  footer: {
    height: 320,
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  placeholder: {
    height: 15,
    backgroundColor: '#f0f0f0',
    marginVertical: 15,
    borderRadius: 5,
  },
  circle: {
    width: 60,
    height: 60,
    borderRadius: 100,
  },
  btnLeft: {
    width: 30,
    height: 30,
    backgroundColor: '#f0f0f0',
    borderRadius: 100,
  },
  input: {
    width: '100%',
    minHeight: 50,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#f0f0f0',
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  container: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginVertical: 25,
    borderBottomColor: appColors.lightGray,
    borderBottomWidth: 2,
  },
  scrollview: {
    width: '100%',
    //padding: 12,
    paddingVertical: scale(10)
  },
  btn: {
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: '#fe8a71',
    paddingHorizontal: 10,
    borderRadius: 5,
    elevation: 5,
    shadowColor: 'black',
    shadowOffset: { width: 0.3 * 4, height: 0.5 * 4 },
    shadowOpacity: 0.2,
    shadowRadius: 0.7 * 4,
  },
  safeareview: {
    justifyContent: 'center',
    flex: 1,
  },
  btnTitle: {
    color: 'white',
    fontWeight: 'bold',
  },
  menuOptions: {
    shadowColor: appColors.lightGray,
    shadowOpacity: 0.5,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 5,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: appColors.lightGray,
    paddingVertical: scale(10),
    paddingHorizontal:scale(4),
    width: '100%',
    ...shadow
  }
});
