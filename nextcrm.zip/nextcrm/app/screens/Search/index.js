import React, { useEffect, useState } from 'react';
import {View, Text, FlatList, Pressable, TouchableOpacity, Image, SafeAreaView,
  RefreshControl
} from 'react-native';
import {scale} from 'react-native-size-matters';
import Feather from 'react-native-vector-icons/dist/Feather';
import { connect } from 'react-redux';
import CustomHeader from '../../components/CustomHeader';
import { HotCategoryItem } from '../../components/HotCategoryItem';
import Label from '../../components/Label';
import SearchBox from '../../components/SearchBox';
import Spinner from '../../components/Spinner';
import { getHotCategories } from '../../redux/categoryAction';
import { getProducts, searchProduct } from '../../redux/productAction';
import { appColors, shadow } from '../../utils/appColors';
import { recentSearches } from '../../utils/MockData';
import ProductCard from '../../components/ProductCard';

function Search({isSearchloading, searchResultProducts, cartItems, hotCategories, 
  getHotCategories$, getProducts$, searchProduct$, navigation}) {
  
  const [opened, setOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [keyword, setKeyword] = useState(null);
  
  useEffect(() => {
    //getHotCategories$()
  }, [])

  const onRefresh = () => {
    setRefreshing(true);
    getHotCategories$()
    setRefreshing(false);
  }

  const onSearch = (keyword) => {
    setKeyword(keyword)
    searchProduct$({keyword: keyword})
  }

  return (
    <SafeAreaView style={{
      backgroundColor: appColors.WHITE,
    }}>
      <View style={{
          flex: 1, 
          top: scale(50),
          right: 0
        }}
        >
        <CustomHeader opened={opened} setOpen={setOpen} style={{zIndex: 15}}/>
      </View>
      {searchResultProducts.length === 0 &&
        <FlatList
          ListHeaderComponent={
            <View style={{zIndex: 5}}>
              <View style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: scale(10),
                marginHorizontal: scale(5),
                position: 'relative',
              }}>
                <Pressable onPress={() => navigation.navigate('Shop')}>
                  <Feather name='arrow-left' size={24} />
                </Pressable>
                <View style={{
                  width: '65%'
                }}>
                  <SearchBox hideCamra rightIcon={"x"} autoFocus 
                    onChangeText={onSearch}
                    currentValue={keyword}
                    onRightIconPress={()=>{ navigation.navigate("Shop") }}  
                  />
                </View>
                <Pressable
                  onPress={() => navigation.navigate('Cart')}
                  style={{
                    borderRadius: scale(25),
                    backgroundColor: '#E8E8E8',
                    height: scale(40),
                    width: scale(40),
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginHorizontal: scale(5),
                    position: 'relative'
                  }}>
                  <Feather name="shopping-cart" size={scale(18)} color={appColors.black} />
                  <View style={{
                    position: 'absolute', 
                    top: -2, 
                    right: 0, 
                    width: scale(16),
                    height: scale(16),
                    backgroundColor: appColors.RED, 
                    borderRadius: scale(10),
                    paddingHorizontal: 5,
                    paddingVertical: 1.5,
                    alignItems: 'center'
                  }}>
                    <Text style={{
                      color: appColors.WHITE, 
                      fontSize: scale(10),
                    }}>{cartItems.length}</Text>
                  </View>
                </Pressable>
                <Pressable onPress={() => {
                  let bo = opened;
                  setOpen(!bo);
                }}
                  style={{
                    borderRadius: scale(25),
                    backgroundColor: '#E8E8E8',
                    height: scale(40),
                    width: scale(40),
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Feather name="more-vertical" size={scale(18)} color={appColors.black} />
                </Pressable>
              </View>
      
              <View style={{
                backgroundColor: appColors.lightGray,
                borderColor: appColors.lightGray,
                borderWidth: 1,
                paddingVertical: scale(3)
              }}/>

              <View style={{
                marginHorizontal: scale(5), 
                paddingVertical: scale(10)
              }}>
                <Text 
                style={{
                  fontFamily: 'Oswald-Bold',
                  fontSize: scale(20)
                }}
                >Tìm kiếm phổ biến</Text>
              </View>
            </View>
          }
          refreshControl={
            <RefreshControl colors={["#9Bd35A", "#689F38", "#FE8800"]}
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
          numColumns={2} 
          ItemSeparatorComponent={()=> <View style={{padding:scale(5) }} /> }
          data={recentSearches}
          renderItem={({item, index})=> 
            <View style={{
              backgroundColor: appColors.lightGray,
              paddingHorizontal: scale(10),
              paddingVertical: scale(5),
              borderRadius: scale(5),
              marginHorizontal: scale(5),
              width: '45%',
              elevation: -1,
              zIndex: -1
            }}>
              <TouchableOpacity onPress={() => onSearch(item)}>
                <Label text={item} />
              </TouchableOpacity>
            </View>
          } 
          columnWrapperStyle={{
            justifyContent: 'space-between',
            marginBottom: scale(5)
          }}
          ListFooterComponent={
            <View>
              <View style={{
                backgroundColor: appColors.lightGray,
                borderColor: appColors.lightGray,
                borderWidth: 1,
                paddingVertical: scale(3)
              }}/>

              <View style={{marginHorizontal: scale(5), paddingVertical: scale(10)}}>
                <Text 
                style={{
                  fontFamily: 'Oswald-Bold',
                  fontSize: scale(20)
                }}
                >Danh mục nổi bật</Text>
                <FlatList 
                  style={{
                    paddingVertical:scale(10)
                  }} 
                  numColumns={4} 
                  ItemSeparatorComponent={()=> <View style={{padding:scale(5) }} /> }
                  data={hotCategories}
                  renderItem={({item,index})=> <HotCategoryItem category={item} navigation={navigation} getProducts={getProducts$}/>} 
                />
              </View>
            </View>
          }
          contentContainerStyle={{
            justifyContent: 'space-between',
            elevation: -1,
            zIndex: -1
          }}
        />
      }

      {searchResultProducts.length > 0 &&
        <FlatList
          ListHeaderComponent={
            <View style={{zIndex: 5}}>
              <View style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: scale(10),
                marginHorizontal: scale(5),
                position: 'relative',
              }}>
                <Pressable onPress={() => onSearch(null)}>
                  <Feather name='arrow-left' size={24} />
                </Pressable>
                <View style={{
                  width: '65%'
                }}>
                  <SearchBox hideCamra rightIcon={"x"} autoFocus 
                    onChangeText={onSearch}
                    currentValue={keyword}
                    onRightIconPress={()=>{ navigation.navigate("Shop") }}  
                  />
                </View>
                <Pressable
                  onPress={() => navigation.navigate('Cart')}
                  style={{
                    borderRadius: scale(25),
                    backgroundColor: '#E8E8E8',
                    height: scale(40),
                    width: scale(40),
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginHorizontal: scale(5),
                    position: 'relative'
                  }}>
                  <Feather name="shopping-cart" size={scale(18)} color={appColors.black} />
                  <View style={{
                    position: 'absolute', 
                    top: -2, 
                    right: 0, 
                    width: scale(16),
                    height: scale(16),
                    backgroundColor: appColors.RED, 
                    borderRadius: scale(10),
                    paddingHorizontal: 5,
                    paddingVertical: 1.5,
                    alignItems: 'center'
                  }}>
                    <Text style={{
                      color: appColors.WHITE, 
                      fontSize: scale(10),
                    }}>{cartItems.length}</Text>
                  </View>
                </Pressable>
                <Pressable onPress={() => {
                  let bo = opened;
                  setOpen(!bo);
                }}
                  style={{
                    borderRadius: scale(25),
                    backgroundColor: '#E8E8E8',
                    height: scale(40),
                    width: scale(40),
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <Feather name="more-vertical" size={scale(18)} color={appColors.black} />
                </Pressable>
              </View>
      
              <View style={{
                backgroundColor: appColors.lightGray,
                borderColor: appColors.lightGray,
                borderWidth: 1,
                paddingVertical: scale(3)
              }}/>

              <View style={{
                marginHorizontal: scale(5), 
                paddingVertical: scale(10)
              }}>
                <Text 
                style={{
                  fontFamily: 'Oswald-Bold',
                  fontSize: scale(20)
                }}
                >Kết quả tìm kiếm</Text>
              </View>
            </View>
          }
          numColumns={2} 
          ItemSeparatorComponent={()=> <View style={{padding:scale(0) }} /> }
          data={searchResultProducts}
          renderItem={({item,idx})=> (<ProductCard key={'pro_' + idx} navigation={navigation} item={item}/>)} 
          columnWrapperStyle={{
            justifyContent: 'space-between',
          }}
        />
      }


      {isSearchloading && <Spinner />}

    </SafeAreaView>
  );
}

const mapStateToProps = (state) => ({
  cartItems : state.cart.cartItems,
  hotCategories: state.categories.hotCategories,
  isSearchloading: state.products.isSearchloading,
  searchResultProducts: state.products.searchResultProducts
});
const mapDispatchToProps = {
  getHotCategories$: getHotCategories,
  getProducts$: getProducts,
  searchProduct$: searchProduct,
};

export default connect(mapStateToProps, mapDispatchToProps)(Search);