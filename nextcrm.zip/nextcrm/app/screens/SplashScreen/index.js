import React, {useState, useEffect} from 'react';
import {
  View,
  StyleSheet,
  Image,
  ImageBackground
} from 'react-native';
import Spinner from '../../components/Spinner';
import { theme } from '../../core/theme';
import ReduxWrapper from '../../utils/ReduxWrapper';

function index({isLoggedIn, navigation}) {
    //State for ActivityIndicator animation
  const [animating, setAnimating] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setAnimating(false);
      if(!isLoggedIn) {
        navigation.navigate("Welcome")
      } else {
        navigation.navigate("Home")
      }
    }, 500)
  }, []);

  return (
    <ImageBackground
          source={require('../../static/images/nextcrm_bg.png')}
          resizeMode="stretch"
          style={styles.background}
        >
          <View style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Spinner />
          </View>
    </ImageBackground>
  );
}
export default ReduxWrapper(index)
const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.colors.surface,
  },
});