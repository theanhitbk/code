import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, Pressable, FlatList, TouchableOpacity, ImageBackground, Image, SafeAreaView, ScrollView} from 'react-native';
import {scale} from 'react-native-size-matters';
import Feather from 'react-native-vector-icons/Feather';
import {appColors, shadow} from '../../utils/appColors';
import Label from '../../components/Label';
import {profileKeys} from '../../utils/MockData';
import AvatarImage from '../../components/AvatarImage' 
import auth from '@react-native-firebase/auth';
import ReduxWrapper from '../../utils/ReduxWrapper';
import { clearToken, getToken } from '../../utils/storage';
import { useFocusEffect } from '@react-navigation/native';
import TextInput from '../../components/TextInput';

function Profile({isLoggedIn, userInfo, logout, navigation}) {
  
  useFocusEffect(useCallback(() => {
    getToken().then((token) => {
       if(token.length === 0) {
          clearToken();
          logout();
       }
      });
  }, []));

  const onLogout = ()=>{ 
     //auth().signOut()
     clearToken()
     logout()
  }
  const ItemCard = ({item}) => {
    const {lebel, icon,isNew,route} = item;

    return (
      <Pressable onPress={() =>{
        route=="Login"&& onLogout()
        route&& navigation.navigate(route) 
        }} style={styles.itemContainer}>
        <Pressable  style={styles.iconContainer}>
          {route=='Member' &&
            <Image source={require('../../static/images/icon-member.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Account' &&
            <Image source={require('../../static/images/icon-user2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Reward' &&
            <Image source={require('../../static/images/icon-reward2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='History' &&
            <Image source={require('../../static/images/icon-history2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Login' &&
            <Feather name={icon} size={scale(18)} color={appColors.black} style={{marginRight: scale(8)}} />
          }
          {/* <Feather name={icon} size={scale(22)}color={appColors.black}  /> */}
        </Pressable>
        <View style={styles.itemInnerContainer}>
          <Label text={lebel} style={{fontFamily: 'OpenSans-Regular', fontSize: scale(13)}}/>
          {isNew&&<View style={{paddingHorizontal:scale(10), backgroundColor:appColors.red, padding:scale(5), borderRadius:scale(4)}}>
             <Label text="New" style={{fontFamily: 'OpenSans-Regular', fontSize:scale(10), color:appColors.white}} /> 
          </View>}
          <Feather name={"chevron-right"} size={scale(18)} />
        </View>
      </Pressable>
    );
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE,}}>
        <View style={{
            flexDirection: 'row', 
            justifyContent: 'flex-start',
            alignItems: 'center',
            backgroundColor: appColors.WHITE,
            paddingVertical: scale(15),
            paddingHorizontal: scale(15)
        }}>
            <TouchableOpacity onPress={() => navigation.navigate('Account')}>
                <Feather name='arrow-left' size={24} />
            </TouchableOpacity>
            <Text style={{
                fontFamily: 'OpenSans-Bold',
                paddingLeft: scale(10),
                fontSize: scale(14)
            }}>Chỉnh sửa tài khoản</Text>
        </View>
        <View style={{
          backgroundColor: appColors.WHITE,
          justifyContent: 'flex-start', 
          alignItems: 'center'
        }}>               
            <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                }}>
                <ImageBackground
                    source={require('../../static/images/icon-user2.png')}
                    resizeMode="contain"
                    style={{
                        flex: 1,
                        width: '100%',
                        height: 80,
                    }}
                >
                </ImageBackground>
            </View>
        </View>
        <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: appColors.WHITE,
            borderBottomColor: appColors.YELLOW,
            borderBottomWidth: 1,
            paddingVertical: scale(10)
        }}>
            <Text style={{
                fontFamily: 'OpenSans-Bold',
                fontSize: scale(14),
                color: appColors.darkGray,
            }}>Thông tin của anh/chị</Text>
        </View>
        <ScrollView nestedScrollEnabled style={{
          paddingHorizontal: scale(10),
          paddingTop: scale(10)
        }}>
          <View style={{
              marginVertical: scale(5)
            }}>
            <Label text={'Họ và tên'} 
            style={{
                textTransform: 'uppercase',
                color: appColors.darkGray,
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14),
            }}
            />
            <TextInput mode='flat' underlineColor={appColors.lightGray}
                containerStyles={{
                    marginTop: scale(0),
                    paddingTop: 0,
                    marginBottom: scale(20)
                }}
                style={{
                    fontFamily: 'OpenSans-Regular',
                    fontSize: scale(14),
                    paddingHorizontal: scale(0),
                    backgroundColor: appColors.WHITE,
                }}
                placeholder={'Nhập họ tên'}
            />
          </View>
          <View>
            <Label text={'Email'} 
            style={{
                textTransform: 'uppercase',
                color: appColors.darkGray,
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14)
            }}
            />
            <TextInput mode='flat' underlineColor={appColors.lightGray}
                containerStyles={{
                    marginTop: scale(0),
                    paddingTop: 0,
                    marginBottom: scale(20)
                }}
                style={{
                    fontFamily: 'OpenSans-Regular',
                    fontSize: scale(14),
                    paddingHorizontal: scale(0),
                    backgroundColor: appColors.WHITE,
                }}
                placeholder={'Nhập địa chỉ email'}
            />
          </View>
          <View>
            <Label text={'Số điện thoại'} 
            style={{
                textTransform: 'uppercase',
                color: appColors.darkGray,
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14)
            }}
            />
            <TextInput mode='flat' underlineColor={appColors.lightGray}
                containerStyles={{
                    marginTop: scale(0),
                    paddingTop: 0,
                    marginBottom: scale(20),
                    borderBottomColor: appColors.lightGray,
                    borderBottomWidth: 1
                }}
                style={{
                    fontFamily: 'OpenSans-Regular',
                    fontSize: scale(14),
                    paddingHorizontal: scale(0),
                    backgroundColor: appColors.WHITE,
                }}
                placeholder={'Nhập số điện thoại'}
                value={userInfo.phone}
                disabled={true}
                readonly={true}
            />
          </View>
          <View>
            <Label text={'Ngày sinh'} 
            style={{
                textTransform: 'uppercase',
                color: appColors.darkGray,
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14)
            }}
            />
            <TextInput mode='flat' underlineColor={appColors.lightGray}
                containerStyles={{
                    marginTop: scale(0),
                    paddingTop: 0,
                    marginBottom: scale(20)
                }}
                style={{
                    fontFamily: 'OpenSans-Regular',
                    fontSize: scale(14),
                    paddingHorizontal: scale(0),
                    backgroundColor: appColors.WHITE,
                }}
                placeholder={'Nhập ngày sinh'}
            />
          </View>
          <View>
            <Label text={'Địa chỉ'} 
            style={{
                textTransform: 'uppercase',
                color: appColors.darkGray,
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14)
            }}
            />
            <TextInput mode='flat' underlineColor={appColors.lightGray}
                containerStyles={{
                    marginTop: scale(0),
                    paddingTop: 0,
                    marginBottom: scale(20)
                }}
                style={{
                    fontFamily: 'OpenSans-Regular',
                    fontSize: scale(14),
                    paddingHorizontal: scale(0),
                    backgroundColor: appColors.WHITE,
                }}
                placeholder={'Nhập số địa chỉ'}
            />
          </View>
          <View style={{
              marginVertical: scale(20)
          }}>
              <Pressable onPress={() => console.log('111')}
              style={{
                  alignItems: 'center',
                  borderWidth: 1,
                  borderColor: appColors.YELLOW,
                  backgroundColor: appColors.YELLOW,
                  paddingHorizontal: scale(20),
                  paddingVertical: scale(14),
                  ...shadow
              }}
              >
                  <Text style={{
                      fontFamily: 'OpenSans-Bold',
                      fontSize: scale(16),
                      color: appColors.darkGray
                  }}>Cập nhật</Text>
              </Pressable>
          </View>
      </ScrollView>
    </SafeAreaView>
  );
}
export default ReduxWrapper(Profile)
const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingVertical: scale(15),
    borderBottomColor: appColors.lightGray,
    borderBottomWidth: scale(.7)
  },
  itemInnerContainer: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
});
