import React, { useCallback, useEffect, useRef, useState } from 'react';
import {View, Text, FlatList, Pressable, StyleSheet, useWindowDimensions} from 'react-native';
import {scale} from 'react-native-size-matters';
import Label from '../../components/Label';
import ProductCard from '../../components/ProductCard';
import Feather from 'react-native-vector-icons/Feather';
import {appColors, shadow} from '../../utils/appColors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TabView, TabBar } from 'react-native-tab-view';
import Spinner from '../../components/Spinner';
import { connect } from 'react-redux';
import { getProducts } from '../../redux/productAction';
import CustomHeader from '../../components/CustomHeader';
import Dropdown from '../../components/Dropdown';
import { useFocusEffect } from '@react-navigation/native';

function Category({productList, subCategories, loading, paging, routes,
  getProducts$, navigation, route: {params}}) {

  const layout = useWindowDimensions();
  const dataFilter = [
    {label: 'Giá giảm dần', value: 'price_desc'},
    {label: 'Giá tăng dần', value: 'price_asc'},
    {label: 'Sort giảm dần', value: 'sort_desc'},
    {label: 'Sort tăng dần', value: 'sort_asc'},
    {label: 'ID giảm dần', value: 'id_desc'},
    {label: 'ID tăng dần', value: 'id_asc'},
  ]

  const [index, setIndex] = useState(0);
  const [opened, setOpen] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  
  const [sorted, setSorted] = useState(dataFilter[0]);

  const flatListRef = useRef();
  useFocusEffect(useCallback(() => {
    if(subCategories.length > 0) {
      getProducts$({category_id: subCategories[index].key, page: 1, filter_sort: sorted.value, subCategories: subCategories});
    }
  }, [index, sorted]));

  const onRefresh = () => {
    if(subCategories.length > 0) {
      setIsFetching(true);
      getProducts$({category_id: subCategories[index].key, page: 1, filter_sort: sorted.value, subCategories: subCategories});
      setIsFetching(false);
    }
  }

  const handleLoadMore = () => {
    if(paging.current_page < paging.last_page){ 
        getProducts$({category_id: subCategories[index].key, page: paging.current_page + 1, filter_sort: sorted.value, subCategories: subCategories});
    }
  };

  const filterToolbar = () => {

    return (
      <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: '#D6D8DD',
        paddingVertical: scale(10),
        paddingHorizontal: scale(10),
        marginTop: 1
      }}>
        <View style={{width: '50%'}}>
          <Dropdown label="Mặc định" data={dataFilter} onSelect={setSorted} isIcon
            dropdownStyle={{
              width: '50%',
              left: 0
            }}
          />
        </View>
        <View style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <Feather name='filter' size={20}/>
          <Text style={{
            fontFamily: 'OpenSans-Regular',
            fontSize: scale(14)
          }}>Lọc</Text>
        </View>
      </View>
    );
  };

  const renderListView = () => {
    return (
      <FlatList 
          ref={flatListRef}
          contentContainerStyle={{flexGrow: 1}}
          keyExtractor={item => `product_${item.id.toString()}`}
          onRefresh={onRefresh}
          refreshing={isFetching}
          onEndReachedThreshold={0.5}
          onEndReached={handleLoadMore}
          initialNumToRender={10}
          columnWrapperStyle={{
            justifyContent: 'space-between', flexShrink: 1,
            // paddingHorizontal: scale(5)
          }}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          ItemSeparatorComponent={()=> <View style={{padding:scale(0)}} />}
          numColumns={2}
          data={productList}
          renderItem={({item, index}) => (
            <ProductCard
              key={index}
              navigation={navigation}
              item={{...item, isNew: index < 1}}
            />
          )}
          contentContainerStyle={{
            //justifyContent: 'center',
          }}
          style={{
            ...shadow,
            flexDirection: 'column',
            // marginHorizontal: scale(10)
          }}
          ListFooterComponent={renderFooter()}
        />
    )
  };

  const renderScene = ({route}) => {
    return (
      <View style={{
        flex: 1,
        // flexDirection: 'row',
        justifyContent: 'space-between',
      }}>
          {(loading) ? <Spinner />
          :
          renderListView()
        }
      </View>
    );
  };

  const _renderHeader = () => {
    return (
      <>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingVertical: scale(10),
            paddingLeft: scale(10)
          }}>
          <Pressable onPress={() => navigation.navigate('Shop')}>
            <Feather name="chevron-left" size={scale(25)} />
          </Pressable>

          <Label
            text={params.item.title}
            numberOfLines={1}
            style={{
              fontFamily: 'Oswald-Bold',
              flex: 1,
              fontWeight: '500',
              justifyContent: 'flex-start',
              alignItems: 'center',
              fontSize: scale(18),
              flexShrink: 1,
              marginLeft: 10
            }}
          />

          <Pressable onPress={() => navigation.navigate('Search')}>
            <View
              style={{
                height: scale(45),
                width: scale(45),
                backgroundColor: appColors.gray,
                justifyContent: 'center',
                alignItems: 'center',
                borderRadius: scale(25),
                marginRight: scale(5)
              }}>
              <Feather name="search" size={scale(20)} color={appColors.black} />
            </View>
          </Pressable>
          
          <Pressable onPress={() => {
            let bo = opened;
            setOpen(!bo);
          }}>
          <View
            style={{
              height: scale(45),
              width: scale(45),
              backgroundColor: appColors.gray,
              justifyContent: 'center',
              alignItems: 'center',
              borderRadius: scale(25),
              marginRight: scale(5)
            }}>
            <Feather name="more-vertical" size={scale(20)} color={appColors.black} />
          </View>
          </Pressable>
        </View>
        <View style={{
            top: 0,
            right: 0
          }}
        >
          <CustomHeader opened={opened} setOpen={setOpen} style={{zIndex: 15}} navigation={navigation}/>
        </View>
        
      </>
    );
  };
  
  const renderTabBar = props => (
    <>
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor:appColors.ORANGE}}
      activeColor={appColors.BLACK}
      inactiveColor={appColors.BLACK}
      scrollEnabled
      contentContainerStyle={{
        // flexShrink: 1,
        fontFamily: 'Oswald-Bold',
      }}
      tabStyle={{
        width: 'auto'
      }}
      style={{ 
        fontFamily: 'Oswald-Bold',
        backgroundColor: '#FFEADC', 
        color: appColors.BLACK,
      }}
    />
    {filterToolbar()}
    </>
  );

  const renderFooter = () => {
    if(paging.current_page >= paging.last_page) return null;
  
    return (<View style={styles.footerText}>
            {loading && <Spinner />}
        </View>
      );
  }

  return (
    <>
      <SafeAreaView  style={{flex: 1, backgroundColor: appColors.WHITE,}}>
        {_renderHeader()}

        {routes?.length > 0 ? 
        <TabView
          renderTabBar={renderTabBar}
          navigationState={{ index, routes }}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={{ width: layout.width }}
        />
        :
        <View>
          {filterToolbar()}
          {renderListView()}
        </View>
        }
      </SafeAreaView>
      {/* <BottomButtons onPress={()=> navigation.navigate("Filters")} priceLabel={'No Filter Applied'} buttonLabel="Filter" /> */}
    </>
  );
}

const mapStateToProps = (state) => ({
  subCategories : state.products.subCategories,
  productList: state.products.products,
  loading: state.products.loading,
  paging: state.products.paging,
  routes: state.products.routes
});
const mapDispatchToProps = {
//  addToCart$: addToCart,
 getProducts$: getProducts
};

export default connect(mapStateToProps, mapDispatchToProps)(Category);

const styles = StyleSheet.create({

})