import React,{useState,useEffect, useCallback} from 'react'
import { View, Text, StyleSheet, SafeAreaView, Image, Pressable, FlatList, Platform, ScrollView, useWindowDimensions, ImageBackground } from 'react-native'
import ReduxWrapper from '../../utils/ReduxWrapper';
import { scale } from 'react-native-size-matters';
import { appColors } from '../../utils/appColors';
import BookingHeader from '../../components/BookingHeader';
import { useFocusEffect } from '@react-navigation/native';
import { SceneMap, TabBar, TabView } from 'react-native-tab-view';
import Feather from 'react-native-vector-icons/dist/Feather';

function Member({isLoggedIn, userInfo, resetBook$, getPTSchedules, addBooking$, navigation}) 
{
    
    useFocusEffect(useCallback(() => {
        if(!isLoggedIn) {
            navigation.navigate('Login')
        }
    }, []));

    const layout = useWindowDimensions();

    const FirstRoute = () => (
        <ScrollView style={{backgroundColor: '#eeeeee'}} showsVerticalScrollIndicator={false} nestedScrollEnabled>
            <View style={{height:scale(220), marginHorizontal: scale(15), marginVertical: scale(20)}}>
                <Text style={{
                    fontFamily: "OpenSans-Bold",
                    fontSize: scale(18),
                    textTransform: 'uppercase',
                }}>Các ưu đãi của hạng black</Text>
                
                <View style={{flex: 1, flexDirection: 'row', marginTop: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-reward.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi MUA 1 TẶNG 2</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Nhận mã ưu đãi bất ngờ mỗi tháng</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row', marginVertical: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-clock.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi gia hạn</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Đặt trước lịch 3 ngày</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row'}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-user2.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi free</Text>
                        <Text style={{color: appColors.darkGray, fontFamily:'OpenSans-Regular'}}>Được yêu cầu phục vụ riêng khi đặt trước lịch</Text>
                    </View>
                </View>
            </View>
        </ScrollView>
      );
      
      const SecondRoute = () => (
        <ScrollView style={{backgroundColor: '#eeeeee'}}>
            <View style={{height:scale(220), marginHorizontal: scale(15), marginVertical: scale(20)}}>
                <Text style={{
                    fontFamily: "OpenSans-Bold",
                    fontSize: scale(18),
                    textTransform: 'uppercase',
                }}>Các ưu đãi của hạng silver</Text>
                
                <View style={{flex: 1, flexDirection: 'row', marginTop: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-reward.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi MUA 1 TẶNG 2</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Nhận mã ưu đãi bất ngờ mỗi tháng</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row', marginVertical: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-clock.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily:'OpenSans-Bold'}}>Ưu đãi gia hạn</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Đặt trước lịch 3 ngày</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row'}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-user2.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi free</Text>
                        <Text style={{color: appColors.darkGray, fontFamily:'OpenSans-Regular'}}>Được yêu cầu phục vụ riêng khi đặt trước lịch</Text>
                    </View>
                </View>
            </View>
        </ScrollView>
      );

      const ThirdRoute = () => (
        <ScrollView style={{backgroundColor: '#eeeeee'}}>
            <View style={{height:scale(220), marginHorizontal: scale(15), marginVertical: scale(20)}}>
                <Text style={{
                    fontFamily: "OpenSans-Bold",
                    fontSize: scale(18),
                    textTransform: 'uppercase',
                    fontWeight: '700'
                }}>Các ưu đãi của hạng gold</Text>
                
                <View style={{flex: 1, flexDirection: 'row', marginTop: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-reward.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi MUA 1 TẶNG 2</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Nhận mã ưu đãi bất ngờ mỗi tháng</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row', marginVertical: scale(15)}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-clock.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi gia hạn</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Đặt trước lịch 3 ngày</Text>
                    </View>
                </View>
                <View style={{flex: 1, flexDirection: 'row'}}>
                    <View style={{
                        borderWidth:1,
                        borderColor: '#d6d8dd',
                        borderRadius: scale(50),
                        backgroundColor: '#d6d8dd',
                        width: scale(45),
                        height: scale(45),
                        justifyContent: 'center',
                        alignItems: 'center'
                    }}>
                        <Image source={require('../../static/images/icon-user2.png')} 
                            style={{
                                width: scale(20), 
                                height: scale(20), 
                                alignItems: 'center',
                            }}
                        />
                    </View>
                    <View style={{marginHorizontal: scale(15)}}>
                        <Text style={{fontSize: scale(16), fontFamily: 'OpenSans-Bold'}}>Ưu đãi free</Text>
                        <Text style={{color: appColors.darkGray, fontFamily: 'OpenSans-Regular'}}>Được yêu cầu phục vụ riêng khi đặt trước lịch</Text>
                    </View>
                </View>
            </View>
        </ScrollView>
      );
      
      const renderScene = SceneMap({
        first: FirstRoute,
        second: SecondRoute,
        third: ThirdRoute
      });

    const [index, setIndex] = React.useState(0);
    const [routes] = React.useState([
        { key: 'first', title: 'Black' },
        { key: 'second', title: 'Silver' },
        { key: 'third', title: 'Gold' },
    ]);

    const renderTabBar = props => (
        <TabBar
          {...props}
          indicatorStyle={{ backgroundColor: appColors.GREEN }}
          style={{ backgroundColor: '#eeeeee', fontFamily: 'OpenSans-Bold' }}
          activeColor={appColors.BLACK}
          inactiveColor={appColors.BLACK}
        />
      );

    return (
    <>
        <BookingHeader title={'NextCRM Member'} isback navigation={navigation}>
            <Text style={{
                color: appColors.BLACK,
                fontSize: scale(16),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>Chưa có hạng thành viên: mua ngay</Text>
          
        </BookingHeader>
        <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
            <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled contentContainerStyle={{flexGrow:1}}>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginHorizontal: scale(5)
                }}>
                    <ImageBackground
                        source={require('../../static/images/black-level-bg.png')}
                        resizeMode="contain"
                        style={{
                            flex: 1,
                            width: '100%',
                            paddingVertical: scale(20),
                            marginHorizontal: scale(10),
                        }}
                    >
                        <View style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'relative'
                        }}>
                            <Image source={require('../../static/images/icon-black.png')} 
                                style={{
                                    width: scale(16),
                                    height: scale(16),
                                    position: 'absolute',
                                    top: scale(5),
                                    right: scale(30)
                                }}
                            />
                            <Text style={{
                                fontFamily: 'OpenSans-Bold',
                                fontSize: scale(14),
                                textTransform: 'uppercase',
                                color: appColors.WHITE,
                                paddingTop: scale(30)
                            }}>Hạng black</Text>
                        </View>
                    </ImageBackground>

                    <ImageBackground
                        source={require('../../static/images/silver-level-bg.png')}
                        resizeMode="contain"
                        style={{
                            flex: 1,
                            width: '100%',
                            paddingVertical: scale(20),
                            marginHorizontal: scale(10),
                        }}
                    >
                        <View style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <Image source={require('../../static/images/icon-silver.png')} 
                                style={{
                                    width: scale(20),
                                    height: scale(20),
                                    position: 'absolute',
                                    top: scale(0),
                                    right: scale(15)
                                }}
                            />
                            <Text style={{
                                fontFamily: 'OpenSans-Bold',
                                fontSize: scale(14),
                                textTransform: 'uppercase',
                                color: appColors.WHITE,
                                paddingTop: scale(30)
                            }}>Hạng silver</Text>
                        </View>
                    </ImageBackground>
                </View>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    backgroundColor: '#eeeeee',
                    borderRadius: scale(5),
                    marginVertical: scale(15),
                    marginHorizontal: scale(10),
                    paddingVertical: scale(7),
                    paddingHorizontal: scale(7),
                    alignItems: 'center'
                }}>
                    <Text style={{fontSize: scale(14), fontFamily: 'OpenSans-Regular'}}>Có thể thăng hạng</Text>
                    <Feather name="chevron-right" size={scale(20)} color={appColors.BLACK} />
                </View>
                <View style={{flex: 1}}>
                    <TabView
                        renderTabBar={renderTabBar}
                        navigationState={{ index, routes }}
                        renderScene={renderScene}
                        onIndexChange={setIndex}
                        initialLayout={{ width: layout.width }}
                    />
                </View>
                
            </ScrollView>
        </SafeAreaView>
    </>
    )
}

export default ReduxWrapper(Member)

const styles = StyleSheet.create({
  
})