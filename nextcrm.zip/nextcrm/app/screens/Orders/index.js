import React, { useCallback, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, useWindowDimensions, Image} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import Container from '../../components/Container';
import Label from '../../components/Label';
import ScreenHeader from '../../components/ScreenHeader';
import {appColors, shadow} from '../../utils/appColors';
import Feather from 'react-native-vector-icons/dist/Feather';
import { connect } from 'react-redux';
import { getOrders } from '../../redux/orderAction';
import { useFocusEffect } from '@react-navigation/native';
import { currencyFormat } from '../../utils/HelperFunctions';
import Spinner from '../../components/Spinner';
import { TabBar, TabView } from 'react-native-tab-view';
import { addToCart } from '../../redux/cartAction';

function Orders({loading, orderList, statusList, getOrders$, addToCart$, navigation}) {

  const OrderCard = ({order}) => {
    const {id, total, status, color, details} = order;

    if(details.length === 0) {
      return (<></>)
    }

    return (
      <View style={{
        flex: 1,
        borderBottomColor: appColors.lightGray,
        borderBottomWidth: 3,
      }}>
        <View style={{
          flexDirection: 'row',
          justifyContent: 'flex-start',
          borderBottomColor: appColors.lightGray,
          borderBottomWidth: 2.5,
          marginHorizontal: scale(5)
        }}>
          <Label
              text={statusList.order[status]}
              style={{
                fontFamily: 'OpenSans-Bold',
                fontSize: scale(14), 
                textTransform: 'uppercase',
                color: appColors.YELLOW,
                paddingVertical: scale(5)
              }}
            />
        </View>
        <View style={{
          flexDirection: 'row',
          marginHorizontal: scale(5),
          borderBottomColor: appColors.lightGray,
          borderBottomWidth: 2.5,
        }}>
          <FlatList
            listKey={'orp_' + id}
            keyExtractor={(item)=> `p_${id}_${item.name}_${id}`}
            ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
            data={details}
            renderItem={({item, index}) => (
              <View key={index} style={{
                flexDirection: 'row',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                marginVertical: scale(10),
                borderBottomWidth: .3,
                borderBottomColor: appColors.lightGray,
                borderStyle: 'dashed',
                paddingBottom: 10
              }}>
                
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  width: '70%'
                }}>
                  <Image source={{uri: item.image}} style={{
                    width: scale(60),
                    height: scale(60),
                  }} />
                  <View style={{
                    paddingHorizontal: scale(10),
                    justifyContent: 'flex-start',
                    // width: 250
                  }}>
                    <Text numberOfLines={1} style={{
                      fontFamily: 'OpenSans-Regular',
                      fontSize: scale(12),
                      flexShrink: 1,
                    }}>{item.name}</Text>
                  </View>
                </View>
                
                <View style={{
                      justifyContent: 'flex-end',
                      alignItems: 'flex-end',
                      width: '30%'
                    }}>
                      <Text style={{
                        fontFamily: 'Oswald-Bold',
                        textAlign: 'right'
                      }}>x{item.qty}</Text>
                      <Text style={{
                        fontFamily: 'Oswald-Bold',
                        textAlign: 'right',
                        fontSize: scale(14)
                      }}>{currencyFormat(item.price) + ' đ'}</Text>
                </View>
              </View>
              )
            }
          />
        </View>

        <View style={{
          flex: 1,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginHorizontal: scale(5),
        }}>
          <View style={{
            backgroundColor: appColors.YELLOW,
            borderRadius: scale(4),
            marginHorizontal: scale(5),
            marginVertical: scale(10)
          }}>
            <Pressable onPress={() => {
              details.forEach(it => {
                it.descriptions = {name: it.name};
                addToCart$({...it, quantity: it.qty});
              })
              
              navigation.navigate('Cart');
            }}>
              <Text style={{
                fontFamily: 'OpenSans-Bold',
                paddingHorizontal: scale(10),
                paddingVertical: scale(8),
                fontSize: scale(14)
              }}>Mua lần nữa</Text>
            </Pressable>
          </View>
          <View>
            <Text style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
            }}>Tổng tiền: <Text style={{
                fontFamily: 'Oswald-Bold',
                color: appColors.RED,
              }}>{currencyFormat(total) + ' đ'}</Text>
            </Text>
          </View>
        </View>
      </View>
    );
  };

  const layout = useWindowDimensions();
  const [index, setIndex] = useState(0);

  let routes = [
    {key: 'all', title: 'Tất cả', data: orderList},
  ];
  for (const key of Object.keys(statusList.order)) {
    routes.push({key: key, title: statusList.order[key], data: []});
  }

  routes.forEach(rout => {
    if(rout.key != 'all') {
      orderList.forEach(it => {
        if(typeof rout != 'undefined') {
          if(it.status == rout.key) {
            rout.data.push(it);
          }
        }
      })
    }
  });

  useFocusEffect(useCallback(() => {
    getOrders$({page: 1})
  }, []))
  
  const _renderHeader = () => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: scale(8),
          paddingHorizontal: scale(5)
        }}>
        <Pressable onPress={() => navigation.navigate('Shop')}>
          <Feather name="arrow-left" size={scale(20)} />
        </Pressable>

        <Label
          text={'Đơn hàng'}
          numberOfLines={1}
          style={{
            fontFamily: 'Oswald-Bold',
            flex: 1,
            fontSize: scale(16),
            marginLeft: scale(10)
          }}
        />
      </View>
    );
  };

  const renderTabBar = props => (
    <>
    <TabBar
      {...props}
      indicatorStyle={{ backgroundColor:appColors.ORANGE}}
      activeColor={appColors.BLACK}
      inactiveColor={appColors.BLACK}
      contentContainerStyle={{
      }}
      tabStyle={{
        width: 'auto'
      }}
      style={{ 
        backgroundColor: '#FFEADC', 
      }}
      labelStyle={{
        fontFamily: 'OpenSans-Bold',
        fontSize: scale(12),
        color: appColors.BLACK,
        textTransform: 'none'
      }}
    />
    </>
  );

  const renderFooter = () => {
    if(paging.current_page >= paging.last_page) return null;
  
    return (<View style={styles.footerText}>
            {loading && <Spinner />}
        </View>
      );
  }

  const renderScene = ({route}) => {
    // console.log(route)
      return (
        <View style={{
          flex: 1,
          justifyContent: 'space-between',
        }}>
            {(loading) ? <Spinner />
            :
            <FlatList
              listKey={'tab_' + route.key}
              keyExtractor={(item)=> `or_${route.key}_${item.id}`}
              ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
              data={route.data}
              renderItem={({item, indx}) => <OrderCard key={'tab_' + route.key} order={item} />}
              style={{
                marginTop: 15
              }}
            />
          }
        </View>
      );
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
      {_renderHeader()}
      <TabView
          renderTabBar={renderTabBar}
          navigationState={{ index, routes }}
          renderScene={renderScene}
          onIndexChange={setIndex}
          initialLayout={{ width: layout.width }}
          lazy={false}
          swipeEnabled
        />
    </SafeAreaView>
  );
  /*
  return (
    <Container  >
      <ScreenHeader navigation={navigation} label="Đơn hàng" />
      <View style={{paddingVertical: scale(20)}}>
        <Label
          text="Sept 23, 2021"
          style={{opacity: scale(0.5), fontSize: scale(13)}}
        />
      </View>
      <OrderCard
        item={{
          label: 'AMU - 9249296 - N',
          amount: '$3503',
          status: 'In transit',
          color: 'yellow',
        }}
      />
      <View style={{flex:1, paddingVertical:scale(20)}}>
      <View style={{paddingVertical: scale(20)}}>
        <Label
          text="Sept 23, 2021"
          style={{opacity: scale(0.5), fontSize: scale(13)}}
        />
      </View>

      <SafeAreaView style={{flex: 1}}></SafeAreaView>
      <FlatList
        keyExtractor={(item)=> `${item.label}_${new Date().getTime()}_${item.amount}`}
        ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
        data={orderList}
        renderItem={({item, index}) => <OrderCard key={index} item={item} />}
      />
      </View>
      
    </Container>
  );*/
}

const mapStateToProps = (state) => ({
  orderList: state.orders.orders,
  statusList: state.orders.status,
  loading: state.orders.loading
});
const mapDispatchToProps = {
 getOrders$: getOrders,
 addToCart$: addToCart,
};

export default connect(mapStateToProps, mapDispatchToProps)(Orders);

const styles = StyleSheet.create({
  contentContiner: {
    paddingVertical: scale(30),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(20),
    ...shadow,
  },
});
