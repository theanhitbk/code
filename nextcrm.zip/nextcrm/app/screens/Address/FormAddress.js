import React, { useCallback, useEffect, useState } from 'react'
import { View, Text, FlatList, SafeAreaView, Pressable } from 'react-native'
import { scale } from 'react-native-size-matters';
import RNPickerSelect from 'react-native-picker-select';
import TextInput from '../../components/TextInput';
import { ADD_ADDRESS_URL, UPDATE_ADDRESS_URL } from '../../services/config';
import { appColors } from '../../utils/appColors';
import Label from '../../components/Label';
import Feather from 'react-native-vector-icons/dist/Feather';
import { Checkbox } from 'react-native-paper';
import { AlertHelper } from '../../utils/AlertHelper';
import { useFocusEffect } from '@react-navigation/native';
import { connect } from 'react-redux';
import { addShippingAddress, getShippingAddress } from '../../redux/shippingAction';
import { getCities, getCommunes, getDistricts } from '../../redux/addressAction';
import { api } from '../../services/api';

function AddressForm({cities, districts, communes, 
    getShippingAddress$, getCommunes$, getDistricts$, 
    setRowEdited, setShowCreateForm, setVisible, row, navigation}) {

    const [isSelected, setSelection] = useState(false);
    const [u_name, onChangeUName] = useState(null);
    const [u_mobile, onChangeUMobile] = useState(null);
    const [u_email, onChangeUEmail] = useState(null);
    const [u_address, onChangeUAddress] = useState(null);
    const [u_note, onChangeUNote] = useState(null);

    const [city, setCity] = useState(null);
    const [cityValue, setCityValue] = useState(null);
    const [district, setDistrict] = useState(null)
    const [districtValue, setDistrictValue] = useState(null)
    const [commune, setCommune] = useState(null)
    const [communeValue, setCommuneValue] = useState(null)

    useFocusEffect(useCallback(() => {
        if(row) {
            onChangeUName(row.name)
            onChangeUMobile(row.phone)
            onChangeUEmail(row.email)
            onChangeUAddress(row.address)
            setCity(row.matp)
            setDistrict(row.maqh)
            setCommune(row.xaid)
            setCityValue(row.cityValue)
            setDistrictValue(row.districtValue)
            setCommuneValue(row.communeValue)
            setSelection(row.active === 0)
        }
    }, []));

    return (
        <View style={{
        marginHorizontal: scale(10)
        }}>
        <TextInput
            onChangeText={text => {onChangeUName(text);}}
            value={u_name}
            containerStyles={{
            marginVertical: scale(5)
            }}
            style={{
            borderColor: appColors.darkGray,
            }}
            editable
            placeholder={'Họ tên'}
        />
        <TextInput
            onChangeText={text => {onChangeUMobile(text);}}
            value={u_mobile}
            containerStyles={{
            marginVertical: scale(5)
            }}
            style={{borderColor: appColors.darkGray}}
            editable
            placeholder={'Số điện thoại'}
        />

        <TextInput
            onChangeText={text => {onChangeUEmail(text);}}
            value={u_email}
            containerStyles={{
            marginVertical: scale(5)
            }}
            style={{borderColor: appColors.darkGray}}
            editable
            placeholder={'Email'}
        />

        <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        }}>
            <View style={{
                borderColor: appColors.darkGray,
                borderWidth: 1,
                borderRadius: 4,
                marginVertical: scale(10),
                alignItems: 'center',
                width: '48%'
            }}>
                <RNPickerSelect
                    onValueChange={(value, index) => {
                        if(typeof cities[index-1] != 'undefined') {
                            setCity(value)
                            setCityValue(cities[index-1].label)
                            getDistricts$({matp: value})
                        }
                    }}
                    value={city}
                    items={cities}
                    placeholder={{label: 'Tỉnh / Thành phố'}}
                />
            </View>
            
            <View style={{
            borderColor: appColors.darkGray,
            borderWidth: 1,
            borderRadius: 4,
            marginVertical: scale(10),
            width: '48%'
            }}>
                <RNPickerSelect
                    onValueChange={(value, index) => {
                        if(typeof districts[index-1] != 'undefined') {
                            setDistrict(value)
                            setDistrictValue(districts[index-1].label)
                            getCommunes$({maqh: value})
                        }
                    }}
                    value={district}
                    items={districts??[]}
                    placeholder={{label: 'Quận / Huyện'}}
                />
            </View>
        </View>

            <View style={{
            borderColor: appColors.darkGray,
            borderWidth: 1,
            borderRadius: 4,
            marginVertical: scale(5)
            }}>
            <RNPickerSelect
                onValueChange={(value, index) => {
                    if(typeof communes[index-1] != 'undefined') {
                        setCommune(value)
                        setCommuneValue(communes[index-1].label)
                    }
                }}
                value={commune}
                items={communes??[]}
                placeholder={{label: 'Xã / Phường'}}
            />
            </View>

            <TextInput
            onChangeText={text => {onChangeUAddress(text);}}
            value={u_address}
            containerStyles={{
                marginVertical: scale(5)
            }}
            style={{borderColor: appColors.darkGray}}
            editable
            placeholder={'Địa chỉ'}
            />

            <View style={{
                flexDirection: 'row', 
                alignItems: 'center',
                marginVertical: scale(10),
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: appColors.lightGray,
                paddingVertical: scale(3)
            }}>
                <Checkbox
                status={(isSelected) ? 'checked' : 'unchecked'}
                onPress={() => {
                    setSelection(!isSelected)
                }}
                style={{justifyContent: 'flex-start'}}
                />
                <Label text={'Đặt làm địa chỉ mặc định'} style={{fontSize: scale(12)}} />
            </View>

            {row && row.active !== 0 && <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: scale(10),
                paddingBottom: scale(10)
            }}>
                <Text>Xoá địa chỉ</Text>
                <Pressable onPress={() => {
                    setVisible(true)
                }}>
                    <Feather name='trash' size={20} />
                </Pressable>
            </View>
            }

            <Pressable onPress={async () => {
                const formData = new FormData();
                if(row) {
                    formData.append("id", row.id)
                }

                formData.append("name", u_name)
                formData.append("phone", u_mobile)
                formData.append("email", u_email)
                formData.append("province", cityValue)
                formData.append("district", districtValue)
                formData.append("commune", communeValue)
                formData.append("address", u_address)
                formData.append("active", isSelected ? 0 : 1)

                try {
                    const result = await api.post(row ? UPDATE_ADDRESS_URL : ADD_ADDRESS_URL, formData, {crossDomain : true});
                    if(result.data.meta.status_code === 0) {
                        AlertHelper.show('success', result.data.meta.message);
                        getShippingAddress$();
                        setRowEdited(null)
                        setShowCreateForm(false)
                    } else {
                        AlertHelper.show('error', result.data.meta.message);
                    }
                } catch (error) {
                    console.log(error);
                    AlertHelper.show('error', 'Đã có lỗi xảy ra!');
                }
            }} 
            style={{
                backgroundColor: '#FE6700',
                borderColor: '#FE6700',
                borderWidth: .5,
                alignItems: 'center', 
                borderRadius: scale(5),
                marginBottom: scale(10)
            }}>
            <Text style={{
                paddingHorizontal: scale(12),
                paddingVertical: scale(10),
                fontSize: scale(16),
                fontFamily: 'Oswald-Bold',
                color: appColors.WHITE,
                textTransform: 'uppercase'
            }}>{row ? 'Cập nhật' : 'Thêm mới'}</Text>
            </Pressable>
        </View>
    )
}

const mapStateToProps = (state) => ({
    cities: state.address.cities,
    districts: state.address.districts,
    communes: state.address.communes
  });
  const mapDispatchToProps = {
    getShippingAddress$: getShippingAddress,
    getCities$: getCities, 
    getCommunes$: getCommunes, 
    getDistricts$: getDistricts,
    addShippingAddress$: addShippingAddress
  };
  
export default connect(mapStateToProps, mapDispatchToProps)(AddressForm);