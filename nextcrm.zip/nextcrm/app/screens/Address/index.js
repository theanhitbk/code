import React, { useEffect, useState } from 'react'
import { View, Text, FlatList, SafeAreaView, Pressable } from 'react-native'
import { scale } from 'react-native-size-matters'
import Label from '../../components/Label'
import { appColors } from '../../utils/appColors'
import Feather from 'react-native-vector-icons/dist/Feather'
import { connect } from 'react-redux'
import { addShippingAddress, getShippingAddress } from '../../redux/shippingAction'
import { getCities, getCommunes, getDistricts } from '../../redux/addressAction';
import { ScrollView } from 'react-native-gesture-handler'
import { Modal, ModalContent, ModalTitle, ModalFooter, ModalButton } from 'react-native-modals';
import { GET_ADDRESS_URL, REMOVE_ADDRESS_URL} from '../../services/config'
import { api } from '../../services/api'
import { AlertHelper } from '../../utils/AlertHelper'
import FormAddress from './FormAddress'

function Address({addressList, cities, districts, communes, 
  getShippingAddress$, getCities$, getCommunes$, getDistricts$, addShippingAddress$, navigation}) {

  const [row, setRowEdited] = useState();
  const [isSelected, setSelection] = useState(false);
  const [u_name, onChangeUName] = useState(null);
  const [u_mobile, onChangeUMobile] = useState(null);
  const [u_email, onChangeUEmail] = useState(null);
  const [u_address, onChangeUAddress] = useState(null);
  const [u_note, onChangeUNote] = useState(null);

  const [city, setCity] = useState(null);
  const [cityValue, setCityValue] = useState(null);
  const [district, setDistrict] = useState(null)
  const [districtValue, setDistrictValue] = useState(null)
  const [commune, setCommune] = useState(null)
  const [communeValue, setCommuneValue] = useState(null)

  const [visible, setVisible] = useState(false)
  const [showCreateForm, setShowCreateForm] = useState(false)

  useEffect(() => {
    getShippingAddress$()
    getCities$()
  }, []);

    const _renderHeader = () => {
        return (
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              paddingVertical: scale(10),
              paddingHorizontal: scale(15),
              borderBottomWidth: 3.5,
              borderBottomColor: appColors.lightGray
            }}>
            <Pressable onPress={() => row ? setRowEdited(null) : (showCreateForm ? setShowCreateForm(false) : navigation.navigate('Shop'))}>
              <Feather name="arrow-left" size={scale(24)} />
            </Pressable>
    
            <Label
              text={row ? 'Cập nhật địa chỉ nhận hàng' : (showCreateForm ? 'Thêm mới địa chỉ nhận hàng' : 'Địa chỉ Nhận hàng')}
              numberOfLines={1}
              style={{
                fontFamily: 'Oswald-Bold',
                flex: 1,
                fontSize: scale(16),
                marginLeft: scale(10)
              }}
            />
          </View>
        );
    };

    const _renderModal = () => {
      return (
        <Modal
          visible={visible}
          onTouchOutside={() => {
            setVisible(false)
          }}
          modalTitle={<ModalTitle title="Xoá địa chỉ" />}
          footer={
            <ModalFooter>
              <ModalButton
                text="Trở lại"
                textStyle={{
                  color: '#FE8800'
                }}
                onPress={() => setVisible(false)}
              />
              <ModalButton
                text="Đồng ý"
                textStyle={{
                  color: '#FE8800'
                }}
                onPress={async () => {
                  try {
                    const formData = new FormData();
                    formData.append("id", row.id)
                    const result = await api.post(REMOVE_ADDRESS_URL, formData, {crossDomain : true});
                    if(result.data.meta.status_code === 0) {
                      setRowEdited(null)
                      setVisible(false)
                      getShippingAddress$()
                    } else {
                      AlertHelper.show("error", result.data.meta.message);
                    }
                  } catch (error) {
                    AlertHelper.show("error", 'Đã có lỗi xảy ra.');
                  }
                }}
              />
            </ModalFooter>
          }
        >
          <ModalContent>
          <Text style={{
            fontFamily: 'OpenSans-Regular',
            fontSize: scale(14),
            alignItems: 'center',
            justifyContent: 'center',
            paddingTop: scale(20)
          }}>Bạn có chắc chắn muốn xoá địa chỉ này</Text>
          </ModalContent>
        </Modal>
      )
    };

    const _renderForm = () => {
      return (
        <ScrollView showsVerticalScrollIndicator={false}>
          <FormAddress row={row} setRowEdited={setRowEdited} 
            setShowCreateForm={setShowCreateForm} 
            setVisible={setVisible}
            navigation={navigation} />
        </ScrollView>
      )
    };

    const _renderCreateForm = () => {
      return (
        <ScrollView showsVerticalScrollIndicator={false}>
          <FormAddress setRowEdited={setRowEdited} setShowCreateForm={setShowCreateForm} navigation={navigation} />
        </ScrollView>
      )
    };

    return (
      <>
        <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
            {_renderHeader()}
            {!row && !showCreateForm && <FlatList
              showsVerticalScrollIndicator={false}
              //keyExtractor={({item, idx})=> `add_${idx}}`}
              ItemSeparatorComponent={() => <View style={{padding: scale(0)}} />}
              data={addressList}
              renderItem={({item, index}) => (
                  <View style={{
                      paddingHorizontal: scale(10),
                      paddingVertical: scale(10),
                      borderTopColor: '#bbbbbb',
                      borderTopWidth: index > 0 ? .3 : 0
                  }}>
                    <Pressable onPress={async () => {
                      try {
                        const result = await api.get(GET_ADDRESS_URL + item.id, {crossDomain : true});
                        if(result.data.meta.status_code === 0) {
                          let d = result.data.data;
                          d.id = item.id;
                          d.cityValue = item.province;
                          d.districtValue = item.district;
                          d.communeValue = item.commune;
                          setRowEdited(d)
                          onChangeUName(d.name)
                          onChangeUEmail(d.email)
                          onChangeUMobile(d.phone)
                          onChangeUAddress(d.address)
                          setCity(d.matp)
                          setCityValue(item.province)
                          setDistrict(d.maqh)
                          setDistrictValue(item.district)
                          setCommune(d.xaid)
                          setCommuneValue(item.commune)
                          setSelection(d.active === 0)
                        }
                      } catch (error) {
                        console.log(error);
                      }
                    }}
                    >
                      <View style={{
                        flexDirection: 'row',
                        justifyContent:'space-between'
                      }}>
                        <Text style={{
                          fontFamily: 'OpenSans-Bold',
                          fontSize: scale(14)
                        }}>
                          {item.name} {item.phone}
                        </Text>
                        {item.active === 0 && <Text style={{
                          backgroundColor: '#FE8600',
                          paddingHorizontal: scale(7),
                          paddingVertical: scale(3),
                          borderRadius: scale(4)
                        }}>Mặc định</Text>
                      }
                      </View>
                      <Text style={{
                        fontFamily: 'OpenSans-Regular',
                        fontSize: scale(14)
                      }}>{item.email}</Text>
                      <Text>{item.address}, {item.commune}, {item.district}, {item.province}</Text>
                    </Pressable>
                  </View>
              )}
            />
            }
            {row && _renderForm()}

            {showCreateForm && _renderCreateForm()}

        </SafeAreaView>
        {!row && !showCreateForm && <Pressable onPress={() => setShowCreateForm(true)} 
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: appColors.WHITE,
            borderTopColor: '#bbbbbb',
            borderTopWidth: .3,
          }}
        >
          <Text style={{
            fontFamily: 'OpenSans-Bold',
            fontSize: scale(12),
            paddingVertical: scale(15),
            paddingHorizontal: scale(10)
          }}>Thêm địa chỉ mới</Text>
          <Feather name='plus' size={20} style={{paddingRight: 10, fontFamily: 'OpenSans-Bold'}}/>
        </Pressable>
        }
         
        {_renderModal()}
         
      </> 
    )
}

const mapStateToProps = (state) => ({
    addressList: state.shippings.shippingAddress,
    loading: state.orders.loading,
    cities: state.address.cities,
    districts: state.address.districts,
    communes: state.address.communes
  });
  const mapDispatchToProps = {
    getShippingAddress$: getShippingAddress,
    getCities$: getCities, 
    getCommunes$: getCommunes, 
    getDistricts$: getDistricts,
    addShippingAddress$: addShippingAddress
  };
  
  export default connect(mapStateToProps, mapDispatchToProps)(Address);