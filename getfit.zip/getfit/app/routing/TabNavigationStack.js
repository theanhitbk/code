/**
 * @author Amusoftech <er.amudeep@gmail.com>
 * @description Minimal example of Tab Navigations
 */
 import React, { useEffect, useRef } from 'react';
import {Text, View} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createStackNavigator} from '@react-navigation/stack';
import {RoutesList} from './routes'; 
import {publicRoutes} from './publicRoutes'; 
import {appColors} from '../utils/appColors';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

export default function TabNavigationStack({isAuth}) {

  const navRef = useRef();
  
  const [routes, setRoutes] = React.useState( [...publicRoutes,...RoutesList ] )

  useEffect(() => {
    if (!isAuth) {
        navigation.navigate({ routeName: 'Welcome' })
    }
  }, [isAuth]);

  return (
    <NavigationContainer>
      <Tab.Navigator
        initialRouteName="FlashScreen"
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarInactiveTintColor: appColors.darkGray,
          tabBarActiveTintColor: appColors.ORANGE,
        })}
      >
        { routes?.map((route, key) => {
          const {name, component, options} = route;
          return (
            <Tab.Screen
              key={key}
              name={name}
              component={component}
              options={options}
            />
          );
        })}
      </Tab.Navigator>
    </NavigationContainer>
  );
}
