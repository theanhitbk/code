import React from 'react';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import {addToCart} from '../redux/cartAction';
import {getFeaturedProducts, getProduct, getProducts, searchKeyword} from '../redux/productAction';
import { checkPhone, fetchUserInfo, login, logout, resetPassword, sendOtp, verifyOtp } from '../redux/loginAction';
import { addBooking, getBook, getBooks, getMemberBranchs, getMemberOrders, getPTList, getPTSchedules, removeBooking, resetOldBook, updateBooking } from '../redux/bookAction';
import { getHomeDatas } from '../redux/homeAction';
import { getCategories, getCmsCategories, getDetailCategory, getDetailPostCategory, getHotCategories } from '../redux/categoryAction';
import { getShippingAddress } from '../redux/shippingAction';

export const mapStateToProps = (state) => ({
    config: state.home.config,
    ptList: state.book.ptList,
    ptSchedules: state.book.ptSchedules,
    userInfo: state.login.userInfo,
    isLoggedIn: state.login.isLoggedIn,
    branchList: state.book.branchList,
    orderList: state.book.orderList,
    // productList: state.products.products,
    featuredProductList: state.products.featuredProducts,
    categoryList: state.categories.categories,
    hotCategoryList: state.categories.hotCategories,
    categories : state.categories.cmsCategories,
    cartItems : state.cart.cartItems,
    book: state.book.book,
    books: state.book.books
});

export const mapDispatchToProps = {
  login$: login,
  logout: logout,
  checkPhone: checkPhone,
  verifyOtp: verifyOtp,
  sendOtp: sendOtp,
  resetPassword: resetPassword,
  fetchUserInfo$: fetchUserInfo,
  getMemberBranchs: getMemberBranchs,
  getMemberOrders: getMemberOrders,
  getHomeDatas: getHomeDatas,
  addToCart$: addToCart,
  getProducts$: getProducts,
  getProduct$: getProduct,
  getFeaturedProducts: getFeaturedProducts,
  getCategories: getCategories,
  getHotCategories$: getHotCategories,
  getPTList: getPTList,
  getPTSchedules: getPTSchedules,
  getBooks$: getBooks,
  getBook$: getBook,
  addBooking$: addBooking,
  updateBooking$: updateBooking,
  resetBook$: resetOldBook,
  getCmsCategories$: getCmsCategories,
  getDetailCategory$: getDetailCategory,
  getDetailPostCategory$: getDetailPostCategory,
  removeBooking$: removeBooking,
  getShippingAddress$: getShippingAddress,
  searchKeyword$: searchKeyword,
};

export const hocComponentName = (WrappedComponent) => {
  const hocComponent = ({...props}) => <WrappedComponent {...props} />;

  hocComponent.propTypes = {};
  return hocComponent;
};

export default (ReduxWrapper) =>
  connect(mapStateToProps, mapDispatchToProps)(hocComponentName(ReduxWrapper));
