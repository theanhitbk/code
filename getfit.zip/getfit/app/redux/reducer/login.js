import { LOGIN, SET_USER_INFO, FETCH_USER_INFO, 
    LOGIN_REQUESTING, LOGIN_SUCCESS, LOGIN_ERROR, LOGOUT 
} from '../actionTypes';
const intiialState = {
    requesting: false,
    successful: false,
    messages: [],
    errors: [],
    isLoggedIn: false,
    userInfo :{}
}


export default function (state =intiialState,action) {
    const {type, payload} =action

    switch (type) {
        case LOGIN_REQUESTING:
            return {
                ...state,
                requesting: true,
                successful: false,
                messages: [{ body: 'Logging in...', time: new Date() }],
                errors: [],
            }
        case LOGIN_SUCCESS:
        case LOGIN:
            return {
                ...state,
                // errors: [],
                // messages: [],
                requesting: false,
                successful: true,
                isLoggedIn: false,
            }
        case LOGIN_ERROR:
            return {
                ...state,
                // errors: state.errors.concat([{
                //     body: action.error.toString(),
                //     time: new Date(),
                // }]),
                // messages: [],
                requesting: false,
                isLoggedIn: false,
                successful: false,
            }
        case SET_USER_INFO:
            return  {
                ...state,
                isLoggedIn: true,
                userInfo : {...payload}
            }
        case LOGOUT:
            return {
                ...state,
                isLoggedIn: false,
                userInfo: {}
            }
        default:
            return state
    }
    
} 