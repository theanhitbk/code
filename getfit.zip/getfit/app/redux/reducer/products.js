import { GET_PRODUCTS, GET_PRODUCTS_FAILURE, SEARCH_KEYWORDS, SEARCH_PRODUCTS, SET_FEATURED_PRODUCTS, SET_PRODUCT, SET_PRODUCTS, SET_PRODUCTS_END, SET_SEARCH_KEYWORDS, SET_SEARCH_PRODUCTS } from "../productAction";

const initialState = {
    routes: [],
    subCategories: [],
    products :[],
    product: {},
    featuredProducts: [],
    searchResultProducts: [],
    loading: false,
    moreLoading: false,
    isListEnd: false,
    paging: {},
    isSearchloading: false,
    imageList: [],
    keywords: []
}

export default (state = initialState, action) => {
    const {type,payload, params} =action
    
    switch (type) {
        case GET_PRODUCTS:
            if(payload.page === 1 ) {
                return {
                    ...state,
                    loading: true,
                    products: [],
                    subCategories: [],
                    paging: {},
                };
            }

            return {
                ...state, 
                moreLoading: true
            }
        case SET_PRODUCTS: 
            if(params.route_refresh === true) {
                let routes = [{key: params.category_id, title: 'Tất cả'}];

                payload.sub_category.forEach(element => {
                    routes.push({key: element.id, title: element.title})
                });
                
                return {
                    ...state,
                    routes: routes,
                    subCategories: routes, //[...payload.sub_category],
                    products : [...state.products, ...payload.data],
                    paging: {...payload.paging},
                    loading: false,
                    moreLoading: false,
                };
            }
            
            return {
                ...state,
                subCategories: params.subCategories??[],
                products : [...state.products, ...payload.data],
                paging: {...payload.paging},
                loading: false,
                moreLoading: false,
            };
        case SET_PRODUCTS_END: 
            if(params.route_refresh === true) {
                let routes = [{key: params.category_id, title: 'Tất cả'}];
                return {
                    ...state,
                    isListEnd: true,
                    loading: false,
                    moreLoading: false,
                    subCategories: params.subCategories??[],
                    routes: routes
                };
            }

            return {
                ...state,
                isListEnd: true,
                loading: false,
                moreLoading: false,
                subCategories: params.subCategories??[],
            };

        case SET_PRODUCT: 
            return {
                ...state,
                product : {...payload},
                imageList: [{image: payload.image??''}]
            };
        case SET_FEATURED_PRODUCTS: 
            return {
                ...state,
                featuredProducts : [...payload]
            };
        case SEARCH_PRODUCTS:
            return {
                ...state,
                isSearchloading: true
            };
        case SET_SEARCH_PRODUCTS:
            return {
                ...state,
                isSearchloading: false,
                searchResultProducts: [...payload]
            }
        case GET_PRODUCTS_FAILURE:
            return initialState;
        case SEARCH_KEYWORDS:
            return state;
        case SET_SEARCH_KEYWORDS:
            return {
                ...state,
                keywords: [...payload]
            }
        default:
            return state;
    }
};