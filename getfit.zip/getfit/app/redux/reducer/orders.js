import { GET_ORDERS, GET_ORDERS_FAILURE, SEARCH_ORDERS, 
    SET_ORDER, SET_ORDERS, SET_ORDERS_END, SET_SEARCH_ORDERS 
} from "../orderAction";

const initialState = {
    orders :[],
    order: {},
    searchResultOrders: [],
    loading: false,
    moreLoading: false,
    isListEnd: false,
    paging: {},
    isSearchloading: false,
    status: {
        order: [],
        payment: [],
        shipping: []
    }
}

export default (state = initialState, action) => {
    const {type,payload, params} =action
    switch (type) {
        case GET_ORDERS:
            console.log(payload);
            if(params.page === 1 ) {
                return {
                    ...state,
                    loading: true,
                    orders: [],
                    paging: {}
                };
            }

            return {
                ...state, 
                moreLoading: true
            }
        case SET_ORDERS: 
            return {
                ...state,
                orders : [...state.orders, ...payload.data],
                status: {
                    order: {...payload.statusOrder},
                    payment: {...payload.statusPayment},
                    shipping: {...payload.statusShipping},
                },
                //paging: {...payload.paging},
                loading: false,
                moreLoading: false,
            };
        case SET_ORDERS_END: 
            return {
                ...state,
                isListEnd: true,
                loading: false,
                moreLoading: false
            };
        case SET_ORDER: 
            return {
                ...state,
                order : {...payload}
            };
        
        case SEARCH_ORDERS:
            return {
                ...state,
                isSearchloading: true
            };
        case SET_SEARCH_ORDERS:
            return {
                ...state,
                isSearchloading: false,
                searchResultOrders: [...payload]
            }
        case GET_ORDERS_FAILURE:
            return initialState;
        default:
            return state;
    }
};