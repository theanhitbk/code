import { ADD_TO_CART, CLEAR_CART, REMOVE_FROM_CART, UPDATE_FROM_CART } from "../cartAction"; //action

const initialState = {
    cartItems :[],
    totalPrice: 0
}


export default function (state =initialState,action) {
const {type, payload} =action
    switch (type) {
        case ADD_TO_CART: 
            const item = state.cartItems.find(
                product => product.id === payload.id,
            );
        
          if (item) {
            return {
              ...state,
              cartItems: state.cartItems.map(item => item.id === payload.id
                ? {
                  ...item,
                  quantity: item.quantity + 1,
                }
                : item
              ),
              totalPrice: state.totalPrice + payload.price,
            };
          }
        
            return  {
                ...state,
                cartItems : [...state.cartItems, payload],
                totalPrice: state.totalPrice + payload.price,
            }

        case REMOVE_FROM_CART:
            return {
                ...state,
                cartItems: state.cartItems.filter(
                    cartItem => cartItem !== payload,
                ),
                totalPrice: state.totalPrice - payload.price,
            };

        case UPDATE_FROM_CART:
            const it = state.cartItems.find(
                product => product.id === payload.id,
            );

            if (it) {
                return {
                  ...state,
                  cartItems: state.cartItems.map(item => item.id === payload.id
                    ? {
                      ...item,
                      quantity: item.quantity + payload.quantity,
                    }
                    : item
                  ),
                  totalPrice: state.totalPrice + (payload.price * payload.quantity),
                };
            }

        case CLEAR_CART:
            return initialState;
            //return {...state,cartItems: [], totalPrice: 0};
        default:
            return state
    }
    
} 