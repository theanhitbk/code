import { SET_HOMES } from "../homeAction";

const intiialState = {
    config: {}
}

export default (state = intiialState, action) => {
    const {type,payload} =action
    switch (type) {
        case SET_HOMES : 
            return  {
                ...state,
                config: {...payload}
            }
        default:
            return state;
    }
};