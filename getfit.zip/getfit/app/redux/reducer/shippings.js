import { SET_SHIPPING, SET_SHIPPING_ADDRESS } from "../shippingAction";

const intialState = {
    shippings :[],
    shippingAddress: []
}

export default (state = intialState, action) => {
    const {type,payload} =action
    switch (type) {
        case SET_SHIPPING: 
            return {
                ...state,
                shippings : [...payload]
            };
        case SET_SHIPPING_ADDRESS: 
            return {
                ...state,
                shippingAddress : payload
            };
        default:
            return state;
    }
};