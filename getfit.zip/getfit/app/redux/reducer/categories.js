import { SET_CATEGORIES, SET_CMS_CATEGORIES, SET_DETAIL_POST_CATEGORY, SET_HOT_CATEGORIES, SET_POSTS_CATEGORY } from "../categoryAction";

const intialState = {
    categories :[],
    hotCategories :[],
    cmsCategories: [],
    cmsPostCategories: [],
    cmsPost: {}
}

export default (state = intialState, action) => {
    const {type,payload} =action
    switch (type) {
        case SET_CATEGORIES : 
            return {
                ...state,
                categories : [...payload]
            };
        case SET_HOT_CATEGORIES: 
            return {
                ...state,
                hotCategories : [...payload]
            };
        case SET_CMS_CATEGORIES:
            return {
                ...state,
                cmsCategories : [...payload]
            };
        case SET_POSTS_CATEGORY:
            return {
                ...state,
                cmsPostCategories : [...payload]
            };
        case SET_DETAIL_POST_CATEGORY:
            return {
                ...state,
                cmsPost : {...payload}
            };
        default:
            return state;
    }
};