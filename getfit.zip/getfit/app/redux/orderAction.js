export const GET_ORDER="GET_ORDER"
export const SET_ORDER="SET_ORDER"
export const GET_ORDERS="GET_ORDERS"
export const SET_ORDERS="SET_ORDERS"
export const SET_ORDERS_END="SET_ORDERS_END"
export const GET_ORDERS_FAILURE='GET_ORDERS_FAILURE'

export const SEARCH_ORDERS="SEARCH_ORDERS";
export const SET_SEARCH_ORDERS="SET_SEARCH_ORDERS";

export const getOrders = (params)=>({
    type: GET_ORDERS,
    params: params,
})

export const getOrder = (id)=>({
    type: GET_ORDER,
    payload: id
})

export const searchOrder = (params) => ({
    type: SEARCH_ORDERS,
    params: params
})