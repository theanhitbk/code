import {  all } from "redux-saga/effects"
import { watcherGetCities, watcherGetCommunes, watcherGetDistricts } from "./saga/addressSaga"
import { watcherBooking, watcherGetBook, watcherGetBooks, watcherGetMemberBranchs, watcherGetMemberOrders, watcherGetPTList, watcherGetPTSchedules, watcherRemoveBooking, watcherUpdateBooking } from "./saga/bookSaga"
import { watcherGetCategories, watcherGetCmsCategories, watcherGetCmsCategory, watcherGetCmsPost, watcherGetHotCategories } from "./saga/categorySaga"
import { workerGetError } from "./saga/errorSaga"
import { watcherGetHomeDatas } from "./saga/homeSaga"
import { watcherCheckPhone, watcherFetchUserInfo, watcherLogin, watcherResetPassword, watcherSendOtp, watcherVerifyOtp } from "./saga/loginSaga"
import { watcherGetOrders } from "./saga/orderSaga"
import { watcherGetFeaturedProducts, watcherGetProduct, watcherGetProducts, watcherSearchKeywords, watcherSearchProducts } from "./saga/productSaga"
import { watcherAddShipping, watcherGetShippingAddress, watcherGetShippingMethods } from "./saga/shippingSaga"


//1 worker saga
export function* loadMenuQWorker() {

}
//2 watcher saga
export function* watchLoadMenu() {

}
//3 root saga
//single entry point to start all sagas
export default function* rootSaga() {
  yield all([
    workerGetError(),
    watcherLogin(),
    watcherGetHomeDatas(),
    watcherCheckPhone(),
    watcherVerifyOtp(),
    watcherSendOtp(),
    watcherResetPassword(),
    watcherFetchUserInfo(),
    watcherGetMemberBranchs(),
    watcherGetMemberOrders(),
    watcherGetProducts(),
    watcherGetFeaturedProducts(),
    watcherGetCategories(),
    watcherGetHotCategories(),
    watcherGetPTList(),
    watcherGetPTSchedules(),
    watcherBooking(),
    watcherUpdateBooking(),
    watcherGetBook(),
    watcherGetBooks(),
    watcherRemoveBooking(),
    watcherGetShippingMethods(),
    watcherGetCmsCategories(),
    watcherGetCmsCategory(),
    watcherGetCmsPost(),
    watcherGetProduct(),
    watcherSearchProducts(),
    watcherGetOrders(),
    watcherGetShippingAddress(),
    watcherAddShipping(),
    watcherGetCities(),
    watcherGetDistricts(),
    watcherGetCommunes(),
    watcherSearchKeywords()
  ])
}
