export const GET_PRODUCT="GET_PRODUCT"
export const SET_PRODUCT="SET_PRODUCT"
export const GET_PRODUCTS="GET_PRODUCTS"
export const SET_PRODUCTS="SET_PRODUCTS"
export const SET_PRODUCTS_END="SET_PRODUCTS_END"
export const GET_PRODUCTS_FAILURE='GET_PRODUCTS_FAILURE'

export const GET_FEATURED_PRODUCTS="GET_FEATURED_PRODUCTS"
export const SET_FEATURED_PRODUCTS="SET_FEATURED_PRODUCTS"

export const SEARCH_PRODUCTS="SEARCH_PRODUCTS";
export const SET_SEARCH_PRODUCTS="SET_SEARCH_PRODUCTS";

export const SET_SEARCH_KEYWORDS="SET_SEARCH_KEYWORDS";
export const SEARCH_KEYWORDS="SEARCH_KEYWORDS"

export const getProducts = (params)=>({
    type: GET_PRODUCTS,
    params: params,
    payload: params
})

export const getProduct = (id)=>({
    type: GET_PRODUCT,
    payload: id
})

export const getFeaturedProducts = ()=>({
    type: GET_FEATURED_PRODUCTS,
})

export const searchProduct = (params) => ({
    type: SEARCH_PRODUCTS,
    params: params
})

export const searchKeyword = () => ({
    type: SEARCH_KEYWORDS,
})