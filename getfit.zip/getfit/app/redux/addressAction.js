export const GET_CITIES= "GET_CITIES" // ACTION TYPE 
export const SET_CITIES = 'SET_CITIES'

export const SET_DISTRICTS='SET_DISTRICTS'
export const GET_DISTRICTS='GET_DISTRICTS'

export const SET_COMMUNES='SET_COMMUNES'
export const GET_COMMUNES='GET_COMMUNES'

export const getCities = ()=>({
    type: GET_CITIES,
})

export const getDistricts = (params)=>({
    type: GET_DISTRICTS,
    params: params
})

export const getCommunes = (params)=>({
    type: GET_COMMUNES,
    params: params
})
