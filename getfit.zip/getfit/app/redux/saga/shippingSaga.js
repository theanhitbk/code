import { call, put, takeLatest } from 'redux-saga/effects'
import * as shipApis from '../../services/shippingApis';
import { ADD_SHIPPING_ADDRESS, GET_SHIPPING, GET_SHIPPING_ADDRESS, SET_SHIPPING, SET_SHIPPING_ADDRESS } from '../shippingAction';
 
export function* workerGetShippingMethods(action) {
  try {
    const result = yield call(shipApis.getShippings, action.params)
    yield put({type: SET_SHIPPING, payload: result.data.shippingMethod})
  } catch (error) {
    console.log(error);
    yield put({type: SET_SHIPPING, payload: []})
  }
  
}
export function* watcherGetShippingMethods() {
  yield takeLatest(GET_SHIPPING, workerGetShippingMethods)
}

export function* workerGetShippingAddress(action) {
  try {
    const result = yield call(shipApis.getShippingAddress, action.params)
    yield put({type: SET_SHIPPING_ADDRESS, payload: result.data})
  } catch (error) {
    console.log(error);
    yield put({type: SET_SHIPPING_ADDRESS, payload: []})
  }
  
}
export function* watcherGetShippingAddress() {
  yield takeLatest(GET_SHIPPING_ADDRESS, workerGetShippingAddress)
}

export function* addShippingAddress(action) {
  try {
      const result = yield call(shipApis.addShippingAddress, action.params)
      if(result.meta.status_code === 0 && typeof result.data.error == 'undefined') {
          action.onSuccess(result)
          // yield put(setUserInfo(result.data.user))
      } else if(typeof result.data.error != 'undefined') {
          action.onError(result.data.msg)    
      }
  } catch (error) {
      action.onError(error)
  }
}

export function* watcherAddShipping() {
  yield takeLatest(ADD_SHIPPING_ADDRESS, addShippingAddress)
}