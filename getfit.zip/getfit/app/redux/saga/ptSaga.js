import { put, call, fork, takeLatest } from 'redux-saga/effects';
import { GET_PTS,SET_PTS } from '../ptAction'
import RequestMake from '../../utils/RequestMake'
import * as ptApis from '../../services/ptApis';

export function* workerGetPts(action) {
  if (action) {
      const category =action.payload
      // const URL=`${PRODUCTS_BY_CATEGORY}/${category}`
      // console.log({URL});
      //const result = yield RequestMake(URL)
      const result = yield call(ptApis.getPts, action.params) 
      yield put({ type:SET_PTS, payload: result })
  }
}
export function* watcherGetPts() {
  yield takeLatest(GET_PTS,workerGetPts)
}