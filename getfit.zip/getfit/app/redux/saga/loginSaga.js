import { put, call, fork, takeLatest } from 'redux-saga/effects';
import * as types from '../actionTypes';
import * as loginApis from '../../services/loginApis';
import { setUserInfo } from '../loginAction';
import { saveToken } from '../../utils/storage';

export function* login(action) {
    try {
        const result = yield call(loginApis.login, action.params)
        if(result.meta.status_code === 0 && typeof result.data.error == 'undefined') {
            action.onSuccess(result)
            saveToken(result.data.access_token || '');
            yield put(setUserInfo(result.data.user))
        } else if(typeof result.data.error != 'undefined') {
            action.onError(result.data.msg)    
        }
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherLogin() {
    yield takeLatest(types.LOGIN, login)
}

export function* checkPhone(action) {
    try {
        const result = yield call(loginApis.checkPhone, action.params)
        if(result.meta.status_code === 0) {
            action.onSuccess(result)
        } else {
            action.onError(result.meta.message)    
        }
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherCheckPhone() {
    yield takeLatest(types.CHECK_PHONE, checkPhone)
}

export function* verifyOtp(action) {
    try {
        const result = yield call(loginApis.verifyOtp, action.params)
        if(result.meta.status_code === 0 && result.data.error === 0) {
            action.onSuccess(result)
        } else {
            action.onError(result.meta.message)    
        }
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherVerifyOtp() {
    yield takeLatest(types.VERIFY_OTP, verifyOtp)
}

export function* sendOtp(action) {
    try {
        const result = yield call(loginApis.sendOtp, action.params)
        if(result.meta.status_code === 0 && result.data.error === 0) {
            action.onSuccess(result)
        } else {
            action.onError(result.meta.message)    
        }
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherSendOtp() {
    yield takeLatest(types.SEND_OTP, sendOtp)
}

export function* resetPassword(action) {
    try {
        const result = yield call(loginApis.resetPassword, action.params)
        if(result.meta.status_code === 0 && typeof result.data.error == 'undefined') {
            action.onSuccess(result)
            saveToken(result.data.access_token || '');
            yield put(setUserInfo(result.data.user))
        } else if(typeof result.data.error != 'undefined') {
            action.onError(result.data.msg)    
        }
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherResetPassword() {
    yield takeLatest(types.RESET_PASSWORD, resetPassword)
}

export function* workerFetchUserInfo(action) {
    try {
        const result = yield call(loginApis.fetchUserInfo)
        const data = result.data
        action.onSuccess(data)
        yield put(setUserInfo(data))
    } catch (error) {
        action.onError(error)
    }
}

export function* watcherFetchUserInfo() {
    yield takeLatest(types.FETCH_USER_INFO, workerFetchUserInfo)
}

export function* logout () {  
    yield takeLatest(types.LOGOUT)
}