import { put, call, fork, takeLatest } from 'redux-saga/effects';
import { GET_FEATURED_PRODUCTS, GET_PRODUCT, GET_PRODUCTS,GET_PRODUCTS_FAILURE,SEARCH_KEYWORDS,SEARCH_PRODUCTS,SET_FEATURED_PRODUCTS,SET_PRODUCT,SET_PRODUCTS, SET_PRODUCTS_END, SET_SEARCH_KEYWORDS, SET_SEARCH_PRODUCTS } from '../productAction';
import * as productApis from '../../services/productApis';

export function* workerGetProducts(action) {
  try {
      const result = yield call(productApis.getProducts, action.params) 
      if(result.data.length > 0) {
        yield put({ type:SET_PRODUCTS, payload: result, params: action.params })
      } else {
        yield put({ type:SET_PRODUCTS_END, payload: result, params: action.params })
      }
  } catch(error) {
    yield put({ type:GET_PRODUCTS_FAILURE })
  }
}
export function* watcherGetProducts() {
  yield takeLatest(GET_PRODUCTS, workerGetProducts)
}

export function* workerGetProduct(action) {
  try {
      const result = yield call(productApis.getProduct, action.payload) 
      yield put({ type:SET_PRODUCT, payload: result })
  } catch (error) {
    yield put({ type:SET_PRODUCT, payload: null })
  }
}
export function* watcherGetProduct() {
  yield takeLatest(GET_PRODUCT,workerGetProduct)
}

export function* workerGetFeaturedProducts(action) {
  try {
      const result = yield call(productApis.getFeaturedProducts, action.payload) 
      yield put({ type:SET_FEATURED_PRODUCTS, payload: result })
  } catch (error) {
    yield put({ type:SET_FEATURED_PRODUCTS, payload: [] })
  }
}
export function* watcherGetFeaturedProducts() {
  yield takeLatest(GET_FEATURED_PRODUCTS, workerGetFeaturedProducts)
}

export function* workerSearchProducts(action) {
  try {
      if(action.params.keyword.length === 0) {
        yield put({ type:SET_SEARCH_PRODUCTS, payload: [] })
      } else {
        const result = yield call(productApis.searchProducts, action.params) 
        yield put({ type:SET_SEARCH_PRODUCTS, payload: result })
      }
  } catch (error) {
    yield put({ type:SET_SEARCH_PRODUCTS, payload: [] })
  }
}
export function* watcherSearchProducts() {
  yield takeLatest(SEARCH_PRODUCTS, workerSearchProducts)
}

export function* workerSearchKeywords(action) {
  try {
      const result = yield call(productApis.searchKeywords, action.params) 
      yield put({ type:SET_SEARCH_KEYWORDS, payload: result })
  } catch (error) {
    yield put({ type:SET_SEARCH_KEYWORDS, payload: [] })
  }
}
export function* watcherSearchKeywords() {
  yield takeLatest(SEARCH_KEYWORDS, workerSearchKeywords)
}