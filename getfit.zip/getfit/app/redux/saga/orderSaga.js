import { put, call, fork, takeLatest } from 'redux-saga/effects';
import { GET_ORDER, GET_ORDERS,GET_ORDERS_FAILURE,SEARCH_ORDERS,SET_ORDER,SET_ORDERS, SET_ORDERS_END, SET_SEARCH_ORDERS } from '../orderAction';
import * as orderApis from '../../services/orderApis';

export function* workerGetOrders(action) {
  try {
      const result = yield call(orderApis.getOrders, action.params) 
      if(result.data.length > 0) {
        yield put({ type:SET_ORDERS, payload: result })
      } else {
        yield put({ type:SET_ORDERS_END, payload: result })
      }
  } catch(error) {
    yield put({ type:GET_ORDERS_FAILURE })
  }
}
export function* watcherGetOrders() {
  yield takeLatest(GET_ORDERS, workerGetOrders)
}

export function* workerGetOrder(action) {
  if (action) {
      const result = yield call(orderApis.getOrder, action.payload) 
      yield put({ type:SET_ORDER, payload: result })
  }
}
export function* watcherGetOrder() {
  yield takeLatest(GET_ORDER,workerGetProduct)
}

export function* workerSearchOrders(action) {
  try {
      if(action.params.keyword.length === 0) {
        yield put({ type:SET_SEARCH_ORDERS, payload: [] })
      } else {
        const result = yield call(orderApis.searchOrders, action.params) 
        yield put({ type:SET_SEARCH_ORDERS, payload: result })
      }
  } catch (error) {
    yield put({ type:SET_SEARCH_ORDERS, payload: [] })
  }
}
export function* watcherSearchOrders() {
  yield takeLatest(SEARCH_ORDERS, workerSearchOrders)
}