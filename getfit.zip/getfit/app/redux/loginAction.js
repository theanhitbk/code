import { LOGIN, SET_USER_INFO, FETCH_USER_INFO, LOGOUT, CHECK_PHONE, RESET_PASSWORD, VERIFY_OTP, SEND_OTP 
} from './actionTypes';

export const loginRequest = ( params ) => ({  
      type: LOGIN_REQUESTING,
      params
})

export const login = (params, onSuccess, onError) => ({
    type: LOGIN,
    params,
    onSuccess,
    onError
})

export const checkPhone = (params, onSuccess, onError) => ({
    type: CHECK_PHONE,
    params,
    onSuccess,
    onError
})

export const sendOtp = (params, onSuccess, onError) => ({
    type: SEND_OTP,
    params,
    onSuccess,
    onError
})

export const verifyOtp = (params, onSuccess, onError) => ({
    type: VERIFY_OTP,
    params,
    onSuccess,
    onError
})

export const resetPassword = (params, onSuccess, onError) => ({
    type: RESET_PASSWORD,
    params,
    onSuccess,
    onError
})

export const logout = () => ({
    type: LOGOUT
})
/**
 * 
 * @param {*} data 
 * @returns 
 * @description set user info action
 */
 export const setUserInfo = (data)=>({
    type: SET_USER_INFO,
    payload : data
}) 

export const fetchUserInfo = (onSuccess, onError) => ({
    type: FETCH_USER_INFO,
    onSuccess,
    onError
})
