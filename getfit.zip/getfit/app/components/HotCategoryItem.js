import { CommonActions } from '@react-navigation/native';
import React from 'react';
import { Image, Pressable, Text, TouchableOpacity, View } from 'react-native';
import { scale } from 'react-native-size-matters';
import { appColors, shadow } from '../utils/appColors';

export class HotCategoryItem extends React.PureComponent {
  
    render() {
      return (
          <View style={{
              alignItems: 'center',
              width: '25%',
              padding: scale(2)
          }}>
            <Pressable
                onPress={() => {
                  console.log('iddddd:::', this.props.category.id)
                  this.props.getProducts({category_id: this.props.category.id, page: 1, route_refresh: true})
                  //this.props.navigation.navigate('Category', {item: this.props.category})
                  
                  const resetAction = CommonActions.reset({
                    index: 0,
                    routes: [
                      {
                        name: 'Category',
                        params: {item: this.props.category},
                        key: null // THIS LINE
                      }
                    ],
                    
                  })
                  this.props.navigation.dispatch(resetAction);
                }}
                rippleColor={appColors.primary}
                rippleContainerBorderRadius={scale(40)}
                rippleDuration={800}
                style={{
                ...shadow,
                backgroundColor: appColors.WHITE,
                height: scale(70),
                width: scale(70),
                justifyContent: 'space-between',
                alignItems: 'center',
                borderRadius: scale(40),
                }}>
                <Image source={{uri: this.props.category.image}} 
                style={{
                    flex: 1, 
                    borderRadius: 50, 
                    // resizeMode: 'cover', 
                    alignSelf: 'stretch', 
                    width: null,
                }}/>
            </Pressable>
            <View style={{marginTop: scale(10), flex: 1}}>
                <Text numberOfLines={1} 
                    style={{fontFamily: 'OpenSans-Medium',fontSize: scale(12), flexShrink: 1}} 
                >{this.props.category.title}</Text>
            </View>
          </View>
      )
  }
}
