import { CommonActions } from '@react-navigation/native';
import React from 'react';
import {View, Text, Pressable, Image, Dimensions, ImageBackground} from 'react-native';
import {scale} from 'react-native-size-matters';
import { connect } from 'react-redux';
import { getProduct } from '../redux/productAction';
import {appColors} from '../utils/appColors';
import { currencyFormat } from '../utils/HelperFunctions';
import Label from './Label';

function ProductCard({getProduct$, navigation, item, isHorizontal}) {
  
  const {descriptions, price, price_promotion, image, isNew, id} = item;

  const width = (Dimensions.get('window').width) / 2;

  return (
    <Pressable onPress={() => {
      getProduct$(id)
      console.log('idddd', id)
      // const resetAction = CommonActions.reset({
      //   index: 0,
      //   routes: [
      //     {
      //       name: 'ProductDetails',
      //       params: {item: item},
      //       key: null // THIS LINE
      //     }
      //   ],
        
      // })
      // navigation.dispatch(resetAction);
      navigation.navigate('ProductDetails',{item})
    }}>
      
      <View
        style={{
          width: width,
          flex:1,
          borderColor:appColors.lightGray,
          borderWidth: scale(.7),
          position: 'relative',
          // borderBottomWidth: scale(2),
          marginVertical: scale(isHorizontal ? 10 : 0)
        }}>
          {price_promotion && price_promotion < price &&
            <View style={{
              position: 'absolute',
              top: scale(isHorizontal ? -21 : 0),
              right: scale(10),
              zIndex: 20,
              alignItems: 'center',
            }}>
              <Image source={require('../static/images/icon-sale.png')} 
                style={{
                  width: scale(60),
                  height: scale(60),
                }}
              />
              <Text style={{
                position: 'absolute',
                top: scale(18),
                right: scale(7),
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(16),
                color: appColors.WHITE
              }}>{Math.round(((price - price_promotion) /price) * 100)}%</Text>
            </View>
          }

          <View style={{
            flex: 1,
            flexDirection: 'row',
            height: scale(180),
            // width: scale(240),
            // padding: scale(5)
          }}>
            <ImageBackground source={{uri: image}} //resizeMode="stretch"
              style={{
                flex: 1,
                justifyContent: "center"
              }}
            />
              {/* <Image source={{uri: image}}
                style={{ 
                  flex: 1,
                  // resizeMode: 'contain', 
                  width: null,
                }}
              /> */}
              {isNew && (
                <View
                  style={{
                    backgroundColor:appColors.red,
                    position: 'absolute',
                    top: scale(10),
                    left: scale(10),
                    padding: scale(3),
                    borderRadius: scale(3),
                    paddingHorizontal: scale(10),
                  }}>
                  
                  <Label text="New" style={{fontSize:scale(10), color:appColors.white}} />
                </View>
              )}
          </View>

          <View style={{
            paddingVertical: scale(3), 
            paddingHorizontal: scale(5),
            // flex: 1,
            flexDirection: 'row',
            alignItems: 'center',
            alignSelf: 'flex-start',
          }}>
            <Text numberOfLines={1}
            style={{
              fontFamily: 'OpenSans-Regular',
              flexWrap: 'wrap',
              alignItems: 'flex-start',
              flexShrink: 1,
              color: appColors.black,
              fontSize: scale(14)
            }}
            >{descriptions.name}
            </Text>
          </View>

          {/* <View style={{paddingVertical: scale(2), paddingHorizontal: scale(5)}}>
            <Text numberOfLines={2}
              style={{
                fontFamily: 'OpenSans-Regular',
                flexWrap: 'wrap',
                alignItems: 'flex-start',
                flexShrink: 1,
                color: appColors.darkGray,
                fontSize: scale(12)
              }}
              >{descriptions.description}
              </Text>
          </View> */}

          <View style={{flexDirection: 'row', paddingVertical: scale(5), paddingHorizontal: scale(5)}}>
            <Label
              text={currencyFormat(price_promotion ? price_promotion : price) + ' đ'}
              style={{
                fontFamily: 'OpenSans-Bold',
                fontSize: scale(16),
                color: '#FE6600',
              }}
            />
            {price_promotion && price_promotion < price &&
            <View style={{}}>
              <Label
              text={currencyFormat(price) + ' đ'}
              style={{
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(15),
                color: appColors.gray,
                alignItems: 'center',
                justifyContent: 'center',
                textDecorationLine: 'line-through', 
                // textDecorationStyle: 'solid',
                paddingLeft: scale(10)
              }}
            />
            </View>
            }
          </View>
      </View>
    </Pressable>
  );
}

const mapStateToProps = (state) => ({
  
});
const mapDispatchToProps = {
  getProduct$: getProduct
};

export default connect(mapStateToProps, mapDispatchToProps)(ProductCard);
