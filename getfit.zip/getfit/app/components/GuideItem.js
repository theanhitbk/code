import React from 'react';
import { Dimensions, Image, Linking, Text, TouchableOpacity, View } from 'react-native';
import { scale } from 'react-native-size-matters';
import { appColors, shadow } from '../utils/appColors';

export class GuideItem extends React.PureComponent {
  
    render() {
      const item = this.props.item;
      return (
        <View style={{
                              
        }}>
          <TouchableOpacity onPress={async () => {
            if(item.id_post) {
              this.props.getDetailPostCategory(item.id_post)
              this.props.navigation.navigate('NewsDetail')
            }
            /*
            if(item.url) {
              const supported = await Linking.canOpenURL(item.url);
              if(supported) {
                await Linking.openURL(item.url);
              }
            }*/
          }}>
          <View style={{
            flexDirection: 'row',
            width: (Dimensions.get('window').width) / 2,
            alignItems: 'center'
          }}>
            <Image
                source={{uri: item.image}}
                style={{ 
                    borderRadius: scale(4), 
                    width: 50,
                    height: 50,
                }}
            />
            <Text numberOfLines={3} 
              style={{
                fontFamily: 'OpenSans-Bold',
                flexShrink: 1, 
                marginHorizontal: scale(10),
              }}>{item.title}</Text>
          </View>
          </TouchableOpacity>
        </View>
      )
  }
}
