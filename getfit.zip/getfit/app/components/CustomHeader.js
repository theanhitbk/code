import React, { useState } from 'react';
import { StyleSheet, Text, View } from "react-native";
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
  } from 'react-native-popup-menu';
import { scale } from "react-native-size-matters";
import Feather from 'react-native-vector-icons/dist/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { appColors, shadow } from "../utils/appColors";

export default function CustomHeader({opened, setOpen, navigation}) {

    return (
        <View style={{
            zIndex: 5,
            elevation: 5,
            position: 'absolute',
            top: 1,
            right: 5,
            // ...shadow
          }}>
            <Menu
              opened={opened}
              onBackdropPress={() => {
                setOpen(false)
              }}
              onSelect={value => {
                setOpen(false)
                if(value === 1) {
                  navigation.navigate('Shop');
                }
                if(value === 2) {
                  navigation.navigate('Account');
                }

                if(value === 3) {
                  navigation.navigate('Orders');
                }
              }}
            >
              <MenuTrigger/>
              <MenuOptions
                optionsContainerStyle={styles.menuOptions}
              >
                <MenuOption value={1} 
                style={{
                  flexDirection: 'row', 
                  alignItems: 'center',
                }}>
                  <Feather name='home' size={20} />
                  <Text style={{fontFamily: 'OpenSans-Regular', fontSize: scale(12), marginLeft: scale(5)}}>Trang chủ</Text>
                </MenuOption>
                <MenuOption value={2} 
                style={{
                  flexDirection: 'row', 
                  alignItems: 'center',
                  paddingTop: scale(10)
                }}>
                  <Feather name='user' size={20} />
                  <Text style={{fontFamily: 'OpenSans-Regular', fontSize: scale(12), marginLeft: scale(5)}}>Tài khoản</Text>
                </MenuOption>
                <MenuOption value={3} 
                style={{
                  flexDirection: 'row', 
                  alignItems: 'center',
                  paddingTop: scale(10),
                }}>
                  <MaterialCommunityIcons name='clipboard-check-outline' size={20} />
                  <Text style={{fontFamily: 'OpenSans-Regular', fontSize: scale(12), marginLeft: scale(5)}}>Đơn hàng</Text>
                </MenuOption>
              </MenuOptions>
            </Menu>
        </View>
    );
}

const styles = StyleSheet.create({
    menuOptions: {
      shadowColor: appColors.lightGray,
      shadowOpacity: 0.5,
      shadowOffset: { width: 0, height: 0 },
      shadowRadius: 5,
      borderWidth: 1,
      borderRadius: 10,
      borderColor: appColors.lightGray,
      paddingVertical: scale(10),
      paddingHorizontal:scale(4),
      width: '40%',
      ...shadow
    }
  });
  