import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, Image} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import ReduxWrapper from '../../utils/ReduxWrapper';
import { api } from '../../services/api';
import { PT_LIST_URL } from '../../services/config';
import Spinner from '../../components/Spinner';

function BookService({userInfo, branch, orderList, getMemberOrders, onPtSuccess, setOrder, setIsOrderSelected, navigation}) {

  const OrderCard = ({item}) => {
    const {avatar, price_name, order_code} = item;
    return (
      <View style={{ width: '48%' }}>
        <View style={{ 
          backgroundColor: appColors.WHITE, 
          borderRadius: 10, 
          borderWidth: scale(1),
          borderColor: appColors.LIGHT_GREY,
          overflow: "hidden",
        }}>
          <View>
            <Image
              source={{uri: avatar}}
              style={{
                height: 140,
                width: '100%'
              }}
            />
          </View>
          <View style={{ padding: 10, width: '100%' }}>
            <Text style={{
              flexWrap: 'wrap',
              alignItems: 'flex-start',
              flexShrink: 1,
              fontWeight: '700',
              fontSize: scale(16)
            }}>{price_name}</Text>
            <Text style={{ 
              color: appColors.LIGHT_GREY, 
              paddingVertical: scale(10),
              flexWrap: 'wrap',
              alignItems: 'flex-start',
              flexShrink: 1,
            }}>
              {order_code}
            </Text>

            <Pressable onPress={async () => {
              try {
                const result = await api.get(PT_LIST_URL, {params: {order_id: item.order_id}}, {crossDomain: true});
                onPtSuccess(result.data.data, branch, item);
              } catch {
                onPtSuccess([], branch, item);
              }
              setOrder(item);
              setIsOrderSelected(false);
            }}>
              <View style={{
                flexDirection: 'row',
                justifyContent: 'center',
                borderColor: appColors.LIGHT_BLACK,
                borderWidth: scale(1),
                borderRadius: scale(6),
                padding: scale(8),
                backgroundColor: appColors.WHITE,
                marginVertical: scale(10)
              }}>
                <Text style={{
                  textTransform: 'uppercase',
                  fontWeight: '700',
                  fontSize: scale(16)
                }}>Chọn</Text>
              </View>
            </Pressable>
          </View>
        </View>
      </View>
    );
  };
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    getMemberOrders();
  }, []);

  const wait = (timeout) => {
    return new Promise(resolve => {
        getMemberOrders();
        setTimeout(resolve, timeout);
    });
  }

  const onRefresh = useCallback(() => {
        setRefreshing(true);
        wait(2000).then(() => setRefreshing(false));
  }, []);

  return (
    <SafeAreaView  style={styles.container}>
        <View style={styles.descriptionContainer}>
            <Image source={{uri: userInfo.avatar}} style={styles.image}/>
            <Text style={[styles.textDescription]}>{userInfo.notification}</Text>
        </View>

        <View style={{paddingVertical: scale(20)}}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginHorizontal: scale(5)
            }}>
            <View style={{}}>
            <Label
              text={'Mời bạn chọn dịch vụ'}
              style={{fontSize: scale(18), fontWeight: '600', textTransform: 'uppercase'}}
            />
            </View>
            <Label text={orderList.length + ' dịch vụ'} 
              style={{
                fontSize: scale(12),
                color: appColors.darkGray,
                textTransform: 'uppercase'
              }} />
          </View>
        </View>

        <View style={{
          flex:1, 
          paddingVertical:scale(5),
          marginHorizontal: scale(5)
        }}>
          {orderList.length === 0 ? <Spinner /> :
            <FlatList
                refreshing={refreshing} 
                onRefresh={onRefresh}
                columnWrapperStyle={{justifyContent: 'space-between'}}
                numColumns={2}
                keyExtractor={(item)=> `${item.order_id}_${new Date().getTime()}_${item.order_code}`}
                ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
                data={orderList}
                renderItem={({item, indx}) => <OrderCard key={indx} item={item} />}
                style={{margin: 5}}
            />
          }
        </View>
    </SafeAreaView>
  );
}

export default ReduxWrapper(BookService)

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE
    },
  contentContiner: {
    paddingVertical: scale(5),
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(10),
    ...shadow,
  },
  descriptionContainer:{
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#c6e0cb',
    backgroundColor: '#ecf7f0',
    paddingHorizontal: scale(6),
    paddingVertical: scale(6),
    marginHorizontal: scale(5),
    borderRadius: 8,
    marginTop: -40
  },
  image:{
    width: 80,
    height: 80,
    borderRadius: 25
  },
  textDescription: {
    flexWrap: 'wrap',
    alignItems: 'flex-start',
    flexShrink: 1,
    marginLeft: 10,
    color: appColors.black,
    fontSize: scale(14)
  },
});
