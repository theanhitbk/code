import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, TouchableOpacity, Image} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import { useFocusEffect } from '@react-navigation/native';
import { getCmsCategories, getDetailCategory, getDetailPostCategory } from '../../redux/categoryAction';
import { connect } from 'react-redux';
import {BASE_URL} from '../../../app.json';
import BookingHeader from '../../components/BookingHeader';

function News({categories, getCmsCategories$, getDetailCategory$, getDetailPostCategory$, navigation}) {

  const renderNewsCard = ({item}) => (
    <TouchableOpacity onPress={() => {
      getDetailPostCategory$(item.id);
      navigation.navigate('NewsDetail', {item: item})
    }}>
        <View style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginHorizontal: scale(0),
            borderBottomColor: appColors.lightGray,
            borderBottomWidth: 1,
            paddingVertical: scale(3),
        }}>
            
            {item.image && item.image.length > 0 && 
            <Image source={{uri: BASE_URL + item.image}} 
                style={{
                    // resizeMode: 'contain', 
                    alignSelf: 'center', 
                    height: scale(100),
                    width: scale(120),
                    marginHorizontal: scale(5),
                }}
            />
            }
            
            <View style={{
                // flex: 1,
                // alignItems: 'center',
                flexShrink: 1,
                // justifyContent: 'flex-start',
                marginLeft: scale(5),
                // marginHorizontal: scale(5),
            }}>
                <Text ellipsizeMode='tail' numberOfLines={1}
                style={{
                  fontFamily: 'OpenSans-Bold',
                  justifyContent: 'flex-start',
                  fontWeight: '700',
                  fontSize: scale(14),
                }}>{item.descriptions.title}</Text>
                <Text ellipsizeMode='tail' numberOfLines={4}
                  style={{fontFamily: 'OpenSans-Regular',}}
                >{item.descriptions.description}</Text>
            </View>
        </View>
    </TouchableOpacity>
  );

  const CategoryCard = ({category}) => {
    const {title} = category;
    return (
      <View>
        <View style={styles.contentContiner}>
          <View style={{
              alignItems: 'flex-start',
          }}>
            <Label
              text={title}
              style={{
                fontFamily: 'Oswald-Regular',
                  fontSize: scale(18), 
                  fontWeight: '500',
                  textTransform: 'uppercase',
                  paddingVertical: scale(7)
              }}
            />
          </View>
          <View style={{
              alignItems: 'flex-start',
          }}>
            <Pressable onPress={() => {
              getDetailCategory$(category.id)
              navigation.navigate('NewsList', {item: category})
            }} >
              <Label
                  text={'Xem thêm'}
                  style={{
                    fontFamily: 'Oswald-Regular',
                      fontSize: scale(12), 
                      fontWeight: '500',
                      paddingVertical: scale(7),
                      textTransform: 'uppercase',
                      color: appColors.DARK_GREY
                  }}
              />
            </Pressable>
          </View>
        </View>
        
        <FlatList
        listKey={'news_ ' + category.id}
        keyExtractor={(item)=> `news_${item.id}`}
        //ItemSeparatorComponent={() => <View style={{padding: scale(4)}} />}
        data={category.posts ? category.posts : []}
        renderItem={renderNewsCard}
        />
      </View>
    );
  };
  const [refreshing, setRefreshing] = useState(false);

  const wait = (timeout) => {
    return new Promise(resolve => {
        setTimeout(resolve, timeout);
    });
  }

  const onRefresh = useCallback(() => {
        setRefreshing(true);
        getCmsCategories$();
        wait(2000).then(() => setRefreshing(false));
  }, []);

  useFocusEffect(useCallback(() => {
      getCmsCategories$();
  }, []));

  const renderCatList = ({item, index}) => (
    <CategoryCard key={index} category={item} />
  );

  return (
    <SafeAreaView  style={styles.container}>
        <BookingHeader title={'Getfit Booking'} navigation={navigation}>
            <Text style={{
              fontFamily: 'Oswald-Bold',
                color: appColors.BLACK,
                fontSize: scale(20),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>Tin tức</Text>
        </BookingHeader>

        <FlatList
          refreshing={refreshing} 
          onRefresh={onRefresh}
          keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_${item.id}`}
          //ItemSeparatorComponent={() => <View style={{padding: scale(2)}} />}
          data={categories ? categories : []}
          renderItem={renderCatList}
        />
    </SafeAreaView>
  );
}

const mapStateToProps = (state) => ({
    categories : state.categories.cmsCategories,
 });
 const mapDispatchToProps = {
   getCmsCategories$: getCmsCategories,
   getDetailCategory$: getDetailCategory,
   getDetailPostCategory$: getDetailPostCategory
 };
 
 export default connect(mapStateToProps, mapDispatchToProps)(News);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE,
    },
  contentContiner: {
    //paddingVertical: scale(3),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(5),
    borderBottomWidth: scale(1.2),
    borderBottomColor: '#FE8800',
    paddingVertical: scale(10),
    ...shadow,
  },
});
