import React,{useState,useEffect, useCallback} from 'react'
import { View, Text, StyleSheet, SafeAreaView, Image, Pressable, FlatList, Platform, ListView } from 'react-native'
import ReduxWrapper from '../../utils/ReduxWrapper';
import { scale } from 'react-native-size-matters';
import { theme } from '../../core/theme'
import { appColors } from '../../utils/appColors';
import BookingHeader from '../../components/BookingHeader';
import Timeline from 'react-native-timeline-flatlist'
import Feather from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import Branch from '../Branch';
import Service from '../Service';
import Label from '../../components/Label';
import TouchableRipple from 'react-native-touch-ripple';
import { AlertHelper } from '../../utils/AlertHelper';
import TextInput from '../../components/TextInput';
import { useFocusEffect } from '@react-navigation/native';
import { PT_LIST_URL, SCHEDULE_LIST_URL } from '../../services/config';
import { api } from '../../services/api';
import { dateFormat, getListDate } from '../../utils/HelperFunctions';
import Spinner from '../../components/Spinner';

const sampleList = getListDate();

function Booking({isLoggedIn, userInfo, addBooking$, updateBooking$, getBook$, route: {params}, navigation}) 
{  
  const isEdit = (params && params.item) ? true : false;
    const [branch, setBranch] = useState(isEdit ? {branch_id: params.item.branch_id, address : params.item.branch_address} : null);
    const [order, setOrder] = useState(isEdit ? {order_id: params.item.order_id, price_name: params.item.order_name} : null);
    const [dateTime, setDateTime] = useState(isEdit ? params.item.date_time : new Date());
    const [isBranchSelected, setIsBranchSelected] = useState(false);
    const [isOrderSelected, setIsOrderSelected] = useState(false);
    const [ptSelected, setPtSelected] = useState(isEdit? params.item.employee_id : null);
    const [ptData, setPtData] = useState([]);
    const [scheduleData, setScheduleData] = useState([]);
    const [showCalendar, setShowCalendar] = useState(false);
    const [desc, onChangeText] = useState(isEdit ? params.item.description : '');

    var descValue = isEdit ? params.item.description : '';
    
    const dataTimelineList = [
      {
        time: '00:00', title: '1. Chọn địa điểm', 
        description: 'Xem tất cả địa điểm',
        icons: 'home-outline',
        icon: <Image
          style={{width: 20, height: 20}}
          source={require('../../static/images/circle-clean.png')}
        />,
        screen: 'Branch',
        lineColor: appColors.ORANGE,
        branchId: isEdit? params.item.branch_id : null,
        id: 1,
        height: 80,
        branch: null,
      },
      {
        id: 2,
        height: 80,
        time: '00:01', title: '2. Chọn dịch vụ', description: 'Xem tất cả dịch vụ hấp dẫn',
        screen: 'Service',
        icons: 'heart-outline',
        icon: <Image
          style={{width: 20, height: 20}}
          source={require('../../static/images/circle-clean.png')}
        />,
        orderId: isEdit ? params.item.order_id : null,
        employee_id: isEdit ? params.item.employee_id : null,
        lineColor: appColors.gray,
        circleColor: branch ? appColors.ORANGE : appColors.gray
      },
      { 
        id: 3,
        height: 80,
        time: '00:02', title: '3. Chọn ngày giờ', 
        description: dateFormat(date),
        screen: 'Date', 
        isLoaded: false,
        icon: <Image
          style={{width: 20, height: 20}}
          source={require('../../static/images/circle-clean.png')}
        />,
        ptList: [],
        ptSchedules: [],
        dateList: sampleList[0],
        icons: 'calendar',lineColor: appColors.gray, circleColor: appColors.gray,
        dateTime: isEdit ? params.item.date_time : null,
        showCalendar: null,
      },
      {time: '00:03', 
      icon: <Image
          style={{width: 0, height: 0}}
          source={require('../../static/images/circle-clean.png')}
        />,
      title: '', description: '', circleColor: appColors.gray, circleSize: 1}
    ];

    const [date, setDate] = useState(dataTimelineList[2].dateList.value);
    const [dataTimeline, setDataTimeline] = useState(dataTimelineList);
    
    useFocusEffect(useCallback(() => {
        if(!isLoggedIn) {
            navigation.navigate('Login')
        }
        
        if(isEdit) {
          getPtDatas()
        }

        return () => {
          // setBranch(null)
          // setOrder(null)
          // setDateTime(null)
          // onChangeText('')
          //setDataTimeline(null)
        };
    }, []));

    if(isEdit) {     
      //setDate(dataTimelineList[2].dateList.value)
      //setDate(new Date(params.item.date_time.substring(0, 10)))
      sampleList.forEach((d) => {
        if(d.value.toISOString().substring(0, 10) === params.item.date_time.substring(0, 10)) {
          dataTimelineList[2].dateList = d;
          //setDataTimeline(dataTimelineList);
        }
      }) 
    }

    const getPtData = async (orderId) => {
      let ptList = [];
      try {
        const result = await api.get(PT_LIST_URL, {params: {order_id: orderId}}, {crossDomain: true});
        ptList = result.data.data;
      } catch (error) {

      }

      dataTimelineList[2].ptList = ptList;
      setDataTimeline(dataTimelineList);
      setPtData(ptList);

      return ptList;
    };

    const getPtDatas = async () => {
      await getPtData(params.item.order_id);
      
      dataTimelineList[2].ptSchedules = await getPTList({
        account_id: userInfo.account_id,
        employee_id: params.item.employee_id,
        branch_id: params.item.branch_id,
        date_time: params.item.date_time
      });
      setPtSelected(params.item.employee_id);
      dataTimelineList[1].employee_id = params.item.employee_id;
      dataTimelineList[2].icon = require('../../static/images/icon-checked.png');
      setScheduleData(dataTimelineList[2].ptSchedules);
      setDataTimeline(dataTimelineList);
    }
    
    const setBranchData = async (data) => {
        setBranch(data);
        dataTimelineList[0].branch = data;
        setDataTimeline(dataTimelineList);
    };

    const setOrderData = async (data) => {
      setOrder(data);
      dataTimelineList[1].order = data;
      setDataTimeline(dataTimelineList);
    };

    const onPtSuccess = async (result, branchData, orderData) => {
      setPtData(result);
      dataTimelineList[2].ptList = result;
      dataTimelineList[0].branch = branchData;
      dataTimelineList[1].order = orderData;

      let isExited = false;
      result.forEach(p => {
        if(p.employee_id === dataTimelineList[1].employee_id) {
          isExited = true;
        }
      })

      if(!isExited) {
        dataTimelineList[1].employee_id = null;
        setPtSelected(null);
        dataTimelineList[2].ptSchedules = [];
        setDataTimeline(dataTimelineList);
      }
      
      if(date && dataTimelineList[1].employee_id && isExited) {
        dataTimelineList[2].ptSchedules = await getPTList({
          account_id: userInfo.account_id,
          employee_id: dataTimelineList[1].employee_id,
          branch_id: branchData.branch_id,
          date_time: date
        });
        
        setScheduleData(dataTimelineList[2].ptSchedules);
      }

      setDataTimeline(dataTimelineList);
    };

    const getPTList = async(data) => {
      try {
        const result = await api.get(SCHEDULE_LIST_URL, 
          {params: data}, {crossDomain: true});
          return result.data.data;
      } catch (error) {
        console.log(error)
      }

      return [];
    };

    const renderItem = ({item}) => {
      return (
        <View>
          <TouchableRipple
            onPress={async () => {
              dataTimelineList[2].icon = require('../../static/images/icon-checked.png');
              dataTimelineList[2].dateTime = item.date_time;
              setDataTimeline(dataTimelineList);
              setDateTime(item.date_time);
            }}
            rippleColor='#a3a3a3'
            rippleContainerBorderRadius={scale(4)}
            rippleDuration={800}
          >
            <View
            style={{
              borderWidth: 1,
              borderColor: item.date_time !== dataTimelineList[2].dateTime ? appColors.BLACK : '#a3a3a3',
              borderRadius: scale(6),
              backgroundColor: '#e8e8e8',
              paddingHorizontal: scale(10),
              paddingVertical: scale(10),
              marginVertical: scale(5),
              marginHorizontal: scale(2)
          }}>
            <Text style={{ 
              fontSize: 16, 
              fontFamily: 'OpenSans-Bold',
              borderColor: appColors.BLACK,
              color: item.date_time !== dataTimelineList[2].dateTime ? appColors.BLACK : '#a3a3a3'
            }}
            >{item.start_time}</Text>
            </View>
          </TouchableRipple>
        </View>
      );
    };

    const keyExtractor = useCallback((item) => {
      return item.start_time;
    }, []);

    const renderDetail = (rowData, sectionID, rowID) => {
      
        let title = <Text style={[styles.title]}>{rowData.title}</Text>
        var descc = null;
        
        if(isEdit) {
          if(ptData.length) {
            dataTimelineList[2].ptList = ptData;
          }

          if(scheduleData.length) {
            dataTimelineList[2].ptSchedules = scheduleData;
          }
        }

        if(branch && rowData.screen == 'Branch') {
          rowData.description = branch.address;
          dataTimelineList[0].icon = require('../../static/images/icon-checked.png');
          setDataTimeline(dataTimelineList);
        }

        if(order && rowData.screen == 'Service') {
          rowData.description = order.price_name;
          dataTimelineList[1].icon = require('../../static/images/icon-checked.png');
          dataTimelineList[1].lineColor = appColors.ORANGE;
          dataTimelineList[2].lineColor = appColors.ORANGE;
          dataTimelineList[2].circleColor = appColors.ORANGE;
          if(!isEdit) {
            dataTimelineList[2].ptList = ptData;
          }
          setDataTimeline(dataTimelineList);
        }
        
        if(rowData.screen == 'Date') {
          setDate(dataTimelineList[2].dateList.value);
          rowData.description = dataTimelineList[2].dateList.name;
        }

        if(rowData.description)
          descc = (
            <Pressable onPress={() => {
              if(rowData.screen === 'Service' && !branch) {
                AlertHelper.show("error", 'Bạn chưa chọn địa điểm');
                return;
              }

              if(rowData.screen === 'Date' && !order) {
                AlertHelper.show("error", 'Bạn chưa chọn dịch vụ');
                return;
              }

              setIsOrderSelected(rowData.screen === 'Service');
              setIsBranchSelected(rowData.screen === 'Branch');
              if(rowData.screen === 'Date') {
                if(dataTimelineList[2].showCalendar) {
                  dataTimelineList[2].showCalendar = false;
                } else {
                  dataTimelineList[2].showCalendar = true;
                }
                setDataTimeline(dataTimelineList);
                setShowCalendar(dataTimelineList[2].showCalendar);
              }
            }}>
              <View style={styles.descriptionContainer}>
                  {rowData.screen !== 'Date' && 
                  <Ionicons name={rowData.icons} size={scale(20)} color={appColors.black}
                    style={{alignSelf: 'center'}}
                  />
                  }
                  {rowData.screen === 'Date' && 
                    <Feather name={rowData.icons} size={scale(20)} color={appColors.black}
                      style={{alignSelf: 'center'}}
                    />
                  }
                  
                  <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    position: 'relative'
                  }}>
                    <Text numberOfLines={1} style={[styles.textDescription]}>{rowData.description}</Text>
                    <Ionicons name="caret-forward-outline" size={scale(16)} color={appColors.black}
                      style={{alignSelf: 'center', right: scale(14)}}
                    />
                    {rowData.screen === 'Date' &&
                    <Text style={{
                          fontFamily: 'OpenSans-Regular',
                          fontSize: scale(11),
                          backgroundColor: dataTimelineList[2].dateList.is_weekend ? '#FE8800' : appColors.GREEN,
                          color: appColors.WHITE,
                          paddingHorizontal: scale(5),
                          paddingVertical: scale(3),
                          borderRadius: scale(4),
                          position: 'absolute',
                          right: scale(20)
                    }}>{dataTimelineList[2].dateList.is_weekend ? 'Cuối tuần' : 'Ngày thường'}</Text>
                  }
                  </View>
              </View>
            </Pressable>
          )
        
        return (
          <View style={{flex:1, top: -12}}>
            {title}
            {rowData.screen == 'Branch' && 
              <View style={{
                flex: 1,
                flexDirection: 'row',
                alignItems: 'center',
                alignSelf: 'flex-start',
                borderWidth: .5,
                borderColor: '#c6e0cb',
                backgroundColor: '#ecf7f0',
                paddingHorizontal: scale(6),
                paddingVertical: scale(10),
                marginBottom: scale(20),
                marginHorizontal: scale(10),
                borderRadius: 8,
                width: '110%',
                left: -50
              }}>
                  {userInfo.avatar && userInfo.avatar.length > 0 &&
                    <Image source={{uri: userInfo.avatar}} 
                    style={{
                      width: 80,
                      height: 80,
                      borderRadius: 20
                    }}/>
                  }
                  <Text style={{
                    fontFamily: 'OpenSans-Regular',
                    flexWrap: 'wrap',
                    alignItems: 'flex-start',
                    flexShrink: 1,
                    marginLeft: 10,
                    color: appColors.black,
                    fontSize: scale(12)
                  }}>{userInfo.notification}</Text>
              </View>
            }

            {descc}

            {rowData.screen === 'Date' && dataTimelineList[2].showCalendar &&
                <FlatList data={sampleList} renderItem={
                    ({item}) => {
                      const {name, value, is_weekend} = item;
                      return (
                        <Pressable onPress={async () => {
                          setDate(value);
                          dataTimelineList[2].dateTime = null;
                          setDateTime(null);
                          if(branch && dataTimelineList[1].employee_id) {
                            
                            dataTimelineList[2].ptSchedules = await getPTList({
                              account_id: userInfo.account_id,
                              employee_id: dataTimelineList[1].employee_id,
                              branch_id: branch.branch_id,
                              date_time: value
                            });
                            setScheduleData(dataTimelineList[2].ptSchedules);
                            //setDataTimeline(dataTimelineList);
                          }

                          dataTimelineList[2].showCalendar = false;
                          dataTimelineList[2].dateList = item;
                          setDataTimeline(dataTimelineList);
                          setShowCalendar(dataTimelineList[2].showCalendar);
                        }}>
                        <View style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          backgroundColor: appColors.WHITE,
                          borderColor: appColors.lightGray,
                          borderWidth: 1,
                          borderTopWidth: 0,
                          //height: scale(38),
                          alignItems: 'center',
                          paddingHorizontal: scale(5),
                          paddingVertical: scale(7)
                        }}>
                          <Text style={{
                            fontFamily: 'OpenSans-Regular',
                            fontSize: scale(11),
                          }}>{name}</Text>
                          <Text style={{
                            fontFamily: 'OpenSans-Regular',
                            fontSize: scale(11),
                            backgroundColor: is_weekend ? '#FE8800' : appColors.GREEN,
                            color: appColors.WHITE,
                            paddingHorizontal: scale(5),
                            paddingVertical: scale(3),
                            borderRadius: scale(4)
                          }}>{is_weekend ? 'Cuối tuần' : 'Ngày thường'}</Text>
                        </View>
                        </Pressable>
                      )
                    }
                  }
                />
            }
            {rowData.screen == 'Date' && order &&
              <View style={{
                paddingVertical: scale(10),
              }}
              >
                <FlatList
                  style={{
                    marginHorizontal: scale(10),
                    marginVertical: scale(10),
                  }}
                  listKey='employee'
                  nestedScrollEnabled
                  showsHorizontalScrollIndicator={false}
                  horizontal
                  data={dataTimelineList[2].ptList}
                  extraData={ptSelected}
                  ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
                  renderItem={({item, index}) => {
                    const {full_name, avatar, employee_id} = item;
                    return (
                      <View key={index} 
                        style={{
                          alignItems: 'center',
                          justifyContent: 'center',
                          width: 60,
                          position: 'relative'
                        }}>
                        <TouchableRipple
                          onPress={async () => {
                            dataTimelineList[2].dateTime = null;
                            setDateTime(null);
                            dataTimelineList[1].employee_id = employee_id;
                            setPtSelected(employee_id);
                            dataTimelineList[2].ptSchedules = await getPTList({
                              account_id: userInfo.account_id,
                              employee_id: employee_id, 
                              branch_id: branch.branch_id,
                              date_time: dataTimelineList[2].dateList.value
                            });
                            
                            setScheduleData(dataTimelineList[2].ptSchedules);
                            setDataTimeline(dataTimelineList);
                          }}
                          rippleColor={appColors.primary}
                          rippleContainerBorderRadius={scale(40)}
                          rippleDuration={800}
                          style={dataTimelineList[1].employee_id === employee_id? styles.ptSelected : styles.ptNormal}
                          >
                            <View style={{flex: 1, flexDirection: 'row', position: 'relative'}}>
                              <Image source={{uri: avatar}} 
                                style={{
                                  flex: 1, 
                                  borderRadius: 50, 
                                  resizeMode: 'cover', 
                                  alignSelf: 'stretch', 
                                  width: null,
                                  borderColor: appColors.BLACK
                                }}/>
                            </View>
                        </TouchableRipple>
                        {dataTimelineList[1].employee_id === employee_id && <Image source={require('../../static/images/icon-checked.png')} 
                              style={{
                                position:'absolute',
                                width: scale(14),
                                height: scale(14),
                                right: scale(0),
                                bottom: scale(35),
                                zIndex: scale(10)
                              }}
                            />}
                        <View 
                        style={{
                          marginTop: scale(5),
                          alignItems: 'center',
                          flexShrink: 1,
                        }}>
                          <Text numberOfLines={2} 
                          style={{
                            fontSize: scale(12), 
                            flexShrink: 1,
                          }}>{full_name}</Text>
                        </View>
                      </View>
                    );
                  }}
                />
                <View style={{
                  }}
                  >
                    <FlatList
                      style={{
                        marginVertical: scale(10),
                      }}
                      numColumns={4}
                      listKey='schedule'
                      keyExtractor={keyExtractor}
                      nestedScrollEnabled
                      contentContainerStyle={{alignSelf: 'flex-start'}}
                      showsVerticalScrollIndicator={false}
                      showsHorizontalScrollIndicator={false}
                      //horizontal
                      data={dataTimelineList[2].ptSchedules}
                      extraData={dataTimelineList[2].ptSchedules}
                      ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
                      renderItem={renderItem}
                    />
                    <Text style={{fontWeight: 'bold', fontSize: scale(15)}}>Ghi chú</Text>
                    <TextInput
                      multiline
                      numberOfLines={4}
                      onChangeText={text => {descValue = text; onChangeText(text);}}
                      value={descValue}
                      style={{padding: 10, borderColor: appColors.darkGray, borderRadius: scale(10)}}
                      editable
                      maxLength={40}
                    />            
                </View>
              </View>
            }
          </View>
        )
    };

    const onSuccess = (result) => {
      AlertHelper.show('success', result.meta.message);
      getBook$(result.data.id)
      navigation.navigate('BookResultScreen', {item: result.data})
    };

    const onError = (error) => {
      console.log(error);
      if(typeof error.meta != 'undefined') {
        AlertHelper.show('error', error.meta.message);
      } else {
        AlertHelper.show('error', 'Hệ thống đang quá tải. Vui lòng thử lại sau');
      }
    };

    const DATA = [
      {
        id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
        title: '',
      },
    ];

    const renderFooter = () => {
      return (
        <View style={{marginTop: -75}}>
          <Pressable onPress={() => {
            if(!dateTime) {
              AlertHelper.show('error', 'Bạn chưa chọn thời gian');
              return;
            }

            if(!ptSelected) {
              AlertHelper.show('error', 'Bạn chưa chọn PT');
              return;
            }
            let paramsToUpdate = {
              account_id: userInfo.account_id,
              employee_id: ptSelected,
              branch_id: branch.branch_id,
              order_id: order.order_id,
              date_time: dateTime,
              description: desc
            };


            if(isEdit) {
              paramsToUpdate.id = params.item.id;
              updateBooking$(paramsToUpdate, onSuccess, onError);
            } else {
              addBooking$(paramsToUpdate, onSuccess, onError);
            }
          }}
          disabled={(!ptSelected || !branch || !order || !dateTime) ? true : false}
            style={{
                marginHorizontal:20,
                paddingVertical:20,
                backgroundColor: "#e8e8e8",
                borderRadius:6,
                borderWidth: 0,
                borderColor: '#e8e8e8',
                justifyContent: 'center', 
                alignItems: 'center',
            }}
          >
            <Text style={{
              fontFamily: 'OpenSans-Bold',
                alignSelf: 'center',
                textTransform: 'uppercase',
                fontSize: scale(16),
                color: (!ptSelected || !branch || !order || !dateTime) ? appColors.darkGray : appColors.BLACK
            }}>Hoàn tất</Text>
          </Pressable>

          <Text style={{
                fontFamily: 'OpenSans-Regular',
                alignSelf: 'center',
                marginVertical:15,
                //marginBottom: scale(120),
                fontSize: scale(12)
            }}>Xin Quý khách book lịch trước 2 tiếng</Text>
        </View>
      );
    };

    const renderCircle = (rowData, sectionID, rowID) => {
      if(branch && rowData.screen == 'Branch') {
        rowData.description = branch.address;
        dataTimelineList[0].icon = require('../../static/images/circle-clean.png');
        setDataTimeline(dataTimelineList);
      }

      return (
        <>
          <Image source={require('../../static/images/circle-clean.png')} />
        </>
      );
    };

    const _renderItem = () => (
      <View style={{flex: 1, marginVertical: scale(10)}}>
        <Timeline
            data={dataTimeline}
            innerCircle={'icon'}
            circleSize={20}
            circleColor={appColors.ORANGE}
            lineColor='#e8e8e8'
            timeContainerStyle={{marginTop: 20, marginBottom: scale(0)}}
            timeStyle={{textAlign: 'center', backgroundColor:'#ff9797', color: appColors.ORANGE, padding:0, borderRadius:13}}
            descriptionStyle={{color:'gray'}}
            options={{
                removeClippedSubviews: false,
                renderFooter: renderFooter,
                style:{
                  //paddingTop:5,
                }
            }}
            showTime={false}
            renderDetail={renderDetail}
            //renderCircle={renderCircle}
            separator={false}
            isUsingFlatlist={true}
            detailContainerStyle={{marginTop: 0, marginBottom: 10, marginRight: 10, paddingLeft: 3, paddingRight: 3,}}
        />
        {renderFooter()}
      </View>
    );
  
    return (
      <SafeAreaView style={{flex: 1}}>
        <BookingHeader title={'Getfit Booking'} isback navigation={navigation}>
        {!isBranchSelected && !isOrderSelected &&
            <Text style={{
                color: appColors.BLACK,
                fontSize: scale(20),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>{isEdit ? 'Đổi lịch' : 'Đặt lịch'}</Text>
          }
          {(isBranchSelected || isOrderSelected) &&
            <View style={{
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'flex-start',
              alignItems: 'center',
            }}>
              <View style={{
                    justifyContent: 'flex-start',
                    alignItems: 'center',
              }}>
              <Pressable onPress={() => {
                    setIsOrderSelected(false);
                    setIsBranchSelected(false);
                  }} 
                  style={{
                    left: 10,
                    // justifyContent: 'flex-start',
                }}>
                    <Feather name={'arrow-left'} size={scale(25)} />
                </Pressable>
              </View>
            <View style={{
                  flex: 1,
                    flexDirection: 'column',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                }}>
                
                <Label text={isBranchSelected? 'Chọn địa điểm' : 'Chọn dịch vụ'} style={{
                    color: appColors.BLACK,
                    fontSize: scale(20),
                    fontWeight: '500',
                }} />
            </View>
            </View>
          } 
        </BookingHeader>
                
          {isBranchSelected && <Branch branch={branch} order={order} setBranch={setBranch} setIsBranchSelected={setIsBranchSelected} onPtSuccess={onPtSuccess}/>}
          {isOrderSelected && <Service branch={branch} order={order} setOrder={setOrder} setIsOrderSelected={setIsOrderSelected} onPtSuccess={onPtSuccess} navigation={navigation}/>}
        
          {!isBranchSelected && !isOrderSelected &&          
          <View style={{
            flex: 1,
            // alignItems: 'center',
            flexGrow: 1,
            width: '100%',
            // height: '100%',
            // paddingBottom: scale(20),
             backgroundColor: appColors.WHITE
          }}>
            
          {dataTimeline ? 
            <FlatList
              data={DATA}
              renderItem={_renderItem}
              listKey='timeline'
            />
            :
            <Spinner />
          }
          </View>
          
          }
    </SafeAreaView>
    )
}

export default ReduxWrapper(Booking)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: appColors.WHITE,
  },
  list: {
    flex: 1,
    marginTop:0,
  },
  title:{
    fontSize:18,
    fontWeight: 'bold',
    marginBottom: scale(20),
    position: 'relative'
  },
  descriptionContainer:{
    flexDirection: 'row',
    alignItems: 'center',
    paddingRight: 70,
    borderColor: '#e8e8e8',
    backgroundColor: '#e8e8e8',
    paddingHorizontal: scale(8),
    paddingVertical: scale(8),
    borderRadius: 4,
    flexShrink: 1,
  },
  image:{
    width: 50,
    height: 50,
    borderRadius: 25
  },
  textDescription: {
    fontFamily: "OpenSans-Regular",
    marginLeft: 10,
    color: appColors.black,
    width: '100%',
    fontSize: scale(12),
  },

  buttonTextStyle: {
    fontFamily: "OpenSans-Regular",
    color: '#fff',
    paddingVertical: 12,
    paddingHorizontal: 36,
    fontSize: 16,
    textTransform: 'uppercase',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  forgotPassword: {
    width: '100%',
    alignItems: 'flex-end',
    marginBottom: 100,
    paddingVertical: scale(5)
  },
  row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  forgot: {
    fontSize: 13,
    color: theme.colors.secondary,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
  view: {
    position: 'absolute',
    backgroundColor: 'transparent'
  },
  touchable: {
    borderWidth: 1,
    // borderRadius: scale(15),
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    // backgroundColor: '#fff',
    flex: 1,
  },
  text: {
    fontSize: 18,
    textAlign: 'center'
  },
  ptNormal: {
    flex: 1,
    // position: 'relative',
    backgroundColor: appColors.white,
    height: scale(50),
    width: scale(50),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: scale(40),
  },
  ptSelected: {
    flex: 1,
    backgroundColor: appColors.white,
    height: scale(50),
    width: scale(50),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: scale(40),
    // position: 'relative',
    overflow: 'hidden',
    borderColor: appColors.ORANGE,
    borderWidth: scale(2.5),
  },
})