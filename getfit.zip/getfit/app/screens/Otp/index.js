import React, {useState} from 'react';
import {StyleSheet, View, Text, Pressable, TouchableOpacity, ImageBackground } from 'react-native';
import {scale} from 'react-native-size-matters';
import { useValidation } from 'react-native-form-validator';
import PhoneInput from 'react-native-phone-number-input';
import { v4 as uuid } from 'uuid';
import Container from '../../components/Container';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import auth from '@react-native-firebase/auth';
import { AlertHelper } from '../../utils/AlertHelper';
import { CommonActions, StackActions } from '@react-navigation/native';
import ReduxWrapper from '../../utils/ReduxWrapper';
import TextInput from '../../components/TextInput';
import BackButton from '../../components/BackButton';
import { ScrollView } from 'react-native-gesture-handler';
import Feather from 'react-native-vector-icons/dist/Feather';
import { SafeAreaView } from 'react-native-safe-area-context';
import OtpVerification from '../../components/Otp/OtpVerification';


function index({isLoggedIn, login$, navigation}) {
  
  const [authenticated, setAutheticated] = useState(false);
  auth().onAuthStateChanged((user) => {
    if(user) {
      setAutheticated(true);
      let data = {
        username: username,
        tenant_code: 'hosco'
      }
      
      login$(data, onSuccess, onError)
    } else {
      setAutheticated(false);
    }
  })

  const [credentials, setCredentials] = useState({});
  const [username, setUsername] = useState('0984533910');
  const [password, setPassword] = useState('');

  // If null, no SMS has been sent
  const [confirm, setConfirm] = useState(null);

  const [code, setCode] = useState('');

  // Handle the button press
  async function signInWithPhoneNumber() {
    const confirmation = await auth().signInWithPhoneNumber(username);
    setConfirm(confirmation);
  }

  async function confirmCode() {
    try {
      await confirm.confirm(code);
    } catch (error) {
      console.log('Invalid code.');
    }
  }

  const { validate, isFieldInError, getErrorsInField, getErrorMessages } =
    useValidation({
      state: { username, password },
    });

  const onSuccess = (data) => {
      if (isLoggedIn) {
        navigation.navigate('Home');
      }
  };

  const onError = (error) => {
    AlertHelper.show("error", error)
  };

  const onLogin = async () => {
    auth().signOut()
    validate({
      email: { email: true, required: true },
      password: { required: true },
    });

    try {
      let data = {
        username: username,
        password: password
      }
      login$(data, onSuccess, onError)
      /*
      const user = await auth().signInWithEmailAndPassword(
        username?.toLowerCase(),
        password?.toLowerCase(),
      );
      if (user?.user?.uid) {
        AlertHelper.show("success","Welcome to Amusoftech")
        navigation.navigate("Home")
      }*/
    } catch (error) {
      AlertHelper.show("error","Something went wrong")
    }
  };

  const onChangeText = (name, text) => {
    setCredentials({...credentials, [name]: text});
  };

  if (confirm) {
    return (
      <Container isScrollable>
      <View
        style={{
          flex: 1,
          marginTop: scale(50),
          backgroundColor: appColors.white,
          ...shadow,
          padding: scale(15),
          borderRadius: scale(5),
        }}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
          <Label
            text="Đăng Nhập"
            style={{
              fontSize: scale(30), 
              fontWeight: '700',
              color: appColors.primary,
              textAlign: 'center',
              flex:1, 
              justifyContent:"center",
              alignItems:"center"
            }}
          />
        <TextInput value={code} onChangeText={text => setCode(text)} />
        </View>
        <View style={{paddingVertical: scale(0)}}>
                <CustomButton onPress={confirmCode} label="Xác nhận" 
                  disabled={code == ''}
                  style={{
                    fontSize: scale(20),
                    fontWeight: '700',
                    width: '100%'
                  }}
                />
              </View>
      </View>
      </Container>
    );
  }

  return (
    <SafeAreaView style={styles.container}
    >
      <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled>
      <BackButton goBack={navigation.goBack} />
      <View
        style={{
          flex: 1,
          marginTop: scale(50),
          //backgroundColor: appColors.white,
          ...shadow,
          padding: scale(15),
          // borderRadius: scale(5),
          height: '100%'
        }}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '100%'
          }}>
        </View>
        <OtpVerification></OtpVerification>
      </View>
       </ScrollView>
    </SafeAreaView>
  );
}

export default ReduxWrapper(index)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 10,
    height: '100%',
    backgroundColor: appColors.white
  },
  button: {
    alignItems: "center",
    backgroundColor: "#DDDDDD",
    padding: 10
  },
  countContainer: {
    alignItems: "center",
    padding: 10
  },
  textInputStyle: {
    color: appColors.black,
    fontFamily: "UVNTinTucHepThemBold",
    fontSize: scale(18),
    width: '100%'
  },
});