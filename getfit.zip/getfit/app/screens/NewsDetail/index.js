import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, TouchableOpacity, Image, ScrollView} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import {appColors, shadow} from '../../utils/appColors';
import { useFocusEffect } from '@react-navigation/native';
import { getDetailPostCategory } from '../../redux/categoryAction';
import { connect } from 'react-redux';
import BookingHeader from '../../components/BookingHeader';
import Spinner from '../../components/Spinner';
import {BASE_URL} from '../../../app.json';
import { isRealValue } from '../../utils/HelperFunctions';

function NewsDetail({post, route: {params}, navigation}) {
  
    let HTML = `
    <!doctype html>
    <html>
        <head>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700%7CLato%7CKalam:300,400,700" />
        <link rel="stylesheet" href="https://mall.getfit.vn/templates/cosmetics/assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://mall.getfit.vn/templates/cosmetics/assets/css/style.css">
        <link rel="stylesheet" href="https://mall.getfit.vn/templates/cosmetics/css/fonts.css">
        </head>
        <body>
            <div class="blog blog-inner">
            ###content###
            </div>
        </body>
    </html>
    `

  return (
    <SafeAreaView  style={styles.container}>
        <BookingHeader title={'Getfit Booking'} navigation={navigation}>
            <Text style={{
                fontFamily: 'OpenSans-Bold',
                color: appColors.BLACK,
                fontSize: scale(20),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>Chi tiết</Text>
        </BookingHeader>

        {isRealValue(post?.descriptions) ? 
        <ScrollView nestedScrollEnabled showsHorizontalScrollIndicator={false}
            contentContainerStyle={{flexGrow:1}}
        >
            <View style={{
                flex: 1,
                marginHorizontal: scale(5)
            }}>
                <Text style={{
                    marginVertical: scale(15),
                    fontFamily: 'OpenSans-Bold',
                    fontWeight: '700',
                    fontSize: scale(16)
                }}>{post.descriptions.title}</Text>
                
                <WebView
                    originWhitelist={['*']}
                    source={{ 
                        //html: HTML.replace('###content###', post.descriptions.content),
                        uri: post.url,
                        baseUrl: BASE_URL
                    }}
                    scalesPageToFit={(Platform.OS === 'ios') ? false : true}
                    javaScriptEnabled={true}
                    javaScriptEnabledAndroid={true}
                />
                
            </View>
        </ScrollView>
        :
        <Spinner />
        }
    </SafeAreaView>
  );
}

const mapStateToProps = (state) => ({
    post : state.categories.cmsPost,
 });
 const mapDispatchToProps = {
    getDetailPostCategory$: getDetailPostCategory
 };
 
 export default connect(mapStateToProps, mapDispatchToProps)(NewsDetail);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE,
    },
});
