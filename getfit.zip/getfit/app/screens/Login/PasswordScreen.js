import React, { useState } from 'react'
import { SafeAreaView, ScrollView, TouchableOpacity, StyleSheet, View, Text, ImageBackground, Image, Pressable } 
from 'react-native'
import TextInput from '../../components/TextInput'
import BackButton from '../../components/BackButton'
import { theme } from '../../core/theme'
import { mobileValidator } from '../../helpers/mobileValidator'
import { passwordValidator } from '../../helpers/passwordValidator'
import { codeValidator } from '../../helpers/codeValidator'
import { scale } from 'react-native-size-matters'
import {appColors, shadow} from '../../utils/appColors';
import { AlertHelper } from '../../utils/AlertHelper'
import ReduxWrapper from '../../utils/ReduxWrapper'
import Feather from 'react-native-vector-icons/dist/Feather';
import Label from '../../components/Label'
import OtpVerification from '../../components/Otp/OtpVerification'
import auth from '@react-native-firebase/auth';
import Spinner from '../../components/Spinner'

function PasswordScreen({isLoggedIn, login$, resetPassword, sendOtp, verifyOtp, route, navigation}) {
  const { mobile } = route.params;
  const [code, setCode] = useState({ value: 'hosco', error: '' })
  const [username, setUsername] = useState({ value: mobile, error: '' })
  const [password, setPassword] = useState({ value: '', error: '' })

  // If null, no SMS has been sent
  const [confirm, setConfirm] = useState(null);

  const [resetPass, setResetPass] = useState(false);
  const [loading, setLoading] = useState(false);

  if(isLoggedIn) {
    navigation.navigate('Home');
  }

  // Handle the button press
  async function signInWithPhoneNumber() {
    let formattedValue = '+84' + parseInt(mobile, 10);
    
    try {
      const confirmation = await auth().signInWithPhoneNumber(formattedValue, true);
      setConfirm(confirmation);
    } catch (error) {
      AlertHelper.show("error","SMS: lỗi gửi mã OTP");
    } 
  }

  const onLoginPressed = () => {
    setLoading(true);
    const mobileError = mobileValidator(username.value)
    const passwordError = passwordValidator(password.value)
    const codeError = codeValidator(code.value)
    
    if (mobileError || passwordError || codeError) {
      setUsername({ ...username, error: mobileError })
      setPassword({ ...password, error: passwordError })
      setCode({ ...code, error: codeError })
      AlertHelper.show("error","Đã có lỗi xảy ra")
      return
    }

    try {
      let data = {
        phone: username.value,
        password: password.value,
        tenant_code: code.value,
      }
      if(!resetPass) {
        login$(data, onSuccess, onError);
      } else {
        resetPassword(data, onSuccess, onError);
      }
    } catch (error) {
        setLoading(false);
        AlertHelper.show("error","Đã có lỗi xảy ra")
    }
  }

  const onSuccess = (data) => {
    setLoading(false);
    AlertHelper.show("success", data.meta.message);
    navigation.navigate('Home');
  };

  const onError = (error) => {
    setLoading(false);
    AlertHelper.show("error", error)
  };

  const phoneFormat = (input) => {
    if(!input || isNaN(input)) return `input must be a number was sent ${input}`
    if(typeof(input) !== 'string') input = input.toString()
    if(input.length === 10){
      return input.replace(/(\d{4})(\d{3})(\d{3})/, "$1.$2.$3");
    } else if(input.length < 10){
       return 'was not supplied enough numbers please pass a 10 digit number'
    }
  }

  if (confirm) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled>
          <BackButton goBack={navigation.goBack} />
          <View
            style={{
              flex: 1,
              marginTop: scale(50),
              ...shadow,
              padding: scale(15),
              height: '100%'
            }}>
            <View
              style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: '100%'
              }}>
            </View>
            <OtpVerification 
              verifyOtp={verifyOtp}
              setConfirm={setConfirm}
              setResetPass={setResetPass}
              otpRequestData={{
                username: mobile, 
                phone_no: '+84' + parseInt(mobile, 10), 
                confirm: confirm,
                navigation: navigation,
                reset_pass: resetPass,
              }}></OtpVerification>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }


  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
      <BackButton goBack={navigation.goBack} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-start',
          marginTop: scale(70),
          ...shadow,
        }}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
          <Label
            text="Anh chị vui lòng nhập mật khẩu (gồm 6 chữ số)"
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(18),
              textAlign: 'left',
              flex:1, 
              justifyContent:"center",
              alignItems:"center",
              marginBottom: 10,
            }}
          />
        </View>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            height: '100%'
          }}>
          <Label
            text="Số điện thoại đăng ký"
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              textAlign: 'left',
              flex:1, 
              justifyContent:"flex-start",
              alignItems:"center",
              marginBottom: 0,
            }}
          />

          <Label
            text={phoneFormat(mobile)}
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              fontWeight: "700",
              textAlign: 'left',
              flex:1, 
              justifyContent:"flex-start",
              marginBottom: 0,
            }}
          />
        </View>
      
        <View style={{paddingVertical: scale(10)}}>          
              <View style={{
                justifyContent:'flex-start', 
                flex: 1,
                flexDirection: 'row',
                paddingVertical: scale(10)
              }}>
                <TextInput
                  label=""
                  returnKeyType="done"
                  value={password.value}
                  onChangeText={(text) => setPassword({ value: text, error: '' })}
                  error={!!password.error}
                  errorText={password.error}
                  secureTextEntry
                  mode="flat"
                  selectionColor={appColors.BLACK}
                  style={{ 
                    backgroundColor: appColors.WHITE,
                    borderBottomWidth: 1,
                    borderBottomColor: appColors.DARK_GREY,
                    alignSelf: 'stretch',
                    fontSize: scale(14)
                  }} 
                  placeholder="Mật khẩu"
              /> 
              </View>
              <View style={{
                justifyContent:'center', 
                flex: 1,
                flexDirection: 'row',
                paddingVertical: scale(10)
              }}>
              <Pressable
                onPress={() => {
                  let data = {
                    phone: username.value,
                  }
                  sendOtp(data, (result) => {
                    setResetPass(true);
                    setConfirm(true);
                  }, (error) => {
                    console.log(error);
                  });
                  
                  //signInWithPhoneNumber();
                }}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                }}>
                <Label
                  text="Quên mật khẩu ?"
                  style={{
                    fontSize: scale(14),
                    fontWeight: '600',
                    color: appColors.RED
                  }}
                />
              </Pressable>
              </View>

              <View style={{
                justifyContent:'flex-end', 
                flex: 1,
                flexDirection: 'row',
                paddingVertical: scale(20)
              }}>
                <TouchableOpacity
                  onPress={onLoginPressed}
                  disabled={password.value === ""}
                  style={{
                      borderWidth:0,
                      borderColor:'rgba(0,0,0,0.2)',
                      alignItems:'center',
                      justifyContent:'center',
                      width:70,
                      height:70,
                      backgroundColor: password.value.length > 5 ? '#fe6700' : '#fe9000',
                      borderRadius:50,
                    }}
                >
                  <Feather name={"arrow-right"} size={scale(24)} color={appColors.white}  />
                </TouchableOpacity>
              </View>
        </View>        
      </View>
      </ScrollView>
      {loading && <Spinner /> }
    </SafeAreaView>
  );
}

export default ReduxWrapper(PasswordScreen)

const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent: "center",
        paddingHorizontal: 10,
        height: '100%',
        backgroundColor: appColors.white
    },
  forgotPassword: {
    width: '100%',
    alignItems: 'flex-end',
    marginBottom: 100,
    paddingVertical: scale(5)
  },
  row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  forgot: {
    fontSize: 13,
    color: theme.colors.secondary,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
  view: {
    position: 'absolute',
    backgroundColor: 'transparent'
  },
  touchable: {
    //marginTop: scale(150),
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: 'cover',
    width: '100%',
    height: 40
  },
  text: {
    fontSize: 18,
    textAlign: 'center'
  }
})