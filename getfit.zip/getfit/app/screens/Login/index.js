import React, {useRef, useState} from 'react';
import {StyleSheet, View, Text, Pressable, TouchableOpacity, ImageBackground } from 'react-native';
import {scale} from 'react-native-size-matters';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import auth from '@react-native-firebase/auth';
import { AlertHelper } from '../../utils/AlertHelper';
import ReduxWrapper from '../../utils/ReduxWrapper';
import TextInput from '../../components/TextInput';
import BackButton from '../../components/BackButton';
import { ScrollView } from 'react-native-gesture-handler';
import Feather from 'react-native-vector-icons/dist/Feather';
import { SafeAreaView } from 'react-native-safe-area-context';
import OtpVerification from '../../components/Otp/OtpVerification';
import Spinner from '../../components/Spinner';


function Login({isLoggedIn, login$, checkPhone, verifyOtp, navigation}) {
  
  /*
  const [authenticated, setAutheticated] = useState(false);
  auth().onAuthStateChanged((user) => {
    if(user) {
      setAutheticated(true);
      let data = {
        username: username,
        tenant_code: 'hosco'
      }
      
      login$(data, onSuccess, onError)
    } else {
      setAutheticated(false);
    }
  })*/

  if(isLoggedIn) {
    navigation.navigate('Home');
  }
  
  const [credentials, setCredentials] = useState({});
  const [username, setUsername] = useState('');
  const [formattedValue, setFormattedValue] = useState("");

  // If null, no SMS has been sent
  const [confirm, setConfirm] = useState(null);
  const [loading, setLoading] = useState(false);
  const [animating, setAnimating] = useState(false);

  // Handle the button press
  async function signInWithPhoneNumber() {
    try {
      const confirmation = await auth().signInWithPhoneNumber(formattedValue, true);
      setConfirm(confirmation);
    } catch (error) {
      AlertHelper.show("error","SMS: lỗi gửi mã OTP");
    } 
    //const confirmation = await auth().signInWithPhoneNumber(formattedValue, true);
    //setConfirm(confirmation);
  }

  const checkMobile = async () => {
    setAnimating(true);
    setLoading(true);
    checkPhone({phone: username}, onCheckPhoneSuccess, onCheckPhoneError);
  };

  const onCheckPhoneSuccess = (data) => {
    setAnimating(false);
    setLoading(false);
    if(data.data.error === 0) {
      navigation.navigate('PasswordScreen', {mobile: username});
    } else {
      //signInWithPhoneNumber();
      setConfirm(true)
    }
  };

  const onCheckPhoneError = (error) => {
    setAnimating(false);
    setLoading(false);
    AlertHelper.show("error", error)
  };

  const onChangeText = (name, text) => {
    setCredentials({...credentials, [name]: text});
  };

  if (confirm) {
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={true} nestedScrollEnabled>
          <BackButton goBack={navigation.goBack} />
          <View
            style={{
              flex: 1,
              marginTop: scale(50),
              ...shadow,
              padding: scale(15),
              height: '100%'
            }}>
            <View
              style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                height: '100%'
              }}>
            </View>
            <OtpVerification 
              verifyOtp={verifyOtp}
              otpRequestData={{
                username: username, 
                phone_no: formattedValue, 
                confirm: confirm,
                navigation: navigation,
                reset_pass: false
              }}></OtpVerification>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={true}>
      <BackButton goBack={navigation.goBack} />
      <View
        style={{
          flex: 1,
          justifyContent: 'flex-start',
          marginTop: scale(60),
          ...shadow,
        }}>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
          <Label
            text="Số điện thoại của anh/chị là gì ạ?"
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(18),
              textAlign: 'left',
              flex:1, 
              justifyContent:"center",
              alignItems:"center",
              marginVertical: scale(20),
            }}
          />
        </View>
      
        <View style={{paddingVertical: scale(20)}}>
          <View style={{
                  justifyContent:'flex-start', 
                  flex: 1,
                  flexDirection: 'row',
                  paddingVertical: scale(10)
                }}>
              <TextInput
                label=""
                //keyboardType={'phone-pad'}
                maxLength={10}
                returnKeyType="done"
                value={username}
                onChangeText={(text) => {
                  setUsername(text); 
                  setFormattedValue('+84' + parseInt(text, 10));
                }}
                //error={!!username}
                //errorText={username}
                //secureTextEntry
                mode="flat"
                selectionColor={appColors.BLACK}
                style={{ 
                  backgroundColor: appColors.WHITE,
                  borderBottomWidth: 1,
                  borderBottomColor: appColors.DARK_GREY,
                  alignSelf: 'stretch',
                  fontSize: scale(16)
                }} 
                placeholder="0000000000"
            /> 
          </View>
          <View style={{
            justifyContent:'flex-end', 
            flex: 1,
            flexDirection: 'row',
            paddingVertical: scale(30)
          }}>
            <TouchableOpacity
              onPress={checkMobile}
              disabled={(username.length < 10 || loading)}
              style={{
                  borderWidth:0,
                  borderColor:'rgba(0,0,0,0.2)',
                  alignItems:'center',
                  justifyContent:'center',
                  width:70,
                  height:70,
                  backgroundColor: username.length > 9 ? '#fe6700' : '#fe9000',
                  borderRadius:50,
                }}
            >
              <Feather name={"arrow-right"} size={scale(24)} color={appColors.white}  />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      </ScrollView>
      {loading && <Spinner /> }
    </SafeAreaView>
  );
}

export default ReduxWrapper(Login)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 10,
    height: '100%',
    backgroundColor: appColors.white
  },
  countContainer: {
    alignItems: "center",
    padding: 10
  },
  textInputStyle: {
    color: appColors.black,
    fontFamily: "UVNTinTucHepThemBold",
    fontSize: scale(18),
    width: '100%'
  },
});