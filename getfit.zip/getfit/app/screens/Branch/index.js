import React, { useCallback, useEffect, useState } from 'react';
import {View, Text, StyleSheet, FlatList, Pressable, RefreshControl, Image, Switch} from 'react-native';
import {scale} from 'react-native-size-matters';
import { SafeAreaView } from 'react-native-safe-area-context';
import Label from '../../components/Label';
import {appColors, shadow} from '../../utils/appColors';
import ReduxWrapper from '../../utils/ReduxWrapper';
import { useFocusEffect } from '@react-navigation/native';
import Spinner from '../../components/Spinner';
import { PT_LIST_URL } from '../../services/config';
import { api } from '../../services/api';

function index({branchList, getMemberBranchs, setBranch, setIsBranchSelected, order, onPtSuccess, navigation}) {
  const BranchCard = ({item}) => {
    const {address, description, avatar} = item;
    return (
        <Pressable onPress={async () => {
          if(order) {
            try {
              const result = await api.get(PT_LIST_URL, {params: {order_id: order.order_id}}, {crossDomain: true});
              onPtSuccess(result.data.data, item, order);
            } catch {
              onPtSuccess([], item, order);
            }
          }
            setBranch(item);
            setIsBranchSelected(false);
        }} >
      <View style={styles.contentContiner}>
        <View>
          <Image source={{uri: avatar}} style={{width: 160, height: 120}}/>
        </View>
        <View style={{
          flex: 1,
            // flexWrap: 'wrap',
            // alignItems: 'flex-start',
            flexShrink: 1,
            marginLeft: scale(10),
            // paddingTop: 10
        }}>
          <View>
          <Label
            text={address}
            style={{
                fontFamily: 'OpenSans-Bold',
                fontSize: scale(13),
                paddingBottom: scale(5)
            }}
          />
          </View>
          <View>
          <Label
            text={description}
            style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(11),
              color: appColors.black,
              // paddingVertical: scale(10),
            }}
          />
          </View>
        </View>
      </View>
      </Pressable>
    );
  };

  const [refreshing, setRefreshing] = useState(false);
  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);

  const wait = (timeout) => {
    return new Promise(resolve => {
        setTimeout(resolve, timeout);
    });
  }

  const onRefresh = useCallback(() => {
        setRefreshing(true);
        getMemberBranchs();
        wait(2000).then(() => setRefreshing(false));
  }, []);

  useFocusEffect(useCallback(() => {
      getMemberBranchs();
  }, []));

  return (
    <SafeAreaView  style={styles.container}>
      <View style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginVertical: scale(15),
        marginHorizontal: scale(5),
        alignItems: 'center',
        borderBottomColor: appColors.DARK_GREY,
        borderBottomWidth: .7,
        paddingBottom: scale(15)
      }}>
        <Text style={{
          fontFamily: 'OpenSans-Bold',
          fontSize: scale(14),
        }}>Có chỗ đâu ôtô 
          <Text style={{
            fontFamily: 'OpenSans-Regular', 
            fontSize: scale(12),
            color: appColors.gray,
          }}> (Có thể mất phí)</Text>
        </Text>
        <Switch
          trackColor={{ false: "#767577", true: "#6D6D6D" }}
          
          thumbColor={isEnabled ? "#FE8800" : "#f4f3f4"}
          ios_backgroundColor="#3e3e3e"
          onValueChange={toggleSwitch}
          value={isEnabled}
        />
      </View>
      {branchList.length == 0 ? <Spinner /> : 
        <FlatList
          refreshing={refreshing} 
          onRefresh={onRefresh}
          keyExtractor={(item)=> `${item.branch_id}_${new Date().getTime()}_${item.branch_id}`}
          ItemSeparatorComponent={() => <View style={{padding: scale(2)}} />}
          data={branchList}
          renderItem={({item, index}) => <BranchCard key={index} item={item} />}
        />
      }
    </SafeAreaView>
  );
}

export default ReduxWrapper(index)

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: appColors.WHITE,
    },
  contentContiner: {
    paddingVertical: scale(5),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(5),
    borderBottomWidth: scale(.2),
    borderBottomColor: appColors.LIGHT_GREY,
    // ...shadow,
  },
});
