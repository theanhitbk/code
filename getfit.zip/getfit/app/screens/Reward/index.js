import React,{useState,useEffect, useCallback} from 'react'
import { View, Text, StyleSheet, SafeAreaView, Image, Pressable, FlatList, Platform, ScrollView, ImageBackground } from 'react-native'
import ReduxWrapper from '../../utils/ReduxWrapper';
import { scale } from 'react-native-size-matters';
import { appColors } from '../../utils/appColors';
import BookingHeader from '../../components/BookingHeader';
import { useFocusEffect } from '@react-navigation/native';

function Reward({isLoggedIn, userInfo, resetBook$, getPTSchedules, addBooking$, navigation}) 
{

    useFocusEffect(useCallback(() => {
        if(!isLoggedIn) {
            navigation.navigate('Login')
        }
    }, []));

    return (
    <>
        <BookingHeader title={'NextCRM Rewards'} isback navigation={navigation}>
            <Text style={{
                color: appColors.BLACK,
                fontSize: scale(16),
                fontWeight: '500',
                textAlignVertical: 'center',
            }}>Ưu đãi dành riêng cho anh/chị</Text>
          
        </BookingHeader>
        <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
            <ScrollView>
                <View style={{
                    flex: 1, 
                    flexDirection: 'row', 
                    justifyContent: 'flex-end',
                    marginVertical: scale(10)
                }}>
                    <Text style={{fontSize: scale(14), 
                        color: appColors.darkGray, 
                        marginRight: scale(10),
                    }}>Xem tất cả</Text>
                </View>
                
                <ImageBackground
                source={require('../../static/images/reward-bg.png')}
                resizeMode="stretch"
                style={{
                    flex: 1,
                    width: '100%',
                    paddingVertical: scale(80)
                }}
                >
                    <View style={{justifyContent:'center', alignItems: 'center'}}>
                        <Text style={{fontSize: scale(20), color: appColors.lightGray}}>
                            Không có dữ liệu
                        </Text>
                    </View>
                </ImageBackground>
                <View style={{marginHorizontal: scale(15), marginVertical: scale(20)}}>
                    <Text style={{
                        fontFamily: "UVNTinTucHepThemBold",
                        fontSize: scale(18),
                        textTransform: 'uppercase',
                        fontWeight: '700'
                    }}>Ưu đãi từ NextCRM</Text>
                    
                    <View style={{flex: 1, flexDirection: 'row', marginTop: scale(15)}}>
                        <View style={{
                            borderWidth:1,
                            borderColor: '#d6d8dd',
                            borderRadius: scale(50),
                            backgroundColor: '#d6d8dd',
                            width: scale(45),
                            height: scale(45),
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <Image source={require('../../static/images/icon-reward.png')} 
                                style={{
                                    width: scale(20), 
                                    height: scale(20), 
                                    alignItems: 'center',
                                }}
                            />
                        </View>
                        <View style={{marginHorizontal: scale(15)}}>
                            <Text style={{fontSize: scale(16), fontWeight: '700'}}>Ưu đãi MUA 1 TẶNG 2</Text>
                            <Text style={{color: appColors.darkGray}}>Nhận mã ưu đãi bất ngờ mỗi tháng</Text>
                        </View>
                    </View>
                    <View style={{flex: 1, flexDirection: 'row', marginVertical: scale(15)}}>
                        <View style={{
                            borderWidth:1,
                            borderColor: '#d6d8dd',
                            borderRadius: scale(50),
                            backgroundColor: '#d6d8dd',
                            width: scale(45),
                            height: scale(45),
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <Image source={require('../../static/images/icon-clock.png')} 
                                style={{
                                    width: scale(20), 
                                    height: scale(20), 
                                    alignItems: 'center',
                                }}
                            />
                        </View>
                        <View style={{marginHorizontal: scale(15)}}>
                            <Text style={{fontSize: scale(16), fontWeight: '700'}}>Ưu đãi gia hạn</Text>
                            <Text style={{color: appColors.darkGray}}>Đặt trước lịch 3 ngày</Text>
                        </View>
                    </View>
                    <View style={{flex: 1, flexDirection: 'row'}}>
                        <View style={{
                            borderWidth:1,
                            borderColor: '#d6d8dd',
                            borderRadius: scale(50),
                            backgroundColor: '#d6d8dd',
                            width: scale(45),
                            height: scale(45),
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <Image source={require('../../static/images/icon-user2.png')} 
                                style={{
                                    width: scale(20), 
                                    height: scale(20), 
                                    alignItems: 'center',
                                }}
                            />
                        </View>
                        <View style={{marginHorizontal: scale(15)}}>
                            <Text style={{fontSize: scale(16), fontWeight: '700'}}>Ưu đãi free</Text>
                            <Text style={{color: appColors.darkGray}}>Được yêu cầu phục vụ riêng khi đặt trước lịch</Text>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    </>
    )
}

export default ReduxWrapper(Reward)

const styles = StyleSheet.create({
  
})