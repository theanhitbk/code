import React, {useCallback, useEffect, useRef, useState} from 'react';
import {StyleSheet, Text, View, FlatList, TouchableOpacity, Image, Pressable, ImageBackground, Dimensions, Linking, useWindowDimensions, Animated} from 'react-native';
import {appColors, shadow} from '../../utils/appColors';
import Label from '../../components/Label';
import Product from '../../components/ProductCard';
import {scale} from 'react-native-size-matters';
import ReduxWrapper from '../../utils/ReduxWrapper';
import { SafeAreaView } from 'react-native-safe-area-context';
import Feather from 'react-native-vector-icons/dist/Feather';
import {FlatListSlider} from 'react-native-flatlist-slider';
import { useFocusEffect } from '@react-navigation/native';
import { TabBar, TabView } from 'react-native-tab-view';
import Spinner from '../../components/Spinner';
import { HotCategoryItem } from '../../components/HotCategoryItem';
import { GuideItem } from '../../components/GuideItem';

function Shop({isLoggedIn, userInfo, cartItems, config, hotCategoryList, 
    getHomeDatas, categoryList, getCategories, getHotCategories$,
    featuredProductList, getFeaturedProducts, getProducts$, getShippingAddress$,
    getProduct$, getDetailPostCategory$, addToCart$, searchKeyword$, navigation
  }) {

  const [index, setTabIndex] = useState(0);
  const ref = useRef(null);
  const ref1 = useRef(null);
  const ref3 = useRef(null);
  const ref4 = useRef(null);
  const ref5 = useRef(null);
  
  const layout = useWindowDimensions();
  
  useFocusEffect(useCallback(() => {
     if(!isLoggedIn) {
      navigation.navigate('Login')
     }

     getFeaturedProducts()
     getCategories()
     getHotCategories$()
  }, []));

  let routes = [];
  hotCategoryList?.forEach(cat => {
    routes.push({key: cat.id.toString(), title: cat.title});
  });

  const _renderTabBar = (props) => (
    <TabBar
      {...props}
      scrollEnabled
      renderLabel={({ route, focused, color }) => (
        <Text numberOfLines={2} 
          style={{ 
            color: appColors.black, 
            fontFamily: 'OpenSans-SemiBold',
            fontSize: scale(13)
        }}>
          {route.title}
        </Text>
      )}
      indicatorStyle={{ backgroundColor: '#FE6600' }}
      style={{ 
        backgroundColor: appColors.WHITE, 
        color: appColors.BLACK,
        marginHorizontal: scale(0),
        marginBottom: scale(10),
        paddingHorizontal: scale(0)
      }}
      tabStyle={{
        width: 'auto'
      }}
    />
  );

  const renderScene = ({route}) => {
    let dataList = [];
    hotCategoryList.forEach((elm) => {
      if(route.key === elm.id.toString()) {
        dataList = elm.products
      }
    });

      return(
      <View style={{ flex: 1, backgroundColor: appColors.WHITE }}>
        <FlatList
          ref={ref5}
            listKey={'product_tab'}
            keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_product`}
            showsHorizontalScrollIndicator={false}
            ItemSeparatorComponent={() => <View style={{padding: scale(3)}} />}
            horizontal
            data={dataList}
            renderItem={({item, idx}) => (<Product key={'pro_' + idx} navigation={navigation} item={item} isHorizontal/>)}
          />
      </View>
    );
  };

  const renderItem = ({ item }) => (
    <View style={{flex: 1, marginHorizontal: scale(3), marginVertical: scale(3)}}>
      <TouchableOpacity onPress={async () => {
        if(item.id_product) {
          getProduct$(item.id_product)
          item.id = item.id_product
          console.log(item)
          navigation.navigate('ProductDetails', {item: item})
        }
        /*
        if(item.url) {
          const supported = await Linking.canOpenURL(item.url);
          if(supported) {
            await Linking.openURL(item.url);
          }
        }*/
      }}>
        <Image
            source={{uri: item.image}}
            style={{ 
                flex: 1, 
                borderRadius: scale(4), 
                height: 120, 
                // resizeMode: 'contain', 
                alignSelf: 'stretch', 
                width: null 
            }}
        />
      </TouchableOpacity>
    </View>
  );

  const renderHotCategoryItem = ({item, index}) => (
    <HotCategoryItem key={'hot_cat_' + index} category={item} navigation={navigation} getProducts={getProducts$}/>
  );

  const renderFeaturedProduct = ({item}) => (
    <Product key={'fpro_' + item.id} navigation={navigation} item={item} isHorizontal/>
  );

  const renderBrands = ({item}) => (
    <TouchableOpacity onPress={async () => {
      if(item.url) {
        const supported = await Linking.canOpenURL(item.url);
        if(supported) {
          await Linking.openURL(item.url);
        }
      }
    }}>
    <View style={{
      flex: 1, 
      marginHorizontal: scale(1),
      borderWidth: .5,
      borderColor: appColors.lightGray,
      marginBottom: scale(10)
    }}>
      <Image
          source={{uri: item.image}}
          style={{ 
              flex: 1, 
              borderRadius: scale(4), 
              width: 120,
              height: 120, 
              // resizeMode: 'contain', 
              //alignSelf: 'stretch', 
              // width: null 
          }}
      />
    </View>
    </TouchableOpacity>
  );

  const renderGuide = ({item}) => (
    <GuideItem item={item} getDetailPostCategory={getDetailPostCategory$} navigation={navigation} />
  );

  return (
    <>
      <SafeAreaView style={{flex: 1}}>
        <View style={{
          flex: 1,
          textAlignVertical: 'center',
          backgroundColor: '#f7f7f7',
        }}>
            <ImageBackground
            source={require('../../static/images/header_bg.png')}
            resizeMode="stretch"
            style={{
                height: scale(110),
                backgroundColor: '#f7f7f7'
            }}
            >
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: scale(10)
                    }}>
                    <Image
                        source={require('../../static/images/logo_1.png')}
                        style={{
                        width: 120, 
                        height: 80, 
                        resizeMode: 'contain',
                        alignSelf: 'stretch',
                        }}
                    />
                </View>
                <View style={{
                    flexDirection: 'row',
                    marginHorizontal: scale(10)
                }}>
                    <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'flex-start',
                        }}>
                        <Pressable onPress={() => navigation.navigate('Address')}>
                          <Text style={{
                            fontFamily: 'OpenSans-SemiBold',
                              color: appColors.BLACK,
                              fontSize: scale(12),
                              backgroundColor: appColors.lightGray,
                              borderRadius: scale(6),
                              marginHorizontal: scale(5),
                              paddingHorizontal: scale(5),
                              paddingVertical: scale(2)
                          }}>Sổ địa chỉ</Text>
                        </Pressable>
                        <Pressable onPress={() => navigation.navigate('Orders')}>
                          <Text style={{
                            fontFamily: 'OpenSans-SemiBold',
                              color: appColors.BLACK,
                              fontSize: scale(12),
                              backgroundColor: appColors.lightGray,
                              borderRadius: scale(6),
                              marginHorizontal: scale(5),
                              paddingHorizontal: scale(5),
                              paddingVertical: scale(2)
                          }}>Đơn hàng</Text>
                        </Pressable>
                    </View>
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        marginRight: scale(20)
                    }}>
                      <Pressable onPress={() => {
                        searchKeyword$();
                        navigation.navigate('Search');
                      }}>
                        <Feather name='search' 
                        size={scale(16)}
                        style={{
                            
                        }} />
                        </Pressable>
                        <Pressable onPress={() => {
                          getShippingAddress$();
                          navigation.navigate('Cart');
                        }}
                          style={{
                            borderRadius: scale(25),
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'relative'
                          }}
                        >
                          <Feather name='shopping-cart' 
                          size={scale(16)}
                          style={{
                              paddingHorizontal: scale(10)
                          }}
                          />
                          {cartItems.length > 0 && <View style={{
                            position: 'absolute', 
                            top: -10, 
                            right: 5, 
                            width: scale(16),
                            height: scale(16),
                            backgroundColor: appColors.RED, 
                            borderRadius: scale(10),
                            paddingHorizontal: 5,
                            paddingVertical: 1.5,
                            alignItems: 'center'
                          }}>
                            <Text style={{
                              color: appColors.WHITE, 
                              fontSize: scale(10),
                            }}>{cartItems.length}</Text>
                          </View>
                          }
                        </Pressable>
                        <Feather name='align-right'
                            size={scale(16)}
                            style={{
                            }}
                        />
                    </View>
                </View>
            </ImageBackground> 

            <View style={{flex: 1, marginTop: scale(10), backgroundColor: appColors.WHITE}}>
              {routes.length === 0 ? <Spinner /> :
              <FlatList
                ListHeaderComponent={
                  <>
                    <FlatListSlider 
                      data={config.banners} 
                      height={220}
                      listKey={'banner'}
                      keyExtractor={(item)=> `banner_${new Date().getTime()}_product`}
                      // contentContainerStyle={{paddingHorizontal: 16}}
                      indicatorContainerStyle={{position:'absolute', bottom: -20}}
                      //indicatorActiveColor={'#8e44ad'}
                      //indicatorInActiveColor={'#ffffff'}
                      // indicatorActiveWidth={10}
                      indicatorActiveWidth={15}
                      indicatorStyle={{width: 15, height: 15, borderRadius: 50}}
                      inactiveDotStyle={{width:scale(20)}}
                      animation
                      onPress={item => console.log('testt')}
                    />
                    <View style={{marginVertical: scale(10)}}>
                      <FlatList
                        ref={ref4}
                        style={{margin: scale(10),}}
                        contentContainerStyle={{
                          flex: 1,
                          flexDirection: 'column',
                          justifyContent: 'center',
                        }}
                        listKey={'category'}
                        keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_category`}
                        showsHorizontalScrollIndicator={false}
                        //horizontal
                        numColumns={4}
                        data={categoryList}
                        ItemSeparatorComponent={() => <View style={{padding: scale(10)}} />}
                        //renderItem={_renderCatItem}
                        renderItem={renderHotCategoryItem}
                      />
                    </View>

                    <View style={{flex: 1}}>
                      <View style={{paddingVertical: scale(20)}}>
                          <View
                              style={{
                              flexDirection: 'row',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              borderBottomColor: appColors.RED,
                              borderBottomWidth: scale(1)
                              }}>
                              <View style={{}}>
                                  <Label
                                  text={'Top Sản phẩm nổi bật'}
                                  style={{
                                    fontFamily: 'OpenSans-Bold',
                                      fontSize: scale(18),
                                      textTransform: 'uppercase',
                                      color: appColors.RED,
                                      paddingLeft: 10
                                  }}
                                  />
                              </View>
                              <Feather name='chevron-right' size={scale(20)} color={appColors.darkGray}/>
                          </View>
                      </View>
                      <View style={{flex: 2}}>
                        <FlatList
                        ref={ref3}
                        nestedScrollEnabled
                        listKey={'product_featured'}
                        keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_product_featured`}
                        showsHorizontalScrollIndicator={false}
                        ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
                        horizontal
                        data={featuredProductList}
                        renderItem={renderFeaturedProduct}
                        stickyHeaderIndices={[0]}
                        />
                      </View>
                  </View>
                  </>
                }     
                ref={ref}
                numColumns={2}
                data={config.posters??[]}
                renderItem={renderItem}
                listKey={'shop'}
                showsHorizontalScrollIndicator={false}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, idx)=> `${item.id}_${new Date().getTime()}_shop_${idx}`}
                ListFooterComponent={
                  <>
                    <View style={{flex: 3}}>
                      <View style={{paddingVertical: scale(10), marginTop: scale(10)}}>
                          <View style={{
                            justifyContent: 'center', alignItems: 'center',
                            backgroundColor: '#FE8800',
                            paddingVertical: scale(25)
                          }}>
                              <Text style={{
                                fontFamily: 'OpenSans-Bold',
                                fontSize: scale(16),
                                textTransform: 'uppercase',
                                color: appColors.WHITE,
                              }}>{config.title_home}</Text>
                              <Text style={{
                                fontFamily: 'OpenSans-Bold',
                                fontSize: scale(12),
                                color: appColors.WHITE,
                              }}>{config.description_home}</Text>
                          </View>
                      </View>
                      <View style={{flex: 1, marginVertical: scale(0), minHeight: 400}}>
                        <TabView
                          renderTabBar={_renderTabBar}
                          navigationState={{ index, routes }}
                          renderScene={renderScene}
                          onIndexChange={setTabIndex}
                          initialLayout={{ width: layout.width }}
                          style={{  }}
                        />
                      </View>
                    </View>
                  
                    <View style={{marginVertical: scale(10)}}>
                      <View
                      style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      borderBottomColor: '#FE8800',
                      borderBottomWidth: scale(1)
                      }}>
                        <View style={{}}>
                          <Label
                          text={'Thương hiệu nổi bật'}
                          style={{
                            fontFamily: 'OpenSans-Bold',
                              fontSize: scale(18),
                              textTransform: 'uppercase',
                              color: appColors.BLACK,
                              padding: 5
                          }}
                          />
                        </View>
                      </View>
                      <View style={{flex: 1, marginVertical: scale(5)}}>
                        <FlatList
                          ref={ref1}
                          //nestedScrollEnabled
                          listKey={'brands'}
                          keyExtractor={(item, idx)=> `brand_${new Date().getTime()}_${idx}`}
                          showsHorizontalScrollIndicator={false}
                          ItemSeparatorComponent={() => <View style={{padding: scale(1)}} />}
                          horizontal
                          data={config.brands}
                          renderItem={renderBrands}
                          />
                      </View>

                      <View style={{
                        flex: 1, 
                        justifyContent: 'space-between', 
                        marginHorizontal: scale(10),
                      }}>
                        <FlatList
                          ref={ref1}
                          //nestedScrollEnabled
                          numColumns={2}
                          listKey={'poster-bottom'}
                          keyExtractor={(item, idx)=> `poster_bottom_${new Date().getTime()}_${idx}`}
                          showsHorizontalScrollIndicator={false}
                          ItemSeparatorComponent={() => <View style={{padding: scale(10)}} />}
                          data={config.posterBottoms}
                          renderItem={renderGuide}
                          />
                      </View>
                    </View>
                  </>
                }
              />
            }
            </View>
        </View>        
      </SafeAreaView>
    </>
  );
}
 
 export default ReduxWrapper(Shop)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative'
    //backgroundColor: '#FAF1E6',
    //paddingHorizontal: 0,
  },
  background: {
    flex: 1,
  },
  header: {
    backgroundColor: appColors.WHITE,
    alignItems: 'center',
    borderBottomWidth: 12,
    borderBottomColor: '#ddd',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 13,
    lineHeight: 30,
  },
  headerText: {
    color: 'white',
    fontSize: 25,
    padding: 20,
    margin: 20,
    textAlign: 'center',
  },
  TitleText: {
    fontSize: 25,
    // padding: 20,
    marginVertical: 20,
  },
  scrollContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  cardd: {
    // borderRadius: 10,
    //paddingVertical: 10,
    //paddingHorizontal: 0,
    width: '100%',
    //height: 120,
  },

  btnClickContain: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    backgroundColor: '#009D6E',
    borderRadius: 5,
    padding: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  btnContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    borderRadius: 10,
  },
  btnIcon: {
    height: 25,
    width: 25,
  },
  btnText: {
    fontSize: 18,
    color: '#FAFAFA',
    marginLeft: 10,
    marginTop: 2,
  },
  tabContainer: {
    width: 24,
    height: 24,
    position: 'relative',
  },
  tabBadge: {
    position: 'absolute',
    top: -12,
    right: -12,
    backgroundColor: 'red',
    borderRadius: 16,
    paddingHorizontal: 6,
    paddingVertical: 2,
    zIndex: 2,
  },
  tabBadgeText: {
    color: 'white',
    fontSize: 11,
    fontWeight: '600',
  },

  tabBar: {
    flexDirection: 'row',
    paddingVertical: scale(5),
    borderBottomWidth: scale(1.5),
    borderBottomColor: appColors.lightGray,
    marginBottom: 10
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
  },
});

// React Native cross-platform box shadow
const generateBoxShadowStyle = (
  xOffset,
  yOffset,
  shadowColorIos,
  shadowOpacity,
  shadowRadius,
  elevation,
  shadowColorAndroid,
) => {
  if (Platform.OS === 'ios') {
    styles.boxShadow = {
      shadowColor: shadowColorIos,
      shadowOffset: {width: xOffset, height: yOffset},
      shadowOpacity,
      shadowRadius,
    };
  } else if (Platform.OS === 'android') {
    styles.boxShadow = {
      elevation,
      shadowColor: shadowColorAndroid,
    };
  }
};

generateBoxShadowStyle(-2, 4, '#171717', 0.2, 3, 4, '#171717');