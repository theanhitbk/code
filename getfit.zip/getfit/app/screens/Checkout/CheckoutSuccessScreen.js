import React from 'react';
import {View, Text, FlatList, TextInput,KeyboardAvoidingView, ScrollView, Pressable } from 'react-native';
import Container from '../../components/Container';
import {bestSellersList} from '../../utils/MockData';
import CheckOutItem from '../../components/CheckOutItem';
import {scale} from 'react-native-size-matters';
import {appColors} from '../../utils/appColors';
import Label from '../../components/Label';
import CustomButton from '../../components/CustomButton';
import { SafeAreaView } from 'react-native-safe-area-context';
import Feather from 'react-native-vector-icons/dist/Feather';
import { currencyFormat } from '../../utils/HelperFunctions';

export default function CheckoutSuccessScreen({route: {params}, navigation}) {
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
        <ScrollView>
            <View style={{flex: 1, 
              justifyContent: 'center',
              alignItems: 'center',
              marginVertical: scale(30)
            }}>
                <Feather name='check-circle' size={80} 
                  color={appColors.GREEN}
                />
                <Text style={{
                    fontSize: scale(20), 
                    color: appColors.GREEN,
                    fontWeight: '700',
                    textTransform: 'uppercase',
                    marginTop: scale(20)
                }}>Đặt hàng thành công</Text>
            </View>
            <View style={{
              borderColor: appColors.lightGray,
              borderWidth: 1,
              marginHorizontal: scale(10),
              paddingHorizontal: scale(10),
              paddingVertical: scale(10)
            }}>
              <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: scale(10)}}>
                <Text style={{fontSize: scale(18), fontWeight: '700'}}>Thông Tin Đơn Hàng</Text>
              </View>
              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems:'center',
              }}>
                <Label text={'Mã đơn hàng'} style={{fontSize: scale(14), color: appColors.darkGray}}/>
                <Label text={'#QƯEE'} style={{fontWeight: '700'}}/>
              </View>
              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems:'center',
                paddingVertical: scale(10)
              }}>
                <Label text={'Trạng thái thanh toán'} style={{fontSize: scale(14), color: appColors.darkGray}}/>
                <Label text={'Chờ thanh toán'} style={{fontWeight: '700'}}/>
              </View>
              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems:'center',
              }}>
                <Label text={'Phương thức thanh toán'} style={{fontSize: scale(14), color: appColors.darkGray}}/>
                <Label text={'Chờ thanh toán'} style={{fontWeight: '700'}}/>
              </View>
              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems:'center',
                paddingVertical: scale(10)
              }}>
                <Label text={'Tổng thanh toán'} style={{fontSize: scale(14), color: appColors.darkGray}}/>
                <Label text={currencyFormat(params.item.dataTotal.total) + ' đ'} style={{fontWeight: '700', color: '#FE6600'}}/>
              </View>

              <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems:'center',
              }}>
                <Label text={'Thông tin nhận hàng'} style={{fontSize: scale(14), color: appColors.darkGray}}/>
                <Label text={'Chờ thanh toán'} style={{fontWeight: '700'}}/>
              </View>
            </View>

            <View style={{
              flexDirection: 'row', 
              marginHorizontal: scale(10),
              marginVertical: scale(20),
              justifyContent: 'space-between',
            }}>
                <Pressable onPress={() => console.log('123')}>
                  <View style={{
                    borderColor: appColors.lightGray,
                    borderWidth: 1,
                    paddingHorizontal: scale(14),
                    paddingVertical: scale(10),
                    borderRadius: scale(5),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: "center",
                  }}>
                    <Text style={{
                      fontSize: scale(16)
                    }}>Chi tiết đơn</Text>
                  </View>
                </Pressable>

                <Pressable onPress={() => navigation.navigate('Shop')}>
                <View style={{
                  borderColor: appColors.lightGray,
                  borderWidth: 1,
                  paddingHorizontal: scale(14),
                  paddingVertical: scale(10),
                  borderRadius: scale(5),
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: "center",
                  backgroundColor: '#FFCC30'
                }}>
                    <Text style={{
                        fontSize: scale(16),
                        paddingRight: scale(7)
                      }}>Tiếp tục mua sắm</Text>
                    <Feather name='arrow-right' size={scale(20)} />
                </View>
                </Pressable>
            </View>
        </ScrollView>
    </SafeAreaView>
  );
}
