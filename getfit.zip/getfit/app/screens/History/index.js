import React, {useCallback, useEffect, useRef, useState} from 'react';
import {StyleSheet, Text, View, TouchableOpacity, Image, Pressable, ImageBackground, Linking, SafeAreaView, ScrollView} from 'react-native';
import {appColors, shadow} from '../../utils/appColors';
import { Shadow } from 'react-native-shadow-2';
import Label from '../../components/Label';
import Container from '../../components/Container';
import Product from '../../components/ProductCard';
import {scale} from 'react-native-size-matters';
import TitleComp from '../../components/TitleComp';
import ReduxWrapper from '../../utils/ReduxWrapper';
import AvatarImage from '../../components/AvatarImage' 
import { useFocusEffect } from '@react-navigation/native';
import Feather from 'react-native-vector-icons/dist/Feather';
import { Button } from 'react-native-paper';
import { currencyFormat } from '../../utils/HelperFunctions';

function History({isLoggedIn, userInfo, getHomeDatas, navigation}) {

  const [badge, setBadge] = useState(5);

  useFocusEffect(useCallback(() => {
     if(!isLoggedIn) {
      navigation.navigate('Login')
     }

    getHomeDatas();

  }, []));
  
  return (
    <>
    <SafeAreaView style={{flex: 1, backgroundColor: appColors.WHITE}}>
      <View style={{flex: 1}}>
        <View style={{
          marginHorizontal:scale(0),
          backgroundColor: appColors.WHITE
        }}> 
            <View style={{
              flexDirection:'row', 
              justifyContent: 'center', 
              alignItems: 'center',
              marginVertical: scale(6)
            }}>
              <View style={{
                flex: 1,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'flex-start',
                marginLeft: scale(10),
              }}>
                <Pressable onPress={() => console.log('clicked')}>
                  <View style={styles.tabContainer}>
                  {(userInfo.number_of_notification > 0) &&
                      <View style={styles.tabBadge}>
                        <Text style={styles.tabBadgeText}>
                        {badge}
                        </Text>
                      </View>
                    }
                    <Image
                        source={require('../../static/images/icon-bell.png')}
                        style={{ width: 24, height: 24, resizeMode: 'contain' }}
                    />
                  </View>
                </Pressable>
              </View>
              <View style={{
                flex: 1,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
                  <Image
                      source={require('../../static/images/logo.png')}
                      style={{
                        width: 72, 
                        height: 36, 
                        resizeMode: 'cover',
                        alignSelf: 'stretch',
                        alignItems: 'center',
                      }}
                  />
              </View>

              <View style={{
                flex: 1,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'flex-end',
              }}>
                <Pressable onPress={() => console.log('clicked')}>
                  <ImageBackground
                      source={require('../../static/images/btn.png')}
                      resizeMode="contain"
                      style={{}}
                    >
                    <Text style={{
                      fontFamily: 'OpenSans-Regular',
                      color: appColors.WHITE,
                      alignItems: 'center',
                      paddingHorizontal: scale(10),
                      paddingVertical: scale(10),
                      fontSize: scale(10)
                    }}>Tài khoản: {userInfo.bank??0}</Text>
                  </ImageBackground>
                </Pressable>
              </View>
            </View>
        </View>
        <ImageBackground
            source={require('../../static/images/home_bg.png')}
            resizeMode="stretch"
            style={{height: scale(140)}}
          >
          <View style={{
            flexDirection:'row', 
            justifyContent:'flex-start', 
            alignItems:'center',
            paddingVertical: scale(30),
            paddingHorizontal: scale(10)
          }}>
              <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                <Feather name="chevron-left" size={scale(30)} color={appColors.WHITE} />
              </TouchableOpacity>
              <AvatarImage 
                source={{
                  uri: userInfo.avatar,
                }}
              size={scale(72)}/>
              <View style={{
                marginLeft:scale(10),
                flexWrap: 'wrap',
                alignItems: 'flex-start',
                flexShrink: 1,
              }}> 
                  <Text 
                    numberOfLines={1} 
                    style={{
                      fontFamily: 'OpenSans-Regular',
                      fontSize:scale(16),
                      textTransform: "uppercase",
                      color: appColors.WHITE,
                    }}
                  >{userInfo.name}</Text>
                  <Label text={userInfo.phone} style={{fontFamily: 'OpenSans-Regular', color: appColors.WHITE, fontSize:scale(12)}} />
              </View>
          </View>
        </ImageBackground>

        <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled
            style={{flex: 2}}
        >
          <View style={{flex: 1, marginHorizontal: scale(10)}}>
            <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems: 'center'
            }}>
                <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
                    <Label text={'Họ tên'} style={{fontFamily: 'OpenSans-Regular', color: appColors.darkGray}}/>
                </View>
 
                <View style={{flexDirection: 'row'}}>
                    <Label text={'Xem chi tiết'} style={{color: appColors.darkGray}}/>
                    <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                        <Feather name="chevron-right" size={scale(20)} color={appColors.darkGray}/>
                    </TouchableOpacity>
                </View>
            </View>
            <View style={{
                borderWidth: 1, 
                borderColor: appColors.lightGray,
                // paddingHorizontal: scale(10),
                // paddingVertical: scale(7),
                borderRadius: scale(4),
                marginVertical: scale(10)
            }}>
                <Text style={{
                    fontSize: scale(16),
                    fontFamily: 'OpenSans-Bold',
                    paddingHorizontal: scale(10),
                    paddingVertical: scale(8),
                }}>{userInfo.name}</Text>
            </View>

            <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: scale(10)
            }}>
                <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
                    <Label text={'Số điện thoại'} style={{fontFamily: 'OpenSans-Regular', color: appColors.darkGray}}/>
                </View>
            </View>
            <View style={{
                borderWidth: 1, 
                borderColor: appColors.lightGray,
                borderRadius: scale(4),
            }}>
                <Text style={{
                    fontSize: scale(16),
                    fontFamily: 'OpenSans-Bold',
                    paddingHorizontal: scale(10),
                    paddingVertical: scale(8),
                }}>{userInfo.phone}</Text>
            </View>

            <View style={{
                marginTop: scale(20)
            }}>
              <Text style={{fontSize: scale(18), fontFamily: 'OpenSans-Bold'}}>Ví của anh/chị</Text>
            </View>
            <View style={{
                flexDirection: 'row', 
                justifyContent: 'space-between',
                alignItems: 'center',
                marginVertical: scale(10)
            }}>
                <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
                    <Label text={'Số dư'} style={{fontFamily: 'OpenSans-Regular', color: appColors.darkGray}}/>
                </View>
            </View>
            <View style={{
                borderWidth: 1, 
                borderColor: appColors.lightGray,
                borderRadius: scale(4),
            }}>
                <Text style={{
                    fontFamily: 'OpenSans-Bold',
                    fontSize: scale(16),
                    paddingHorizontal: scale(10),
                    paddingVertical: scale(8),
                }}>{currencyFormat(0) + 'đ'}</Text>
            </View>


            <View style={{
                // flexDirection: 'row', 
                justifyContent: 'center',
                // alignItems: 'center',
                marginVertical: scale(20)
            }}>
                <Button mode="outlined" 
                    dark={true}
                    color={appColors.BLACK}
                    onPress={() => console.log('Pressed')}
                    contentStyle={{
                        paddingHorizontal: scale(15),
                        paddingVertical: scale(6),
                        fontSize: scale(16),
                        width: '100%',
                        fontFamily: 'OpenSans-Bold'
                    }}
                >
                    Xem lịch sử giao dịch
                </Button>
            </View>
            
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>    
    </>
  );
}
 
export default ReduxWrapper(History)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  background: {
    flex: 1,
  },
  header: {
    backgroundColor: appColors.WHITE,
    alignItems: 'center',
    borderBottomWidth: 12,
    borderBottomColor: '#ddd',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 13,
    lineHeight: 30,
  },
  headerText: {
    color: 'white',
    fontSize: 25,
    padding: 20,
    margin: 20,
    textAlign: 'center',
  },
  TitleText: {
    fontSize: 25,
    // padding: 20,
    marginVertical: 20,
  },
  scrollContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  cardd: {
    // borderRadius: 10,
    //paddingVertical: 10,
    //paddingHorizontal: 0,
    width: '100%',
    //height: 120,
  },

  btnClickContain: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    backgroundColor: '#009D6E',
    borderRadius: 5,
    padding: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  btnContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    borderRadius: 10,
  },
  btnIcon: {
    height: 25,
    width: 25,
  },
  btnText: {
    fontSize: 18,
    color: '#FAFAFA',
    marginLeft: 10,
    marginTop: 2,
  },
  tabContainer: {
    width: 24,
    height: 24,
    position: 'relative',
  },
  tabBadge: {
    fontFamily: 'OpenSans-Regular',
    position: 'absolute',
    top: -12,
    right: -12,
    backgroundColor: 'red',
    borderRadius: 16,
    paddingHorizontal: 6,
    paddingVertical: 2,
    zIndex: 2,
  },
  tabBadgeText: {
    fontFamily: 'OpenSans-Regular',
    color: 'white',
    fontSize: 11,
    fontWeight: '600',
  },
});

// React Native cross-platform box shadow
const generateBoxShadowStyle = (
  xOffset,
  yOffset,
  shadowColorIos,
  shadowOpacity,
  shadowRadius,
  elevation,
  shadowColorAndroid,
) => {
  if (Platform.OS === 'ios') {
    styles.boxShadow = {
      shadowColor: shadowColorIos,
      shadowOffset: {width: xOffset, height: yOffset},
      shadowOpacity,
      shadowRadius,
    };
  } else if (Platform.OS === 'android') {
    styles.boxShadow = {
      elevation,
      shadowColor: shadowColorAndroid,
    };
  }
};

generateBoxShadowStyle(-2, 4, '#171717', 0.2, 3, 4, '#171717');