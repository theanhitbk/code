import React, { useEffect, useState } from 'react';
import {View, Text, StyleSheet, Pressable, FlatList, TouchableOpacity, ImageBackground, Image} from 'react-native';
import {scale} from 'react-native-size-matters';
import Feather from 'react-native-vector-icons/Feather';
import {appColors} from '../../utils/appColors';
import Label from '../../components/Label';
import {profileKeys} from '../../utils/MockData';
import AvatarImage from '../../components/AvatarImage' 
import auth from '@react-native-firebase/auth';
import ReduxWrapper from '../../utils/ReduxWrapper';
import { clearToken } from '../../utils/storage';

function Account({isLoggedIn, userInfo, logout, navigation}) {
  
  useEffect(() => {
    setTimeout(() => {
      if(!isLoggedIn) {
        navigation.navigate("Login")
      }
    }, 500)
  }, []);

  const onLogout = ()=>{ 
     //auth().signOut()
     clearToken()
     logout()
  }
  const ItemCard = ({item}) => {
    const {lebel, icon,isNew,route} = item;

    return (
      <Pressable onPress={() =>{
        route=="Login"&& onLogout()
        route&& navigation.navigate(route) 
        }} style={styles.itemContainer}>
        <Pressable  style={styles.iconContainer}>
          {route=='Member' &&
            <Image source={require('../../static/images/icon-member.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Profile' &&
            <Image source={require('../../static/images/icon-user2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Reward' &&
            <Image source={require('../../static/images/icon-reward2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='History' &&
            <Image source={require('../../static/images/icon-history2.png')} 
              style={{
                width: scale(16),
                height: scale(16),
                marginRight: scale(10)
              }}
            />
          }
          {route=='Login' &&
            <Feather name={icon} size={scale(18)} color={appColors.black} style={{marginRight: scale(8)}} />
          }
          {/* <Feather name={icon} size={scale(22)}color={appColors.black}  /> */}
        </Pressable>
        <View style={styles.itemInnerContainer}>
          <Label text={lebel} style={{fontFamily: 'OpenSans-Regular', fontSize: scale(13)}}/>
          {isNew&&<View style={{paddingHorizontal:scale(10), backgroundColor:appColors.red, padding:scale(5), borderRadius:scale(4)}}>
             <Label text="New" style={{fontFamily: 'OpenSans-Regular', fontSize:scale(10), color:appColors.white}} /> 
          </View>}
          <Feather name={"chevron-right"} size={scale(18)} />
        </View>
      </Pressable>
    );
  };

  return (
    <>
      <ImageBackground
            source={require('../../static/images/home_bg.png')}
            resizeMode="stretch"
            style={{height: scale(140)}}
          >
          <View style={{
            flexDirection:'row', 
            justifyContent:'flex-start', 
            alignItems:'center',
            paddingVertical: scale(30),
            paddingHorizontal: scale(10)
          }}>
              <TouchableOpacity onPress={() => navigation.navigate('Home')}>
                <Feather name="chevron-left" size={scale(30)} color={appColors.WHITE} />
              </TouchableOpacity>
              <AvatarImage 
                source={{
                  uri: userInfo.avatar,
                }}
              size={scale(72)}/>
              <View style={{
                marginLeft:scale(10),
                flexWrap: 'wrap',
                alignItems: 'flex-start',
                flexShrink: 1,
              }}> 
                  <Text 
                    numberOfLines={1} 
                    style={{
                      fontFamily: 'Oswald-Bold',
                      fontSize:scale(18),
                      textTransform: "uppercase",
                      color: appColors.WHITE,
                    }}
                  >{userInfo.name}</Text>
                  <Label text={userInfo.phone} style={{fontFamily: 'Oswald-Bold',color: appColors.WHITE, fontSize:scale(12)}} />
              </View>
          </View>
      </ImageBackground>
      <View style={{justifyContent: 'flex-start', alignItems: 'center'}}>
            <Text style={{
              fontFamily: 'Oswald-Regular',
                color: appColors.BLACK,
                fontSize: scale(16),
                fontWeight: '500',
                textAlignVertical: 'center',
                marginTop: scale(-10),
                marginBottom: scale(10)
            }}>Chưa có hạng thành viên: mua ngay</Text>
            
            <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginHorizontal: scale(5),
                    marginTop: scale(-20),
                }}>
                    <ImageBackground
                        source={require('../../static/images/black-level-bg.png')}
                        resizeMode="contain"
                        style={{
                            flex: 1,
                            width: '100%',
                            height: 140,
                            paddingVertical: scale(20),
                            marginHorizontal: scale(10),
                        }}
                    >
                        <View style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'relative'
                        }}>
                            <Image source={require('../../static/images/icon-black.png')} 
                                style={{
                                    width: scale(16),
                                    height: scale(16),
                                    position: 'absolute',
                                    top: scale(15),
                                    right: scale(30)
                                }}
                            />
                            <Text style={{
                              fontFamily: 'Oswald-Bold',
                                fontSize: scale(14),
                                textTransform: 'uppercase',
                                color: appColors.WHITE,
                                fontWeight: '700',
                                paddingTop: scale(30)
                            }}>Hạng black</Text>
                        </View>
                    </ImageBackground>

                    <ImageBackground
                        source={require('../../static/images/silver-level-bg.png')}
                        resizeMode="contain"
                        style={{
                            flex: 1,
                            width: '100%',
                            height: 140,
                            paddingVertical: scale(20),
                            marginHorizontal: scale(10),
                        }}
                    >
                        <View style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center'
                        }}>
                            <Image source={require('../../static/images/icon-silver.png')} 
                                style={{
                                    width: scale(20),
                                    height: scale(20),
                                    position: 'absolute',
                                    top: scale(12),
                                    right: scale(15)
                                }}
                            />
                            <Text style={{
                              fontFamily: 'Oswald-Bold',
                                fontSize: scale(14),
                                textTransform: 'uppercase',
                                color: appColors.WHITE,
                                fontWeight: '700',
                                paddingTop: scale(30)
                            }}>Hạng silver</Text>
                        </View>
                    </ImageBackground>
            </View>
      </View>
      <View style={{backgroundColor: appColors.WHITE}}>
        <FlatList
          scrollEnabled
          data={profileKeys}
          showsVerticalScrollIndicator={false}
          renderItem={ ({item, index}) => <ItemCard key={index} item={item} />}
          style={{marginHorizontal: scale(15), marginBottom: scale(250)}}
        />
      </View>
    
    {/* <Container>
        <View style={{paddingVertical:scale(20), flexDirection:'row', justifyContent:'flex-start', alignItems:'center'}}>
            <AvatarImage 
              source={{
                uri: userInfo.avatar,
              }}
             size={scale(80)}/>
            <View style={{marginLeft:scale(20)}}> 
                <Text numberOfLines={1} style={{fontSize:scale(20)}}>{userInfo.name}</Text>
                <Label text={userInfo.email} style={{fontSize:scale(12)}} />
            </View>
        </View>
      <FlatList
        data={profileKeys}
        showsVerticalScrollIndicator={false}
        renderItem={ ({item, index}) => <ItemCard key={index} item={item} />}
      />
    </Container> */}
    </>
  );
}
export default ReduxWrapper(Account)
const styles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingVertical: scale(15),
    borderBottomColor: appColors.lightGray,
    borderBottomWidth: scale(.7)
  },
  itemInnerContainer: {
    flex: 1,

    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
  },
  iconContainer: {
    // borderRadius: scale(5),
    // padding: scale(10),
    // marginRight: scale(20),
    // backgroundColor: appColors.lightGreen,
  },
});
