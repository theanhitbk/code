import React, { forwardRef, useCallback, useRef, useState } from 'react';
import {View, Text, Image, Platform, Pressable, ScrollView, StyleSheet, Alert} from 'react-native';
import {scale} from 'react-native-size-matters';
import Container from '../../components/Container';
import Label from '../../components/Label';
import {appColors} from '../../utils/appColors';
import {SimpleStepper} from 'react-native-simple-stepper';
import BottomButtons from '../../components/BottomButtons';
import {SwipeListView} from 'react-native-swipe-list-view';
import Feather from 'react-native-vector-icons/Feather';
import Ionicons from 'react-native-vector-icons/Ionicons';
import CheckOutItem from '../../components/CheckOutItem';
import {connect} from 'react-redux';
import { addToCart, clearCart, removeFromCart, updateCart } from '../../redux/cartAction';
import { currencyFormat } from '../../utils/HelperFunctions';
import { Checkbox, Modal, Portal, Provider, RadioButton, Dialog } from 'react-native-paper';
import TextInput from '../../components/TextInput';
import Spinner from '../../components/Spinner';
import { ADD_ADDRESS_URL, ADD_ORDER_URL } from '../../services/config';
import { api } from '../../services/api';
import { addShippingAddress, getShippingAddress, getShippingMethod } from '../../redux/shippingAction';
import { useFocusEffect } from '@react-navigation/native';
import { getCities, getCommunes, getDistricts } from '../../redux/addressAction';
import RNPickerSelect from 'react-native-picker-select';
import { AlertHelper } from '../../utils/AlertHelper';


function Cart({userInfo, cartItems, shippings, shippingAddress, cities, districts, communes,
  addToCart$, updateCart$, clearCart$, getCities$, getShippingAddress$,
  addShippingAddress$, getDistricts$, getCommunes$,
  removeFromCart$, getShippingMethods$, navigation}) {

  const ItemCard = forwardRef((props, ref) => {
    const {descriptions, price, image, quantity} = props.item;

    return ( <CheckOutItem name={descriptions.name} 
        image={image} 
        price={price} 
        quantity={quantity} 
        item={props.item}
        selectedItems={selectedItems}
        onUpdateToCart={onUpdateToCart}
        onRemoveFromCart={onRemoveFromCart}
        toggleItem={toggleItem}
      /> 
    );
  });

  const [isSelected, setSelection] = useState(false);
  const [isCheckout, setCheckout] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [totalSelection, setTotalSelection] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);
  const [checked, setChecked] = useState('ShippingStandard2');
  const [text, onChangeText] = useState('');

  const [u_name, onChangeUName] = useState('');
  const [u_mobile, onChangeUMobile] = useState('');
  const [u_email, onChangeUEmail] = useState('');
  const [u_address, onChangeUAddress] = useState('');
  const [u_note, onChangeUNote] = useState('');

  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);

  const [changeAddress, setChangeAddress] = useState(false);
  const [orderAddress, setOrderAddress] = useState();

  const [city, setCity] = useState(null);
  const [cityValue, setCityValue] = useState(null);
  const [district, setDistrict] = useState(null)
  const [districtValue, setDistrictValue] = useState(null)
  const [commune, setCommune] = useState(null)
  const [communeValue, setCommuneValue] = useState(null)

  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);

  useFocusEffect(useCallback(() => {
    getShippingMethods$()
    getShippingAddress$()
    getCities$()

    shippingAddress.forEach(s => {
      if(s.active===0) {
        setOrderAddress(s);
      }
    });
  }, []));

  const onAddToCart = (item) => {
    addToCart$(item);
  };

  const onUpdateToCart = (item, step) => {
    updateCart$(item);
    let arr = selectedItems;
    if(arr.includes(item.id)){
      cal(arr, item.id, step);
    }
  };

  const onRemoveFromCart = (item) => {
    removeFromCart$(item);
    let arr = selectedItems;
    if(arr.includes(item.id)){
      const it = cartItems.find(
        product => product.id === item.id,
      );
      arr = arr.filter(i => i !== it.id);
      setTotalSelection(totalSelection - it.quantity);
      setTotalPrice((totalPrice - (it.price*it.quantity)))
    }
    setSelectedItems(arr);
  };

  const cal = (arr, id, step) => {
    const item = cartItems.find(
      product => product.id === id,
    );
    if(arr.includes(id)) {
      if(step) {
        setTotalSelection(totalSelection + step);
        setTotalPrice((totalPrice + (step*item.price)))
      } else {
        arr = arr.filter(i => i !== item.id);
        setTotalSelection(totalSelection - item.quantity);
        setTotalPrice((totalPrice - (item.quantity*item.price)))
      }
    } else {
      arr.push(id);
      setTotalSelection(totalSelection + item.quantity);
      setTotalPrice((totalPrice + (item.quantity*item.price)))
    }
    setSelectedItems(arr);
  };

  const toggleItem = (id) => {
    setSelection(false);
    const item = cartItems.find(
      product => product.id === id,
    );
    
    if(item) {
      let arr = selectedItems;
      cal(arr, id);
      if(cartItems.length === arr.length) {
        setSelection(true);
      }
    }
  };

  const submitCheckout = async () => {
    let itemList = [];
    selectedItems.forEach(id => {
      const it = cartItems.find(product => product.id === id);
      if(it) {
        itemList.push({
            id: it.id,
            name: it.descriptions.name,
            qty: it.quantity,
            price:it.price,
            tax:0,
            storeId:1,
            options:[],
            subtotal: it.quantity*it.price,
            total: it.quantity*it.price
        });
      }
    });

    let dataToPost = {
      dataOrder: {
        customer_id: 6,
        store_id: 1,
        status: 0,
        currency: "VND",
        shipping_method: checked,
        exchange_rate: 1,
        email: orderAddress.email,
        phone: orderAddress.phone,
        first_name: orderAddress.name,
        address: orderAddress.address,
        province: orderAddress.province,
        district: orderAddress.district,
        comment: text,
      },
      dataTotal:{
          subtotal: totalPrice,
          total: totalPrice,
          discount: 0
      },
      shipping: {
        title: "",
        code: checked,
        value: 0
      },
      itemDetail: itemList
    };

    setLoading(true);
    try {
      const result = await api.post(ADD_ORDER_URL, dataToPost, {crossDomain : true});
      if(result.data.error === 0) {
        clearCart$();
        setTotalPrice(0);
        setCheckout(false);
        setSelection(false);
        navigation.navigate('CheckoutSuccessScreen', {item : dataToPost});
      }
    } catch (error) {
      AlertHelper.show('error', 'Đã có lỗi xảy ra!')
    }
    setLoading(false);
  };
  
  const _renderHeader = () => {
    return (
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingTop: scale(7),
          marginTop: Platform.OS === 'ios' ? scale(30) : 0,
          // paddingVertical: scale(10),
          backgroundColor: appColors.white,
        }}>
        <Pressable onPress={() => {
          !isCheckout ? navigation.navigate('Shop') : setCheckout(false);
        }}>
          <Feather name="arrow-left" size={scale(25)} />
        </Pressable>

        <Label
          text={isCheckout ? 'Thanh toán' : 'Giỏ hàng'}
          numberOfLines={1}
          style={{
            flex: 1,
            fontWeight: '500',
            justifyContent: 'flex-start',
            alignItems: 'center',
            fontSize: scale(18),
            flexShrink: 1
          }}
        />

        <View
          style={{
            height: scale(40),
            width: scale(40),
            backgroundColor: '#F7F7F7',
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: scale(25),
            marginRight: scale(5),
            borderWidth: 2,
            borderColor: '#E0E0E0'
          }}>
          <Feather name="more-vertical" size={scale(20)} color={appColors.black} />
        </View>
      </View>
    );
  };

  const _renderShippings = () => {
    var shippingsElm = [];
    shippings.forEach(obj => {
      const key = Object.keys(obj)[0];
      shippingsElm.push(
          <View key = {key} style={{flexDirection: 'row', alignItems: 'center', marginVertical: scale(10)}}>
              <RadioButton
                value={key}
                status={ checked === key ? 'checked' : 'unchecked' }
                onPress={() => setChecked(key)}
              />
              <View style={{}}>
                <Text style={{fontSize: scale(14), fontWeight: '700'}}>{obj[key].title}</Text>
                {/* <Text style={{color: appColors.darkGray}}>(Phù hợp với địa chỉ nhà riêng, luôn có người nhận)</Text> */}
              </View>
        </View>
      )
    });

    return (
      <View style={{marginVertical: scale(20)}}>
        {shippingsElm}
      </View>
    )
  }

  const _renderShippingAddress = () => {
    
    let addList = [];
    shippingAddress.forEach(item => {
      if(!orderAddress && item.active===0) {
        setOrderAddress(item);
      }
      addList.push(<View key={'k_' + item.id} style={{flexDirection: 'row', alignItems: 'center', marginVertical: scale(10)}}>
        <RadioButton
          value={item.id}
          status={ (orderAddress && orderAddress.id === item.id) ? 'checked' : 'unchecked' }
          onPress={() => setOrderAddress(item)}
        />
        <View style={{}}>
          <Text style={{fontSize: scale(14), fontFamily: 'OpenSans-Bold'}}>
            {item.name} {item.phone}
          </Text>
          <Text style={{fontSize: scale(12), fontFamily:' OpenSans-Regular', color: appColors.darkGray}}>
            {item.email}
          </Text>
          <Text style={{fontSize: scale(12), fontFamily:' OpenSans-Regular', color: appColors.darkGray}}>
            {item.address}, {item.district}, {item.province}
          </Text>
        </View>
        {item.active === 0 && <View style={{
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
          marginHorizontal: scale(10),
          backgroundColor: '#FE6600',
          paddingHorizontal: scale(10),
          paddingVertical: scale(5),
          borderRadius: scale(4),
        }}>
          <Text style={{
            fontFamily: 'OpenSans-Regular',
            fontSize: scale(12)
          }}>Mặc định</Text>
        </View>
        }
      </View>);
    });
      
    
    return (
      <View style={{marginBottom: scale(10)}}>
        
            {addList}
        
        <View style={{
          flexDirection: 'row', 
          justifyContent: 'flex-start',
          alignItems: 'center',
          marginHorizontal: scale(10),
          marginTop: scale(10)
        }}>
          <Pressable onPress={() => setChangeAddress(false)}>
            <Text style={{
              fontFamily: 'OpenSans-Bold'
            }}>Quay lại</Text>
          </Pressable>
          <Pressable onPress={() => setChangeAddress(false)}>
            <Text style={{
              backgroundColor: '#FE8600',
              paddingHorizontal: scale(10),
              paddingVertical: scale(6),
              borderRadius: scale(3),
              fontFamily: 'OpenSans-Bold',
              marginHorizontal: scale(10)
            }}>Chọn</Text>
          </Pressable>
        </View>
      </View>
    )
  }

  const _renderCheckout = () => {
    return (
      <ScrollView nestedScrollEnabled showsVerticalScrollIndicator={false}>
        <View style={{
          flexDirection: 'row', 
          justifyContent: 'space-between',
          alignItems:'center', 
          borderTopColor: appColors.lightGray, 
          borderTopWidth: 2,
          paddingVertical: scale(10),
        }}>
          <View style={{
            justifyContent:'flex-start', 
            alignItems:'center', 
            marginHorizontal: scale(4)
          }}>
            <Text style={{
              fontFamily: "UVNTinTucHepThemBold",
              justifyContent: 'flex-start',
              fontWeight: '700',
              fontSize: scale(20),
              color: appColors.BLACK
            }}>Thông Tin Nhận Hàng</Text>
          </View>
          <View style={{marginHorizontal: scale(5)}}>
            <Pressable onPress={() => changeAddress ? showModal() : setChangeAddress(!changeAddress)}>
              <Text style={{
                  borderColor: appColors.darkGray,
                  borderWidth: 1,
                  borderRadius: scale(7),
                  paddingHorizontal: scale(10),
                  paddingVertical: scale(6),
                  fontSize: scale(12),
                  fontFamily: "OpenSans-Regular",
                  // justifyContent: 'center',
                  //alignItems: 'flex-end'
                }}>{changeAddress ? 'Thêm địa chỉ mới' : 'Thay đổi địa chỉ' }</Text>
              </Pressable>
          </View>
        </View>

        {changeAddress && _renderShippingAddress()}
        
        {!changeAddress && orderAddress && <View>
          <View style={{
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems:'center', 
            paddingVertical: scale(10),
            paddingHorizontal: scale(10)
          }}>
            
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
            <Label text={'Họ tên'} style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              color: appColors.darkGray
            }}/>
            </View>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
              <Label text={orderAddress.name} style={{
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14),
                alignItems: 'flex-start'
              }}/>
            </View>
          </View>
          <View style={{
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems:'center', 
            paddingVertical: scale(10),
            paddingHorizontal: scale(15)
          }}>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
              <Label text={'Số điện thoại'} style={{
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14),
                color: appColors.darkGray
              }}/>
            </View>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
              <Label text={orderAddress.phone} style={{
                fontFamily: 'OpenSans-Regular',
                fontSize: scale(14),
                alignItems: 'flex-start'
              }}/>
            </View>
          </View>
          <View style={{
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems:'center', 
            paddingVertical: scale(10),
            paddingHorizontal: scale(15)
          }}>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
            <Label text={'Email'} style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              color: appColors.darkGray
            }}/>
            </View>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
            <Label text={orderAddress.email} style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              alignItems: 'flex-start'
            }}/>
            </View>
          </View>
          <View style={{
            flexDirection: 'row', 
            justifyContent: 'space-between',
            alignItems:'center', 
            paddingVertical: scale(10),
            paddingHorizontal: scale(15)
          }}>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
            <Label text={'Địa chỉ'} style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              color: appColors.darkGray
            }}/>
            </View>
            <View style={{flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start'}}>
            <Label text={orderAddress.address} style={{
              fontFamily: 'OpenSans-Regular',
              fontSize: scale(14),
              alignItems: 'flex-start'
            }}/>
            </View>
          </View>
        </View>
        }

        <View style={{}}>
          <Text style={{
            borderWidth: 1, 
            borderColor: appColors.darkGray, 
            backgroundColor: appColors.lightGray,
            height: scale(7),
          }}/>

          <View style={{
            justifyContent:'flex-start', 
            marginHorizontal: scale(4),
            marginTop: scale(10)
          }}>
            <Text style={{
              fontFamily: 'OpenSans-Bold',
              justifyContent: 'flex-start',
              fontWeight: '700',
              fontSize: scale(16),
              color: appColors.BLACK
            }}>Thời gian Nhận Hàng</Text>
          </View>

          {_renderShippings()}

          <Text style={{
            borderWidth: 1, 
            borderColor: appColors.darkGray, 
            backgroundColor: appColors.lightGray,
            height: scale(7),
          }}/>
          <View style={{marginVertical: scale(15), marginHorizontal: scale(4)}}>
            <Label text={'Ghi Chú Đơn Hàng'} 
              style={{
                fontFamily: 'OpenSans-Bold',
                fontSize: scale(16)
              }}
            />
            <TextInput
                multiline
                numberOfLines={4}
                onChangeText={text => {onChangeText(text);}}
                value={text}
                style={{padding: 4, borderColor: appColors.darkGray}}
                editable
                maxLength={100}
                placeholder={'Lời nhắn cho người bán hàng'}
              />
          </View>
        </View>
      </ScrollView>
    )
  };

  const _addNewAddress = async () => {
    const formData = new FormData();
    formData.append("name", u_name)
    formData.append("phone", u_mobile)
    formData.append("email", u_email)
    formData.append("province", cityValue)
    formData.append("district", districtValue)
    formData.append("commune", communeValue)
    formData.append("address", u_address)
    formData.append("active", isSelected ? 0 : 1)

    try {
      const result = await api.post(ADD_ADDRESS_URL, formData, {crossDomain : true});
      if(result.data.meta.status_code === 0) {
          AlertHelper.show('success', result.data.meta.message);
          getShippingAddress$();
          hideModal()
      } else {
          AlertHelper.show('error', result.data.meta.message);
      }
    } catch (error) {
        AlertHelper.show('error', 'Đã có lỗi xảy ra!');
    }
  }

  const _renderModalForm = () => {
    return (
      <Portal>
          <Modal visible={visible} onDismiss={hideModal} 
            contentContainerStyle={{
              backgroundColor: 'white', 
              marginHorizontal: scale(20), 
              borderRadius: scale(5),
              paddingVertical: scale(5),
              paddingBottom: scale(20)
            }}>
              <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginHorizontal: scale(10),
                  borderBottomColor: appColors.lightGray,
                  borderBottomWidth: .6
                }}>
                <Text style={{
                  fontFamily: "OpenSans-Bold",
                  fontSize: scale(18),
                  alignItems: 'center',
                  paddingVertical: scale(10)
                }}>Thêm địa chỉ nhận hàng</Text>
                <Pressable onPress={hideModal}>
                  <Ionicons name='close-circle-outline' size={24} />
                </Pressable>
              </View>

              <ScrollView nestedScrollEnabled showsVerticalScrollIndicator={false}>
              <View style={{marginHorizontal: scale(10)}}>
                
                <TextInput
                  onChangeText={text => {onChangeUName(text);}}
                  value={u_name}
                  containerStyles={{
                    marginVertical: scale(5)
                  }}
                  style={{
                    borderColor: appColors.darkGray,
                  }}
                  editable
                  placeholder={'Họ tên'}
                />
                <TextInput
                  onChangeText={text => {onChangeUMobile(text);}}
                  value={u_mobile}
                  containerStyles={{
                    marginVertical: scale(5)
                  }}
                  style={{borderColor: appColors.darkGray}}
                  editable
                  placeholder={'Số điện thoại'}
                />

                <TextInput
                  onChangeText={text => {onChangeUEmail(text);}}
                  value={u_email}
                  containerStyles={{
                    marginVertical: scale(5)
                  }}
                  style={{borderColor: appColors.darkGray}}
                  editable
                  placeholder={'Email'}
                />

                <View style={{
                  borderColor: appColors.darkGray,
                  borderWidth: 1,
                  borderRadius: 4,
                  marginVertical: scale(10)
                }}>
                <RNPickerSelect
                    onValueChange={(value, index) => {
                      setCityValue(cities[index-1].label)
                      setCity(value)
                      getDistricts$({matp: value})
                    }}
                    items={cities??[]}
                    placeholder={{label: 'Tỉnh / Thành phố'}}
                />
                </View>
                
                <View style={{
                  borderColor: appColors.darkGray,
                  borderWidth: 1,
                  borderRadius: 4,
                  marginVertical: scale(5)
                }}>
                <RNPickerSelect
                    onValueChange={(value, index) => {
                      if(typeof districts[index-1] != 'undefined') {
                        setDistrict(value)
                        setDistrictValue(districts[index-1].label)
                      }
                      getCommunes$({maqh: value})
                    }}
                    items={districts??[]}
                    placeholder={{label: 'Quận / Huyện'}}
                />
                </View>

                <View style={{
                  borderColor: appColors.darkGray,
                  borderWidth: 1,
                  borderRadius: 4,
                  marginVertical: scale(5)
                }}>
                <RNPickerSelect
                    onValueChange={(value, index) => {
                      if(typeof communes[index-1] != 'undefined') {
                        setCommune(value)
                        setCommuneValue(communes[index-1].label)
                      }
                    }}
                    items={communes??[]}
                    placeholder={{label: 'Xã / Phường'}}
                />
                </View>

                <TextInput
                  onChangeText={text => {onChangeUAddress(text);}}
                  value={u_address}
                  containerStyles={{
                    marginVertical: scale(5)
                  }}
                  style={{borderColor: appColors.darkGray}}
                  editable
                  placeholder={'Địa chỉ'}
                />

                <View style={{
                  flexDirection: 'row', 
                  alignItems: 'center',
                  marginVertical: scale(10)
                }}>
                  <Checkbox
                    status={isSelected ? 'checked' : 'unchecked'}
                    onPress={() => {
                      setSelection(!isSelected)
                    }}
                    style={{justifyContent: 'flex-start'}}
                  />
                  <Label text={'Đặt làm địa chỉ mặc định'} style={{fontSize: scale(12)}} />
                </View>

                <Pressable onPress={() => _addNewAddress()} 
                style={{
                  backgroundColor: '#FE6700',
                  borderColor: '#FE6700',
                  borderWidth: .5,
                  alignItems: 'center', borderRadius: scale(5),
                }}>
                <Text style={{
                  paddingHorizontal: scale(12),
                  paddingVertical: scale(10),
                  fontSize: scale(16),
                  fontFamily: 'Oswald-Bold',
                  color: appColors.WHITE,
                  textTransform: 'uppercase'
                }}>Cập nhật</Text>
                </Pressable>
              </View>
              </ScrollView>
          </Modal>
      </Portal>
    )
  };
  
  return (
    <>
    <Provider>
      {_renderHeader()}
      <Container
        bodyStyle={{
          paddingHorizontal: scale(0), backgroundColor: appColors.WHITE
        }}
      >
        {cartItems.length > 0 && 
        <View style={{flex: 1, paddingVertical: scale(1)}}>
          {!isCheckout && <SwipeListView
            keyExtractor={(item) => `${item.id}_${new Date().getTime()}`}
            ItemSeparatorComponent={() => <View style={{padding: scale(0)}} />}
            data={[...cartItems]  || []}
            renderItem={({item, index}) => <ItemCard key={index} item={item} />}
            // renderHiddenItem={(data, rowMap) => (
            //   <View
            //     style={{
            //       flex: 1,
            //       flexDirection: 'row',
            //       justifyContent: 'space-between',
            //       alignItems: 'center',
            //     }}>
            //     <Pressable
            //       style={{
            //         left: scale(-15),
            //         flex: scale(0.3),
            //         backgroundColor: appColors.yellow,
            //         height: '100%',
            //         justifyContent: 'center',
            //         alignItems: 'center',
            //       }}>
            //       <Feather
            //         name={'star'}
            //         size={scale(25)}
            //         color={appColors.white}
            //       />
            //     </Pressable>
            //     <Pressable
            //       style={{
            //         left: scale(15),
            //         flex: scale(0.3),
            //         backgroundColor: appColors.redOrange,
            //         height: '100%',
            //         justifyContent: 'center',
            //         alignItems: 'center',
            //       }}>
            //       <Feather
            //         name={'trash'}
            //         size={scale(25)}
            //         color={appColors.white}
            //       />
            //     </Pressable>
            //   </View>
            // )}
            // leftOpenValue={scale(85)}
            // rightOpenValue={scale(-85)}
          />}
          {isCheckout && _renderCheckout()}
        </View> 
        }

      {cartItems.length === 0 && 
        <View style={{alignItems: 'center', marginVertical: scale(30)}}>
          <Text style={{fontFamily: "UVNTinTucHepThemBold", fontSize: scale(20)}}>Không có sản phẩm nào trong giỏ hàng</Text>
        </View>
      }

      </Container>
      <View style={{backgroundColor: appColors.white}}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingHorizontal: scale(8),
            paddingVertical: scale(6),
            backgroundColor: appColors.white,
            borderTopWidth: 1, 
            borderTopColor: '#E8E8E8'
          }}>
          {!isCheckout && <View style={{justifyContent: 'flex-end', flexDirection: 'row', alignItems: 'center'}}>
            <Checkbox
              status={isSelected ? 'checked' : 'unchecked'}
              onPress={() => {
                let array = [];
                setSelection(!isSelected);
                let tt = 0;
                let totalP = 0;
                if(!isSelected) {
                  cartItems.forEach(it => {
                    array.push(it.id);
                    tt += it.quantity;
                    totalP += it.quantity * it.price;
                  });
                }
                setTotalPrice(totalP);
                setTotalSelection(tt);
                setSelectedItems(array);
              }}
              style={{justifyContent: 'flex-start'}}
              testID='all'
            />
            <Label text={'Tất cả'} style={{fontSize: scale(12)}} />
          </View>
          }
          <View style={{
            flexDirection: 'column', justifyContent:'flex-end', 
          }}>
            <Label
              text={!isCheckout ? "Tạm tính" : "Tổng thanh toán"}
              style={{
                fontFamily: "UVNTinTucHepThemBold",
                fontSize: scale(16),
                opacity: scale(1),
                //letterSpacing: scale(2),
                fontWeight: '700',
                color: appColors.black
              }}
            />
            <Label
              text={currencyFormat(totalPrice) + ' đ'}
              style={{
                fontFamily: "UVNTinTucHepThemBold",
                fontSize: scale(20),
                fontWeight: '800',
                color: '#FE6600', //'#E1A09E',
                //marginTop: scale(3),
              }}
            />
            {!isCheckout && <Label
              text={'(' + totalSelection +' sản phẩm)'}
              style={{
                fontSize: scale(12),
                color: appColors.black, //'#E1A09E',
              }}
            />}
          </View>
          <Pressable onPress={() => {
            if(isSelected) {
              getShippingAddress$();
              !isCheckout ? setCheckout(true) : submitCheckout();//navigation.navigate("Checkout")
            } else {
              Alert.alert('Thông báo', 'Bạn chưa chọn sản phẩm nào');
            }
          }}
            style={{
              borderColor: selectedItems.length ===0 ? '#E9E9E9' : '#FE6700',
              borderWidth: 1,
              borderRadius: scale(4),
            }}
          >
            <Text style={{
              backgroundColor: selectedItems.length ===0 ? '#E9E9E9' : '#FE6700',
              paddingHorizontal: scale(12),
              paddingVertical: scale(10),
              fontSize: scale(16),
              fontWeight: '700',
              color: selectedItems.length ===0 ? '#A4A4A4' : appColors.BLACK,
              textTransform: 'uppercase'
            }}>Đặt hàng</Text>
          </Pressable>
          {/* <CustomButton onPress={()=> navigation.navigate("Checkout") } label={'Đặt hàng'} /> */}
        </View>
        {/* <BottomButtons onPress={()=> navigation.navigate("Checkout") } buttonLabel={'Đặt hàng'} 
          priceLabel={'Tổng tiền'} price={currencyFormat(totalPrice) + ' đ'} /> */}
      </View>
      
      {_renderModalForm()}
      </Provider>
      { loading && <Spinner />
      }
    </>
  );
}

const mapStateToProps = (state) => ({
  cartItems : state.cart.cartItems,
  userInfo: state.login.userInfo,
  shippings: state.shippings.shippings,
  shippingAddress: state.shippings.shippingAddress,
  cities: state.address.cities,
  districts: state.address.districts,
  communes: state.address.communes
});
const mapDispatchToProps = { 
  updateCart$: updateCart,
  addToCart$: addToCart,
  removeFromCart$: removeFromCart,
  clearCart$: clearCart,
  getShippingMethods$: getShippingMethod,
  getShippingAddress$: getShippingAddress,
  getCities$: getCities,
  getDistricts$: getDistricts,
  getCommunes$: getCommunes,
  addShippingAddress$: addShippingAddress
};

export default connect(mapStateToProps, mapDispatchToProps)(Cart);
