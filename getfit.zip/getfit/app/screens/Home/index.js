import React, {useCallback, useEffect, useRef, useState} from 'react';
import {StyleSheet, Text, View, FlatList, Image, Dimensions,
  TouchableOpacity, Pressable, ImageBackground, Linking, 
  SafeAreaView, ScrollView, Platform} from 'react-native';
import {appColors, shadow} from '../../utils/appColors';
import { Shadow } from 'react-native-shadow-2';
import Label from '../../components/Label';
import {scale} from 'react-native-size-matters';
import ReduxWrapper from '../../utils/ReduxWrapper';
import AvatarImage from '../../components/AvatarImage' 
import { CommonActions, NavigationActions, StackActions, useFocusEffect } from '@react-navigation/native';
import {BASE_URL} from '../../../app.json';
import { clearToken, getToken } from '../../utils/storage';
import { FlatListSlider } from 'react-native-flatlist-slider';
import Spinner from '../../components/Spinner';
import { dateStringFormat, isRealValue } from '../../utils/HelperFunctions';
import Feather from 'react-native-vector-icons/Feather';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import { AlertHelper } from '../../utils/AlertHelper';

function Home({logout, userInfo, config, books, getBooks$, getBook$,
    getHomeDatas, categories, getCmsCategories$, getDetailCategory$,
    getDetailPostCategory$, removeBooking$, navigation}) {

  const flatlistRef = useRef(null);

  useFocusEffect(useCallback(() => {
    getToken().then((token) => {
     if(token.length === 0) {
      clearToken();
       logout();
     }
    });

    getHomeDatas();
    getBooks$();
    getCmsCategories$();
  }, []));

  const onRemoveBookSuccess = (result) => {
    if(result.meta.status_code === 0 ){
      getBooks$();
      AlertHelper.show('success', result.meta.message);
    } else {
      AlertHelper.show('error', result.meta.message);
    }
  };
  
  const onRemoveBookError = (result) => {
    AlertHelper.show('error', 'Đã có lỗi xảy ra!');
  }

  const CategoryCard = ({category}) => {
    const {title} = category;
    return (
      <>
        <View style={styles.contentContiner}>
          <View style={{
              alignItems: 'flex-start',
          }}>
            <Label
              text={title}
              style={{
                fontFamily: 'OpenSans-Bold',
                  fontSize: scale(16), 
                  textTransform: 'uppercase',
                  paddingVertical: scale(7)
              }}
            />
          </View>
          <View style={{
              alignItems: 'flex-start',
          }}>
            <Pressable onPress={() => {
              getDetailCategory$(category.id)
              navigation.navigate('NewsList', {item: category})
            }} >
              <Label
                  text={'Xem thêm'}
                  style={{
                    fontFamily: 'OpenSans-Regular',
                      fontSize: scale(12), 
                      paddingVertical: scale(7),
                      textTransform: 'uppercase',
                      color: appColors.darkGray
                  }}
              />
            </Pressable>
          </View>
        </View>
        
        <View style={{flex: 1, marginTop: scale(10)}}>
            <FlatList
            horizontal
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            listKey='hot-news'
            keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_${item.id}`}
            ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
            data={category.posts ? category.posts : []}
            renderItem={({item, index}) => (
                <TouchableOpacity onPress={() => {
                  getDetailPostCategory$(item.id);
                  navigation.navigate('NewsDetail', {item: item})
                }}>
                    <View style={{
                        // flexDirection: 'row',
                        justifyContent: 'center',
                        // alignItems: 'center',
                        width: scale(200)
                    }}>
                        {item.image && item.image.length > 0 && 
                        <Image source={{uri: BASE_URL + item.image}} 
                            style={{
                                flex: 1,
                                // resizeMode: 'contain', 
                                alignSelf: 'stretch', 
                                height: scale(160),
                                width: null
                            }}
                        />
                        }
                      
                        <View style={{
                            // flex: 1,
                            // alignItems: 'center',
                            flexShrink: 1,
                            justifyContent: 'flex-start',
                        }}>
                            <Text ellipsizeMode='tail' numberOfLines={2}
                            style={{
                              fontFamily: 'OpenSans-Medium',
                                justifyContent: 'flex-start',
                                fontSize: scale(14),
                            }}>{item.descriptions.title}</Text>
                            {/* <Text ellipsizeMode='tail' numberOfLines={4}>{item.descriptions.description}</Text> */}
                        </View>
                    </View>
                </TouchableOpacity>
            )}
            />
        </View>
      </>
    );
  };
  
  return (
    <>
      <SafeAreaView style={{flex: 1}}>
        <View style={{flex: 1}}>
          <View style={{
            flex: 1,
            marginHorizontal:scale(0),
            // height: scale(45),
            backgroundColor: appColors.WHITE
          }}> 
              <View style={{
                flexDirection:'row', 
                justifyContent: 'center', 
                alignItems: 'center',
                marginVertical: scale(6)
              }}>
                <View style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  marginLeft: scale(10),
                }}>
                  <Pressable onPress={() => console.log('clicked')}>
                    <View style={styles.tabContainer}>
                      {(userInfo.number_of_notification > 0) &&
                        <View style={styles.tabBadge}>
                          <Text style={styles.tabBadgeText}>
                          {userInfo.number_of_notification}
                          </Text>
                        </View>
                      }
                      <Image
                          source={require('../../static/images/icon-bell.png')}
                          style={{ width: 24, height: 24, 
                           resizeMode: 'contain' 
                          }}
                      />
                    </View>
                  </Pressable>
                </View>
                <View style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                    <Image
                        source={require('../../static/images/logo.png')}
                        style={{
                          width: 72, 
                          height: 36, 
                          resizeMode: 'cover',
                          alignSelf: 'stretch',
                          alignItems: 'center',
                        }}
                    />
                </View>

                <View style={{
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                }}>
                  <Pressable onPress={() => console.log('clicked')}>
                    <ImageBackground
                        source={require('../../static/images/btn.png')}
                        resizeMode="contain"
                        style={{}}
                      >
                      <Text style={{
                        fontFamily: 'OpenSans-Regular',
                        color: appColors.WHITE,
                        alignItems: 'center',
                        paddingHorizontal: scale(10),
                        paddingVertical: scale(10),
                        fontSize: scale(10)
                      }}>Tài khoản: {userInfo.bank??0}</Text>
                    </ImageBackground>
                  </Pressable>
                </View>
              </View>
          </View>
          <ImageBackground
              source={require('../../static/images/home_bg.png')}
              resizeMode="stretch"
              style={{flex: 2, height: 220}}
            >
            <View style={{
              // flex: 1,
              paddingHorizontal: scale(15),
              flexDirection:'row', 
              justifyContent:'flex-start', 
              alignItems:'center',
              paddingVertical: scale(10)
            }}>
                <AvatarImage 
                  source={{
                    uri: userInfo.avatar,
                  }}
                size={scale(72)}/>
                <View style={{
                  marginLeft:scale(10),
                  flexWrap: 'wrap',
                  alignItems: 'flex-start',
                  flexShrink: 1,
                }}> 
                    <Text 
                      numberOfLines={1} 
                      style={{
                        fontFamily: 'OpenSans-Regular',
                        fontSize:scale(16),
                        textTransform: "uppercase",
                        color: appColors.WHITE,
                      }}
                    >{userInfo.name}</Text>
                    <Label text={userInfo.phone} 
                      style={{
                        fontFamily: 'OpenSans-Regular',
                        color: appColors.WHITE, 
                        fontSize:scale(10)
                      }} />
                </View>
            </View>
            <View style={{
              backgroundColor: appColors.WHITE,
              flexDirection: 'column',
              justifyContent: 'space-between',
              alignItems:'center',
              alignSelf: 'center',
              borderRadius: 8,
              height: Platform.OS ==='ios' ? 90 : 110,
              top: Platform.OS === 'ios' ? 15 : 10,
              ...shadow
              //marginTop: scale(10)
            }}> 
              
                <View style={{
                  flex: 1, 
                  flexDirection:'row',
                  justifyContent: 'space-between',
                  // marginHorizontal: scale(10)
                }}>
                  <View style={{
                    flexDirection:'row', 
                    justifyContent: 'center', 
                    alignItems: 'center',
                    paddingHorizontal: scale(20)
                  }}>
                      <Pressable onPress={() => {
                        if(userInfo.account_id.length) {
                          const resetAction = CommonActions.reset({
                            index: 0,
                            routes: [
                              {
                                name: 'Booking',
                                key: null // THIS LINE
                              }
                            ],
                            
                          })
                          navigation.dispatch(resetAction);
                        }
                      }}>
                        <Image
                            source={require('../../static/images/icon-edit.png')}
                            style={{ width: 45, height: 45, resizeMode: 'contain' 
                          }}
                        />
                        <Text style={styles.boxShadowText}>Đặt lịch</Text>
                    </Pressable>
                  </View>

                  <View style={{
                    flexDirection:'row', 
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginHorizontal: scale(20)
                  }}>
                    <Pressable onPress={() => navigation.navigate('History')}>
                        <Image
                            source={require('../../static/images/icon-history.png')}
                            style={{ width: 45, height: 45, resizeMode: 'contain' }}
                        />
                        <Text style={styles.boxShadowText}>Lịch sử</Text>
                    </Pressable>
                  </View>

                  <View style={{
                    flexDirection:'row', 
                    justifyContent: 'center', 
                    alignItems: 'center',
                    marginHorizontal: scale(20)
                  }}>
                    <TouchableOpacity onPress={() => navigation.navigate('Member')}>
                        <Image
                            source={require('../../static/images/icon-user.png')}
                            style={{ 
                              width: 45, height: 45, 
                             resizeMode: 'contain' 
                            }}
                        />
                        <Text style={styles.boxShadowText}>Member</Text>
                    </TouchableOpacity>
                  </View>

                  <View style={{
                    flexDirection:'row', 
                    justifyContent: 'center', 
                    alignItems: 'center',
                    marginHorizontal: scale(20)
                  }}>
                      <TouchableOpacity onPress={() => navigation.navigate('Reward')}>
                        <Image
                            source={require('../../static/images/icon-rewards.png')}
                            style={{ width: 45, height: 45, 
                              resizeMode: 'contain' 
                            }}
                        />
                        <Text style={styles.boxShadowText}>Rewards</Text>
                    </TouchableOpacity>
                  </View>
                </View>
            </View>
          </ImageBackground>
        </View>
                    
        <View style={{
          flex: 2,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignItems: 'flex-start',
          marginBottom: scale(1),
          marginTop: Platform.OS === 'ios' ? scale(80) : scale(100),
          backgroundColor: appColors.WHITE
        }}>

          <FlatList
            ListHeaderComponent={
              <View>
                <FlatList
                  data={books??[]}
                  renderItem={({item, idx}) => 
                  <View
                    key={'book_' + item.id}
                    style={{
                        backgroundColor: appColors.WHITE,
                        borderRadius: 8,
                        marginHorizontal: scale(5),
                        marginBottom: scale(10),
                        ...shadow
                      }}
                  >
                    <View style={{
                      marginHorizontal: scale(10),
                    }}>
                      <View style={{
                        flexDirection: 'row',
                        paddingVertical: scale(10)
                      }}>
                        <Image source={require('../../static/images/icon-booked.png')}
                          style={{
                            width: scale(20),
                            height: scale(20),
                            marginRight: scale(10)
                          }}
                        />
                        <Text style={{
                          fontFamily: 'OpenSans-Bold',
                          fontSize: scale(14),
                          textTransform: 'uppercase',
                          color: '#FE8800'
                        }}>{item.branch_name}</Text>
                      </View>
                      <View style={{
                      }}>
                        <Text>- Địa điểm: {item.branch_address}</Text>
                        <Text style={{
                          paddingVertical: scale(5)
                        }}>- Thời gian: {item.date_time}</Text>
                        <Text>- PT: {item.pt_name}</Text>
                        <Text style={{
                          paddingVertical: scale(5)
                        }}>- Lịch tập của anh/chị vào lúc {item.date_time.substring(11, 16)} {dateStringFormat(item.date_time.substring(0, 10))}</Text>
                        <View style={{flexDirection: 'row'}}>
                          <Ionicons name='location' size={20} />
                          <Text>Xem địa điểm gửi xe ô tô</Text>
                        </View>
                      </View>
                      <View style={{
                          flexDirection: 'row',
                          justifyContent: 'space-around',
                          alignItems: 'center',
                          marginVertical: scale(10)
                      }}>
                          <Pressable onPress={() => {
                            const resetAction = CommonActions.reset({
                              index: 0,
                              routes: [
                                {
                                  name: 'Booking',
                                  params: {item: item},
                                  key: null // THIS LINE
                                }
                              ],
                              
                            })
                            navigation.dispatch(resetAction);
                            //navigation.navigate('Booking', {item: item})
                          }}
                          style={{
                              flexDirection: 'row',
                              borderColor: appColors.darkGray,
                              borderWidth: 1,
                              borderRadius: scale(7),
                              paddingHorizontal: scale(10),
                              paddingVertical: scale(6),
                              alignItems: 'center'
                          }}
                          >
                              <Text style={{
                                  paddingLeft: scale(7),
                                  fontFamily: 'OpenSans-Bold',
                                  fontSize: scale(14),
                                  marginRight: scale(10),
                                  textTransform: 'uppercase'
                              }}>Đổi lịch đặt</Text>
                              <SimpleLineIcons name='refresh' size={20}/>
                          </Pressable>
                          <Pressable onPress={() => {Linking.openURL(`https://maps.google.com/?q=${item.branch_address}`);}}
                            style={{
                                flexDirection: 'row',
                                borderColor: appColors.darkGray,
                                borderWidth: 1,
                                borderRadius: scale(7),
                                paddingHorizontal: scale(10),
                                paddingVertical: scale(6),
                                alignItems: 'center'
                            }}
                          >
                            <Text style={{
                                  paddingLeft: scale(7),
                                  fontFamily: 'OpenSans-Bold',
                                  fontSize: scale(14),
                                  textTransform: 'uppercase'
                            }}>Chỉ đường</Text>
                            <MaterialCommunityIcons name='hand-pointing-up' size={24} />
                          </Pressable>
                      </View>
                      <View style={{alignItems: 'center', marginVertical: scale(10)}}>
                        <Pressable onPress={() => removeBooking$({id: item.id}, onRemoveBookSuccess, onRemoveBookError)}>
                            <Text style={{
                              fontFamily: 'OpenSans-Regular', 
                              fontSize: scale(14),
                              textDecorationLine: 'underline'
                            }}>Huỷ đặt lịch</Text>
                        </Pressable>
                      </View>
                    </View>
                  </View>
                }
                />
                
                {isRealValue(config?.banners) ? 
                <FlatListSlider 
                  data={config.banners??[]} 
                  height={200}
                  listKey={'banner'}
                  keyExtractor={(item)=> `banner_${new Date().getTime()}_product`}
                  // contentContainerStyle={{paddingHorizontal: 16}}
                  // indicatorContainerStyle={{position:'absolute', bottom: 10}}
                  //indicatorActiveColor={'#8e44ad'}
                  //indicatorInActiveColor={'#ffffff'}
                  indicatorActiveWidth={15}
                  indicatorStyle={{width: 15, height: 15, borderRadius: 50}}
                  inactiveDotStyle={{width:scale(20)}}
                  animation
                  onPress={item => console.log('testt')}
                />
                : <Spinner />
              }
              </View>
            }
            ref={flatlistRef}
            nestedScrollEnabled={true}
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
            listKey='home'
            keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_${item.id}`}
            ItemSeparatorComponent={() => <View style={{padding: scale(5)}} />}
            data={isRealValue(config?.posts) ? config.posts : []}
            renderItem={({item, index}) => <></>}
            //stickyHeaderIndices={[0]}
            ListFooterComponent={
              <FlatList
                listKey='categories_'
                keyExtractor={(item)=> `${item.id}_${new Date().getTime()}_${item.id}`}
                ItemSeparatorComponent={() => <View style={{padding: scale(2)}} />}
                data={isRealValue(categories) ? categories : []}
                renderItem={({item, index}) => <CategoryCard key={index} category={item} />}
                style={{
                  marginTop: 10
                }}
              />
            }
          />
        </View>
      </SafeAreaView>
      <View style={{
        position: 'absolute',
        bottom: 15,
        right: 10,
        height: 60,
      }}>
        <Pressable
          onPress={() => {Linking.openURL(`tel:${config.phoneNumber}`);}}
        >
          <Image
              source={require('../../static/images/icon-hotline.png')}
              style={{ 
                width: 122,
                height: 55,
                // resizeMode: 'contain',
              }}
          />
        </Pressable>
      </View>
    </>
  );
}
 
export default ReduxWrapper(Home)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative'
    //backgroundColor: '#FAF1E6',
    //paddingHorizontal: 0,
  },
  background: {
    flex: 1,
  },
  header: {
    backgroundColor: appColors.WHITE,
    alignItems: 'center',
    borderBottomWidth: 12,
    borderBottomColor: '#ddd',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 13,
    lineHeight: 30,
  },
  headerText: {
    color: 'white',
    fontSize: 25,
    padding: 20,
    margin: 20,
    textAlign: 'center',
  },
  boxShadowText: {
    fontFamily: 'OpenSans-Regular',
    textAlign: 'center', 
    marginTop: 10,
    fontSize: scale(10)
  },
  scrollContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },

  btnClickContain: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    backgroundColor: '#009D6E',
    borderRadius: 5,
    padding: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  btnContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'stretch',
    alignSelf: 'stretch',
    borderRadius: 10,
  },
  btnIcon: {
    height: 25,
    width: 25,
  },
  btnText: {
    fontSize: 18,
    color: '#FAFAFA',
    marginLeft: 10,
    marginTop: 2,
  },
  tabContainer: {
    width: 24,
    height: 24,
    position: 'relative',
  },
  tabBadge: {
    position: 'absolute',
    top: -12,
    right: -12,
    backgroundColor: 'red',
    borderRadius: 16,
    paddingHorizontal: 6,
    paddingVertical: 2,
    zIndex: 2,
  },
  tabBadgeText: {
    fontFamily: 'OpenSans-Regular',
    color: 'white',
    fontSize: 10,
  },

  contentContiner: {
    fontFamily: 'OpenSans-Regular',
    paddingVertical: scale(3),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: appColors.white,
    paddingHorizontal: scale(5),
    borderBottomWidth: scale(1.2),
    borderBottomColor: '#FE8800',
    // paddingVertical: scale(10),
    ...shadow,
  },
});

// React Native cross-platform box shadow
const generateBoxShadowStyle = (
  xOffset,
  yOffset,
  shadowColorIos,
  shadowOpacity,
  shadowRadius,
  elevation,
  shadowColorAndroid,
) => {
  if (Platform.OS === 'ios') {
    styles.boxShadow = {
      shadowColor: shadowColorIos,
      shadowOffset: {width: xOffset, height: yOffset},
      shadowOpacity,
      shadowRadius,
    };
  } else if (Platform.OS === 'android') {
    styles.boxShadow = {
      elevation,
      shadowColor: shadowColorAndroid,
    };
  }
};

generateBoxShadowStyle(-2, 4, '#171717', 0.2, 3, 4, '#171717');