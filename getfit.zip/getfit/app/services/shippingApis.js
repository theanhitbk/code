import { api } from './api';
import { ADD_ADDRESS_URL, GET_CITIES_URL, GET_COMMUNES_URL, GET_DISTRICTS_URL, SHIPPING_ADDRESS_URL, SHIPPING_URL } from './config';

export const getShippings = async (params) => {
    const result = await api.get(SHIPPING_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getShippingAddress = async (params) => {
    const result = await api.get(SHIPPING_ADDRESS_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const addShippingAddress = async (params) => {
    const result = await api.post(ADD_ADDRESS_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getCities = async (params) => {
    const result = await api.get(GET_CITIES_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getDistricts = async (params) => {
    const result = await api.get(GET_DISTRICTS_URL, {params: params}, {crossDomain : true});

    return result.data;
}

export const getCommunes = async (params) => {
    const result = await api.get(GET_COMMUNES_URL, {params: params}, {crossDomain : true});
    return result.data;
}