import axios from 'axios';
import { getToken, clearToken } from '../utils/storage';
import {BASE_API_URL, API_KEY, API_SECRET} from '../../app.json';

export const api = axios.create({
  baseURL: BASE_API_URL,
  timeout: 6000,
  headers: {
    'X-Requested-With': 'XMLHttpRequest',
    apiconnection: API_KEY,
    apikey: API_SECRET,
  },
});

export function setToken(token) {
  //api.defaults.headers.common.Authorization = `Bearer ${token}`;
}

api.interceptors.request.use(async (config) => {
  const token = await getToken();
  config.headers.Authorization = `Bearer ${token}`;

  return config;
});

api.interceptors.response.use(undefined, err => {
  const error = err.response;
  if(error) {
    // if error is 401 
    if(error.status===401) {
      clearToken();
    }
    if (error.status===401 && error.config && 
      !error.config.__isRetryRequest) {
      return Promise.reject(error);
  // request for a new token
  // return getAuthToken().then(response => {
  //  // update the error config with new token
  //  error.config.__isRetryRequest = true;
  //  error.config.headers.token= localStorage.getItem("accessToken");
  //  return api(error.config);
  // });
    }
  } 
});

getToken().then((token) => {
  if(token.length > 0) {
    setToken(token);
  } else {
    clearToken();
  }
});

/**
 * @description this method calls a requestNewToken method to issue a 
 new token to the client
*/ 
/*
function getAuthToken() {
  if (!authTokenRequest) {
  authTokenRequest = requestNewToken();
  authTokenRequest.then(resetAuthTokenRequest, resetAuthTokenRequest);
}
return authTokenRequest;
}
*/
/**
 * @description this method requests the server to issue a new token, 
 the server response is updated in local storage accessToken
*/ 
/*
function requestNewToken() {
 var newToken = request({
 method: "post",
 url: '/sign-in',
 data:  qs.stringify({
        "userName":localStorage.getItem('userName'),
        "password":localStorage.getItem('password')
        })  
 }).then((res)=>{
 if(res.status == "success"){
   localStorage.setItem('accessToken',res.data.accessToken);
   //if featureArray is present in response object, update the featureArray in local storage
   if(res.data.features){
     localStorage.setItem(
     'featureArray',
    JSON.stringify(res.data.features));
   }
   client = axios.create({
    baseURL: baseURL,
    headers: {
         appID: 8,
         version: "1.1.0",
         empID: localStorage.getItem('empID'),
         token: localStorage.getItem('accessToken')
     }
  });
} else {
 window.location = "/logout";
}
});
return newToken;
}

function resetAuthTokenRequest() {
 authTokenRequest = null;
}
*/