import { api } from './api';
import { CATEGORIES_URL, CMS_CATEGORIES_URL, CMS_CATEGORY_URL, CMS_POST_URL, HOT_CATEGORIES_URL } from './config';

export const getCategories = async (params) => {
    const result = await api.get(CATEGORIES_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getHotCategories = async (params) => {
    const result = await api.get(HOT_CATEGORIES_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getCmsCategories = async (params) => {
    const result = await api.get(CMS_CATEGORIES_URL, {params: params}, {crossDomain: true});
    return result.data;
}

export const getCmsCategory = async (params) => {
    const result = await api.get(CMS_CATEGORY_URL + params.id, {params: params}, {crossDomain: true});
    return result.data;
}

export const getCmsPost = async (params) => {
    const result = await api.get(CMS_POST_URL + params.id, {params: params}, {crossDomain: true});
    return result.data;
}