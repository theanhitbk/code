import { api } from './api';
import { ADD_ORDER_URL, GET_ORDERS_URL, GET_ORDER_URL } from './config';

export const addOrder = async (params) => {
    const result = await api.post(ADD_ORDER_URL, params, {crossDomain : true});
    return result.data;
}

export const getOrder = async (params) => {
    const result = await api.get(GET_ORDER_URL + params.id, {params: params}, {crossDomain : true});
    return result.data;
}

export const getOrders = async (params) => {
    const result = await api.get(GET_ORDERS_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const searchOrders = async (params) => {
    const result = await api.get(SEARCH_PRODUCTS_URL, {params: params}, {crossDomain : true});
    return result.data.data;
}

