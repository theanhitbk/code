import { api } from './api';
import { BOOK_ADD_URL, BOOK_DELETE_URL, BOOK_INFO_URL, BOOK_UPDATE_URL, BRANCH_LIST_URL, CATEGORIES_URL, CONTRACT_LIST_URL, GET_BOOKS_URL, PT_LIST_URL, SCHEDULE_LIST_URL } from './config';

export const getbooks = async (params) => {
    const result = await api.get(CATEGORIES_URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getMemberBranchs = async (params) => {
    const result = await api.get(BRANCH_LIST_URL, {params: params}, {crossDomain: true});
    return result.data;
}

export const getMemberOrders = async (params) => {
    const result = await api.get(CONTRACT_LIST_URL, {params: params}, {crossDomain: true});
    return result.data;
}

export const getPTList = async (params) => {
    const result = await api.get(PT_LIST_URL, {params: params}, {crossDomain: true});
    if(result.data.data) {
        return result.data.data;
    }
    return [];
}

export const getPTSchedules = async (params) => {
    const result = await api.get(SCHEDULE_LIST_URL, {params: params}, {crossDomain: true});
    return result.data;
}

export const addBooking = async (params) => {
    const result = await api.post(BOOK_ADD_URL, params, {crossDomain : true});
    return result.data;
}

export const updateBooking = async (params) => {
    let URL = BOOK_UPDATE_URL + params.id;
    const result = await api.post(URL, params, {crossDomain : true});
    return result.data;
}

export const removeBooking = async (params) => {
    let URL = BOOK_DELETE_URL + params.id;
    const result = await api.delete(URL, params, {crossDomain : true});
    return result.data;
}

export const getBooking = async (params) => {
    let URL = BOOK_INFO_URL + params.id;
    const result = await api.get(URL, {params: params}, {crossDomain : true});
    return result.data;
}

export const getMemberBooks = async (params) => {
    const result = await api.get(GET_BOOKS_URL, {params: params}, {crossDomain : true});
    return result.data;
}