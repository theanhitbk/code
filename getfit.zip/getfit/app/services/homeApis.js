import { api } from './api';
import { HOME_URL } from './config';

export const getHomeData = async (params) => {
    const result = await api.get(HOME_URL, {params: params}, {crossDomain : true});
    return result.data;
}
