/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React ,{useEffect,useState}from 'react';
import MainStack from './app/routing/MainStack';
import {Provider, useSelector } from 'react-redux';
import {Alert, Platform, StatusBar, ActivityIndicator } from 'react-native';
import storePre from './app/redux/store';
import DropdownAlert from 'react-native-dropdownalert';
import {AlertHelper} from './app/utils/AlertHelper';
import {PersistGate} from 'redux-persist/integration/react';
import TabNavigationStack from './app/routing/TabNavigationStack';
import Feather from 'react-native-vector-icons/Feather'; 
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import FontAwesome from 'react-native-vector-icons/FontAwesome'; 
import messaging from '@react-native-firebase/messaging';
import { getToken, saveDeviceToken } from './app/utils/storage';
import Login from './app/screens/Login';
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import Welcome from './app/screens/Welcome';
import Home from './app/screens/Home';
import SplashScreen from './app/screens/SplashScreen';
import PasswordScreen from './app/screens/Login/PasswordScreen';
import {MenuProvider} from 'react-native-popup-menu';
import { ModalPortal } from 'react-native-modals';

Ionicons.loadFont()
FontAwesome.loadFont()
Feather.loadFont()

const Stack = createStackNavigator()

const App: () => React$Node = () => {
  const {persistor, store} = storePre;
  const [animating, setAnimating] = useState(true);

  /*
  const _onChangeToken = (token) => {
    var data = {
      'device_token': token,
      'device_type': Platform.OS,
    };

    _loadDeviceInfo(data).done();
  };

  const _loadDeviceInfo = async (deviceData) => {
    var value = JSON.stringify(deviceData);
    try {
      await saveDeviceToken(value);
    } catch (error) {
      console.log(error);
    }
  };

  messaging().getToken().then((token) => {
      _onChangeToken(token)
  });

  messaging().onTokenRefresh((token) => {
      _onChangeToken(token)
  });
  */
 
  const RootNavigation = () => {
    const isAuth = useSelector((state) => state.login.isLoggedIn);
    const token = '';
      getToken().then(token => {
        token = token;
      });

      if(!isAuth && token.length == 0) {
        return <>
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName="Welcome"
            screenOptions={{
              headerShown: false,
            }}
          >
            <Stack.Screen name="Welcome" component={Welcome} />
            <Stack.Screen name="Login" component={Login} />
            <Stack.Screen name="PasswordScreen" component={PasswordScreen} />
            <Stack.Screen name="Home" component={Home} />
            <Stack.Screen name="SplashScreen" component={SplashScreen} />
          </Stack.Navigator>
        </NavigationContainer>
        </>
      }

      return (
        <TabNavigationStack isAuth={isAuth}/>
        // {navigationTypeTabs ? <TabNavigationStack isAuth={isAuth}/> : <MainStack />}
        // <PaperProvider theme={paperTheme}>
        //   <Navigator theme={combinedTheme} />
        // </PaperProvider>
      );
  };
  
  return (
    <Provider store={store}>
      <StatusBar hidden={true} />
      <PersistGate loading={<ActivityIndicator />} persistor={persistor} animating={animating}>
        {/* <PaperProvider> */}
        <MenuProvider>
          <RootNavigation />
        </MenuProvider>
        {/* </PaperProvider> */}
        <ModalPortal />
        <DropdownAlert
          // defaultContainer={{
          //   padding: 8,
          //   paddingTop: StatusBar.currentHeight,
          //   flexDirection: 'row',
          // }}
          ref={(ref) => AlertHelper.setDropDown(ref)}
          onClose={() => AlertHelper.invokeOnClose()}
        />
      </PersistGate>
    </Provider>
  );
};

export default App;
