class AppUser {
  final String email;
  final String password;
  final String token;

  AppUser({this.email, this.password, this.token});
}
