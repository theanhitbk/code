class ServerAddresses {
  //Server address of your project should go here
  static const serverAddress = 'api.phanmembanhang.com';// 'woocommerce.openflutterproject.com';
  static const serverAddressURL = 'http://api.phanmembanhang.com';
  //?consumer_key=ck_*****&consumer_secret=cs_**** goes here
  static const _woocommerceKeys = '';
  static const _categorySuffix = '/api/Category/ProductGroupList';// '/wp-json/wc/v3/products/categories/'; //id
  static const _productSuffix = '/api/Category/ProductListV2';// '/wp-json/wc/v3/products/categories/';
  static const _promoSuffix = ' /wp-json/wc/v3/reports/coupons/';
  static const signUp = ''; // TODO need an endpoint for this
  static const forgotPassword = '';// TODO need an endpoint for this
  static const changePassword = 'api/Customer/ChangePwd';
  static const getConfig = serverAddressURL + '/api/Common/GetConfig';
  static const getCustomer = 'api/Category/CustomerList';
  static const locationSuffix = 'api/Category/LocationList';

  /// For more information about wp-rest-api plugin
  /// https://wordpress.org/plugins/jwt-authentication-for-wp-rest-api/
  static const authToken = 'api/token';// 'wp-json/jwt-auth/v1/token';

  static const orderSuffix = '/api/PurchaseOrder/AddNewPurchaseOrder';
  static const orderDetailSuffix = '/api/PurchaseOrder/GetPurchaseOrderDetail';
  static const myOrderSuffix = '/api/PurchaseOrder/PurchaseOrderList';
  static const generateOrderIdSuffix = '/api/PurchaseOrder/GetNewCode/""';
  static const productSuffix = '/api/Category/GetProductInfoDL';

  //CACHED API (for test purposes only)
  static const _productCategoriesCached = '/cachedapi/v3/products/categories.json';
  static const _productsCached = '/cachedapi/v3/products/products.json';
  static const _promosCached = '/cachedapi/v3/coupon.json';

  static bool useStatic = _woocommerceKeys.isNotEmpty;

  static String get productCategories => serverAddressURL  +
    (useStatic ? _productCategoriesCached 
      : _categorySuffix + _woocommerceKeys);

  static String get products => serverAddressURL  +
    (useStatic ? _productsCached 
      : _productSuffix + _woocommerceKeys);

  static String get promos => serverAddress  +
    (useStatic ? _promosCached 
      : serverAddress  +_promoSuffix + _woocommerceKeys);

  static String get orderUrl => serverAddressURL + orderSuffix;
  static String get myOrderUrl => serverAddressURL + myOrderSuffix;
  static String get genOrderIdUrl => serverAddressURL + generateOrderIdSuffix;
  static String get productDetailUrl => serverAddressURL + productSuffix;
  static String get orderDetailUrl => serverAddressURL + orderDetailSuffix;
  static String get changePasswordUrl => serverAddressURL + changePassword;
  static String get locationUrl => serverAddressURL + locationSuffix;
}
