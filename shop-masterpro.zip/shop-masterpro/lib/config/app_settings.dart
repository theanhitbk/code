class AppSettings {
  static bool cacheIsEnabled;
  static bool profileEnabled = true;
  static String locale = 'vi';
  static String fontFamily = 'Time New Roman'; //Metropolis
  static bool isListViewState = true;
}
