// Favourites Grid list of products and on Favourites screen
// Author: umair_adil@live.com
// Date: 2020-02-14

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hosco/config/routes.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/presentation/features/product_details/product_screen.dart';
import 'package:hosco/presentation/widgets/extensions/product_view.dart';

import '../favorites_bloc.dart';
import '../favorites_event.dart';
import '../favorites_state.dart';

class FavouritesTileView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FavouriteBloc, FavouriteState>(
        builder: (context, state) {
      return SliverGrid(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 4.0,
            crossAxisSpacing: 4.0,
            childAspectRatio: 1.589),
        delegate: SliverChildBuilderDelegate(
          (BuildContext context, int index) {
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: AppSizes.sidePadding),
              child: state.data[index].getTileView(
                context: context,
                showProductInfo: () {
                  Navigator.of(context).pushNamed(
                      hoscoRoutes.product,
                      arguments: ProductDetailsParameters(
                          state.data[index].product.id,
                          state.data[index].product.unitId,
                          state.data[index].product.categories.isNotEmpty ? 
                            state.data[index].product.categories[0].id: '0',
                          selectedAttributes: state.data[index].favoriteForm));
                },
                onRemoveFromFavorites: () {
                  BlocProvider.of<FavouriteBloc>(context).add(
                      RemoveFromFavoriteEvent(state.data[index]));
                },
                onAddToCart: () {
                  BlocProvider.of<FavouriteBloc>(context)
                    .add(AddToCartEvent(state.data[index]));
                  Navigator.of(context)
                    .pushNamed(hoscoRoutes.cart);
                },
                selectedAttributes: state.data[index]?.favoriteForm
              ),
            );
          },
        ),
      );
    });
  }
}
