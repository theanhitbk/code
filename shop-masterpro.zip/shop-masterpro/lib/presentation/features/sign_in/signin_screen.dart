import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hosco/config/routes.dart';
import 'package:hosco/config/storage.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/domain/entities/validator.dart';
import 'package:hosco/presentation/features/sign_up/sign_up.dart';
import 'package:hosco/presentation/widgets/widgets.dart';

import 'sign_in.dart';

class SignInScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _SignInScreenState();
  }
}

class _SignInScreenState extends State<SignInScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController tenantController = TextEditingController();
  final GlobalKey<OpenFlutterInputFieldState> emailKey = GlobalKey();
  final GlobalKey<OpenFlutterInputFieldState> passwordKey = GlobalKey();
  final GlobalKey<OpenFlutterInputFieldState> tenantKey = GlobalKey();

  double sizeBetween;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    sizeBetween = height / 20;
    return Scaffold(
      appBar: AppBar(
        // title: Text('Đăng nhập', style: Theme.of(context).accentTextTheme.headline4.copyWith(
        //   color: Colors.lightBlue, fontWeight: FontWeight.bold
        // ),),
        title: null,
        centerTitle: true,
        backgroundColor: AppColors.transparent,
        brightness: Brightness.light,
        elevation: 0,
        iconTheme: IconThemeData(color: AppColors.black),
      ),
      backgroundColor: AppColors.background,
      body: BlocConsumer<SignInBloc, SignInState>(
        listener: (context, state) {
          // on success delete navigator stack and push to home
          if (state is SignInFinishedState) {
            Navigator.of(context).pushNamedAndRemoveUntil(
              hoscoRoutes.home,
              (Route<dynamic> route) => false,
            );
          }
          // on failure show a snackbar
          if (state is SignInErrorState) {
            Scaffold.of(context).showSnackBar(
              SnackBar(
                content: Text('${state.error}'),
                backgroundColor: Colors.red,
                duration: Duration(seconds: 3),
              ),
            );
          }
        },
        builder: (context, state) {
          // show loading screen while processing
          if (state is SignInProcessingState) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          tenantController.text = Storage()?.account?.tenantCode??'';
          emailController.text = Storage()?.account?.username??'';
          passwordController.text = Storage()?.account?.password??'';

          return SingleChildScrollView(
                  child: Container(
                    height: height * 0.9,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Stack(
                          children: <Widget>[
                            Align(
                              alignment: Alignment.topCenter,
                              child: AppLogo(),
                            ),
                          ]
                        ),
                        SizedBox(
                          height: sizeBetween,
                        ),
                        OpenFlutterInputField(
                          key: tenantKey,
                          controller: tenantController,
                          hint: 'Mã khách hàng',
                          validator: Validator.validateCusCode,
                          onValueChanged: (val) {

                          },
                          //error: tenantKey.currentState.validate(),
                        ),
                        OpenFlutterInputField(
                          key: emailKey,
                          controller: emailController,
                          hint: 'Tên đăng nhập',
                          validator: Validator.validateUsername,
                          onValueChanged: (val) {

                          },
                          //error: emailKey.currentState.validate(),
                        ),
                        // OpenFlutterInputField(
                        //   key: emailKey,
                        //   controller: emailController,
                        //   hint: 'Email',
                        //   validator: Validator.validateEmail,
                        //   keyboard: TextInputType.emailAddress,
                        // ),
                        OpenFlutterInputField(
                          key: passwordKey,
                          controller: passwordController,
                          hint: 'Mật khẩu',
                          validator: Validator.passwordCorrect,
                          keyboard: TextInputType.visiblePassword,
                          isPassword: true,
                          onValueChanged: (val) {

                          },
                        ),
                        /*OpenFlutterRightArrow(
                    'Forgot your password',
                    onClick: _showForgotPassword,
                  ),*/
                        OpenFlutterButton(
                            title: 'ĐĂNG NHẬP', onPressed: _validateAndSend),
                        SizedBox(
                          height: sizeBetween * 2,
                        ),
                        /* Padding(
                    padding: EdgeInsets.only(bottom: AppSizes.linePadding),
                    child: Center(
                      child: Text('Or sign up with social account'),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: width * 0.2),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        OpenFlutterServiceButton(
                          serviceType: ServiceType.Google,
                          onPressed: () {
                            BlocProvider.of<SignInBloc>(context).add(
                              SignInPressedGoogle(),
                            );
                          },
                        ),
                        OpenFlutterServiceButton(
                          serviceType: ServiceType.Facebook,
                          onPressed: () {
                            BlocProvider.of<SignInBloc>(context).add(
                              SignInPressedFacebook(),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  */
                ]),
              )
          );
        },
      ),
    );
  }

  void _showForgotPassword() {
    Navigator.of(context).pushNamed(hoscoRoutes.forgotPassword);
  }

  void _validateAndSend() {
    if (tenantKey.currentState.validate() != null) {
      tenantKey.currentState.error = tenantKey.currentState.validate();
      return;
    }

    if (emailKey.currentState.validate() != null) {
      emailKey.currentState.error = emailKey.currentState.validate();
      return;
    }

    if (passwordKey.currentState.validate() != null) {
      passwordKey.currentState.error = passwordKey.currentState.validate();
      return;
    }
    BlocProvider.of<SignInBloc>(context).add(
      SignInPressed(
        tenantCode: tenantController.text,
        email: emailController.text,
        password: passwordController.text,
      ),
    );
  }
}

class AppLogo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100.0,
      height: 100.0,
      decoration:
      BoxDecoration(shape: BoxShape.circle, color: Colors.green[800]),
      child: CircleAvatar(
        radius: 60.0,
        backgroundColor: Colors.transparent,
        backgroundImage: AssetImage('assets/icons/signin/icon.png'),
        // backgroundImage: NetworkImage(
        //     'https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg?cs=srgb&dl=bloom-blooming-blossom-462118.jpg&fm=jpg'),
      ),
    );
  }
}
