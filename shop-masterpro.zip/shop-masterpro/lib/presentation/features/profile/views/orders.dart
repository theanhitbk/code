import 'dart:async';

import 'package:bubble_tab_indicator/bubble_tab_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/data/model/user_order.dart';
import 'package:hosco/data/repositories/abstract/order_repository.dart';
import 'package:hosco/domain/usecases/orders/orders_by_filter_params.dart';
import 'package:hosco/locator.dart';
import 'package:hosco/presentation/widgets/data_driven/order_tile.dart';
import 'package:hosco/presentation/widgets/independent/loading_view.dart';
import 'package:hosco/presentation/widgets/widgets.dart';

import '../../../../config/routes.dart';
import '../../wrapper.dart';
import '../profile.dart';
import '../profile_bloc.dart';
import '../profile_state.dart';

class MyOrdersView extends StatefulWidget {
  final Function changeView;

  const MyOrdersView({Key key, this.changeView}) : super(key: key);

  @override
  _MyOrdersViewState createState() => _MyOrdersViewState();
}

class _MyOrdersViewState extends State<MyOrdersView> with SingleTickerProviderStateMixin {

  TabController controller;
  int page = 0;
  int _currentIndex = 0;
  int status = 2;
  String searchPattern;
  final _scrollController = ScrollController();
  final _suggestionBloc = SuggestionBloc();

  Icon _searchIcon = Icon(
    Icons.search,
  );
  bool isSearchClicked = false;

  @override
  void initState() {
    super.initState();
    controller = TabController(length: 1, vsync: this);
    //_suggestionBloc.fetchSuggestions(0, searchPattern, status, false);
    _scrollController.addListener(_scrollListener);
    controller.addListener(_handleTabSelection);
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
    _suggestionBloc.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels == _scrollController.position.maxScrollExtent && page <= _suggestionBloc.totalPage) {
      _suggestionBloc.fetchSuggestions(++page, searchPattern, status, false);
    }
  }

  void _handleTabSelection() {
    setState(() {
      _currentIndex = controller.index;
    });
  }

  final List<Widget> tabs = <Widget>[
    /*
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.sidePadding),
      child: Tab(text: 'Hoàn thành'),
    ),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.sidePadding),
      child: Tab(text: 'Đã xử lý'),
    ),*/
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.sidePadding),
      child: Tab(text: 'Đang đặt hàng'),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    var _theme = Theme.of(context);
    var width = MediaQuery.of(context).size.width;

    var bloc = BlocProvider.of<ProfileBloc>(context);

    //if(searchPattern != null) {
      _suggestionBloc.fetchSuggestions(0, searchPattern, status, true);
    //}

    return SafeArea(
      child: NestedScrollView(
        controller: _scrollController,
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return [
            SliverAppBar(
              actions: <Widget>[
                RawMaterialButton(
                  elevation: 0.0,
                  child: _searchIcon,
                  onPressed: () {
                    _searchPressed();
                  },
                  constraints: BoxConstraints.tightFor(
                    width: 56,
                    height: 56,
                  ),
                  shape: CircleBorder(),
                ),
              ],
                title:isSearchClicked ? Container(
                  padding: EdgeInsets.only(bottom: 2),
                  constraints:
                  BoxConstraints(minHeight: 40, maxHeight: 40),
                  width: 220,
                  child: CupertinoTextField(
                    onChanged: (val) {
                      setState(() {
                        searchPattern = val;
                      });
                    },
                    //controller: _filter,
                    keyboardType: TextInputType.text,
                    placeholder: 'Tìm kiếm...',
                    placeholderStyle: TextStyle(
                      color: Color(0xffC4C6CC),
                      fontSize: 14.0,
                      fontFamily: 'Brutal',
                    ),
                    prefix: Padding(
                      padding:
                      const EdgeInsets.fromLTRB(9.0, 6.0, 9.0, 6.0),
                      child: Icon(Icons.search, ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.0),
                      color: Colors.white,
                    ),
                  ),
                ) : Text('Đơn hàng'),
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black,),
                onPressed: () {
                  Navigator.pushNamed(
                      context, hoscoRoutes.profile);
                },
              ),
              pinned: true,
              backgroundColor: Colors.white,
              flexibleSpace: FlexibleSpaceBar(
                collapseMode: CollapseMode.pin,
                background: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    /*
                            Container(
                              height: 200.0,
                              width: double.infinity,
                              color: Colors.grey,
                              child: FlutterLogo(),
                            ),*/
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Text(
                        'Business Office',
                        style: TextStyle(fontSize: 25.0),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Text(
                        'Open now\nStreet Address, 299\nCity, State',
                        style: TextStyle(fontSize: 15.0),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    /*
                            Padding(
                              padding: const EdgeInsets.only(right: 10.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: <Widget>[
                                  Icon(Icons.share),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 10.0),
                                    child: Icon(Icons.favorite),
                                  ),
                                ],
                              ),
                            )*/

                    OpenFlutterBlockHeader(
                      title: 'Đơn đặt hàng',
                      width: width,
                    ),
                    Padding(
                        padding: EdgeInsets.only(
                            bottom: AppSizes.sidePadding)),
                  ],
                ),
              ),
              //expandedHeight: 380.0,
              /*
              bottom: TabBar(
                indicatorColor: Colors.black,
                // labelColor: Colors.black,
                controller: controller,
                indicatorSize: TabBarIndicatorSize.tab,
                labelColor: AppColors.white,
                labelPadding: EdgeInsets.symmetric(horizontal: 4),
                unselectedLabelColor: AppColors.black,
                indicator: BubbleTabIndicator(
                  indicatorHeight: 32,
                  indicatorColor: Colors.black,
                  tabBarIndicatorSize: TabBarIndicatorSize.tab,
                ),
                tabs: tabs,
                unselectedLabelStyle: _theme.textTheme.display3,
                labelStyle: _theme.textTheme.display3
                    .copyWith(color: AppColors.white),
                onTap: (int index) {
                  setState(() {
                    status = index;
                    _currentIndex = controller.index;
                  });
                },
              ),*/
            )
          ];
        },
        body: StreamBuilder(
          stream: _suggestionBloc.suggestionStream,
          builder: (_, snapshot) {
            if (snapshot.hasData) {
              final items = snapshot.data;
              return ListView.builder(
                  shrinkWrap: true,
                  // controller: _scrollController,
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    return OpenFlutterOrderTile(
                      order: items[index],
                      onClick: ((String orderId) => {
                        bloc..add(ProfileMyOrderDetailsEvent(orderId)),
                        widget.changeView(changeType: ViewChangeType.Exact, index: 7)
                      }),
                    );
                  });
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                      (_, int index) {
                    return OpenFlutterOrderTile(
                      order: items[index],
                      onClick: ((String orderId) => {
                        bloc..add(ProfileMyOrderDetailsEvent(orderId)),
                        widget.changeView(changeType: ViewChangeType.Exact, index: 7)
                      }),
                    );
                  },
                  childCount: items.length,
                ),
              );
            } else {
              return LoadingView();
            }
          },
        ),
      ),
    );

    return BlocConsumer<ProfileBloc, ProfileState>(
        listener: (context, state) {},
        builder: (context, state) {
          var bloc = BlocProvider.of<ProfileBloc>(context);
          if (state is ProfileMyOrdersState) {
            return SafeArea(
              child: DefaultTabController(
                length: tabs.length,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: AppSizes.sidePadding),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            OpenFlutterBlockHeader(
                              title: 'Đơn đặt hàng',
                              width: width,
                            ),
                            Padding(
                                padding: EdgeInsets.only(
                                    bottom: AppSizes.sidePadding)),
                            TabBar(
                              indicatorSize: TabBarIndicatorSize.tab,
                              labelColor: AppColors.white,
                              labelPadding: EdgeInsets.symmetric(horizontal: 4),
                              unselectedLabelColor: AppColors.black,
                              indicator: BubbleTabIndicator(
                                indicatorHeight: 32,
                                indicatorColor: Colors.black,
                                tabBarIndicatorSize: TabBarIndicatorSize.tab,
                              ),
                              tabs: tabs,
                              unselectedLabelStyle: _theme.textTheme.display3,
                              labelStyle: _theme.textTheme.display3
                                  .copyWith(color: AppColors.white),
                            ),
                          ]),
                    ),
                    Padding(
                        padding: EdgeInsets.only(bottom: AppSizes.sidePadding)),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: AppSizes.sidePadding),
                        child: TabBarView(
                          children: <Widget>[
                            buildOrderList(state.orderData, bloc),
                            buildOrderList(state.orderData, bloc),
                            buildOrderList(state.orderData, bloc),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
          return Container();
        });
  }

  ListView buildOrderList(List<UserOrder> orders, ProfileBloc bloc) {
    return ListView.builder(
        shrinkWrap: true,
        itemCount: orders.length,
        itemBuilder: (context, index) {
          return OpenFlutterOrderTile(
            order: orders[index],
            onClick: ((String orderId) => {
                  bloc..add(ProfileMyOrderDetailsEvent(orderId)),
                  widget.changeView(changeType: ViewChangeType.Exact, index: 7)
                }),
          );
        });
  }

  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = Icon(
          Icons.close,
        );
        isSearchClicked = true;
      } else {
        _searchIcon = Icon(
          Icons.search,
        );
        isSearchClicked = false;
        searchPattern = '';
      }
    });
  }
}

class SuggestionBloc {
  final _suggestions = <UserOrder>[];
  int _totalPage = 0;
  int _totalCount = 0;

  final StreamController<List<UserOrder>> _suggestionController = StreamController<List<UserOrder>>();

  Stream<List<UserOrder>> get suggestionStream => _suggestionController.stream;

  int get totalPage => _totalPage;
  int get totalCount => _totalCount;

  void fetchSuggestions(int page, String patternSearch, int status, bool reset) async {
    OrderRepository orderRepository = sl();
    OrdersByFilterParams params = OrdersByFilterParams(
      PageIndex: page, OrderStatus: status,
      SearchPattern: patternSearch??''
    );
    var ret = await orderRepository.getRawMyOrders(params);

    _totalPage = ret.paging != null ? ret.paging['TotalPage']??0 : 0;
    _totalCount = ret.paging != null ? ret.paging['TotalCount']??0 : 0;
    //await Future.delayed(Duration(seconds: 2));
    if(reset) {
      _suggestions.clear();
    }
    if(!_suggestionController.isClosed) {
      _suggestions.addAll(ret.data.take(AppConsts.page_size));
      _suggestionController.sink.add(_suggestions);
    }
  }

  void dispose() {
    _suggestionController.close();
    _suggestions.clear();
  }
}