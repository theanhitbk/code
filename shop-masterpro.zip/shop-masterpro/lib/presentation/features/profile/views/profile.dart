import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:hosco/config/storage.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/presentation/features/authentication/authentication.dart';
import 'package:hosco/presentation/features/wrapper.dart';
import 'package:hosco/presentation/widgets/independent/custom_button.dart';
import 'package:hosco/presentation/widgets/independent/menu_line.dart';
import 'package:hosco/presentation/widgets/independent/scaffold.dart';

import '../profile.dart';

class ProfileView extends StatefulWidget {
  final Function changeView;

  const ProfileView({Key key, this.changeView}) : super(key: key);

  @override
  _ProfileViewState createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  @override
  Widget build(BuildContext context) {
    var bloc = BlocProvider.of<ProfileBloc>(context);
    final authBloc = BlocProvider.of<AuthenticationBloc>(context);

    return Scaffold(
        appBar: AppBar(
          title: Text('Tài khoản'),
          centerTitle: true,
          leading: Container(),
        ),
        body: ListView(
      children: <Widget>[
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            /*Padding(
              padding: const EdgeInsets.only(top: 40.0, left: 10.0),
              child: Container(
                  child: Text(
                'My profile',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 34.0),
              )),
            ),*/
            SizedBox(
              height: 5.0,
            ),
            ListTile(
              leading: Container(
                height: 60.0,
                width: 60.0,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: Storage().account?.avatar != null? NetworkImage(Storage().account.avatar) : AssetImage('assets/profile/user-profile.jpeg'))),
              ),
              title: Text(
                Storage().account?.name??'',
                style: TextStyle(
                  color: AppColors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                Storage().account?.email??'',
                style: TextStyle(
                    color: AppColors.lightGray, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
              height: 25.0,
            ),
            OpenFlutterMenuLine(
              title: 'Đơn hàng của tôi',
              //TODO: make short card info
              subtitle: '',
              onTap: (() => {
                bloc..add(ProfileMyOrdersEvent()),
                widget.changeView(
                  changeType: ViewChangeType.Exact, index: 1)
              })),
            /*Divider(),
            OpenFlutterMenuLine(
              title: 'Shipping addresses',
              //TODO: make dynamic address count
              subtitle: '',
              onTap: (() => {
                widget.changeView(
                  changeType: ViewChangeType.Exact, index: 2)
              })),
            Divider(),
            OpenFlutterMenuLine(
              title: 'Payments methods',
              //TODO: make short card info
              subtitle: 'visa **34',
              onTap: (() => {
                  widget.changeView(
                    changeType: ViewChangeType.Exact, index: 3)
                })),
            Divider(),
            OpenFlutterMenuLine(
              title: 'Promocodes',
              //TODO: make dynamic later
              subtitle: 'You have special promocodes',
              onTap: (() => {
                widget.changeView(
                    changeType: ViewChangeType.Exact, index: 4)
              })),
            Divider(),
            OpenFlutterMenuLine(
              title: 'My reviews',
              //TODO: make dynamic later
              subtitle: 'review for 4 items',
              onTap: (() => {
                widget.changeView(
                    changeType: ViewChangeType.Exact, index: 5)
              })),
            Divider(),*/
            OpenFlutterMenuLine(
                title: 'Cài đặt',
                subtitle: 'Thông tin, Mật khẩu',
                onTap: (() => {
                  widget.changeView(
                      changeType: ViewChangeType.Exact, index: 6)
                  //Navigator.of(context).pushNamed(hoscoRoutes.settings)
                })),
            Divider(
              height: 100.0,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 110.0, vertical: 8.0),
              child: InkWell(
                onTap: (() => {
                  authBloc.add(LoggedOut())
                }),
                child: Container(
                  //width: 100.0,
                  height: 35.0,
                  padding: EdgeInsets.symmetric(horizontal: 6.0, vertical: 4.0),
                  decoration: BoxDecoration(
                      color: AppColors.red,
                      border: Border.all(color: AppColors.red),
                      borderRadius: BorderRadius.circular(AppSizes.buttonRadius),
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.red.withOpacity(0.3),
                            blurRadius: 4.0,
                            offset: Offset(0.0, 5.0)),
                      ]),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6.0, vertical: 4.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(
                            right: 8.0,
                          ),
                          child: Icon(
                            Icons.logout,
                            size: 14.0,
                            color: Theme.of(context).textTheme.button.color,
                          ),
                        ),
                      Text(
                        'ĐĂNG XUẤT',
                         style: Theme.of(context).textTheme.button.copyWith(
                           backgroundColor: Theme.of(context).textTheme.button.backgroundColor,
                           color: Theme.of(context).textTheme.button.color,
                         ),
                      ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            /*
            OpenFlutterMenuLine(
                title: 'Logout',
                subtitle: '',
                onTap: (() => {
                  authBloc.add(LoggedOut())
                  //Navigator.of(context).pushNamed(hoscoRoutes.signout)
                }))*/
          ],
        )
      ],
    ));
  }
}
