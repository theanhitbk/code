
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumberInputWithIncrementDecrement extends StatefulWidget {
  @override
  _NumberInputWithIncrementDecrementState createState() =>
      _NumberInputWithIncrementDecrementState();
}

class _NumberInputWithIncrementDecrementState
    extends State<NumberInputWithIncrementDecrement> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller.text = '1'; // Setting the initial value for the field.
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(0.0),
        child: Center(
          child: Container(
            width: 220.0,
            height: 30,
            foregroundDecoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5.0),
              border: Border.all(
                color: Colors.blueGrey,
                width: 1.0,
              ),
            ),
            child: Row(
              children: <Widget>[
                InkWell(
                  onTap: () {
                    int currentValue = int.parse(_controller.text);
                    setState(() {
                      currentValue--;
                      _controller.text =
                          (currentValue > 1 ? currentValue : 1)
                              .toString(); // decrementing value
                    });
                  },
                  child: Icon(
                    Icons.remove,
                    size: 20.0,
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.black),
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(4.0),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                    ),
                    controller: _controller,
                    keyboardType: TextInputType.numberWithOptions(
                      decimal: false,
                      signed: true,
                    ),
                    inputFormatters: <TextInputFormatter>[
                      WhitelistingTextInputFormatter.digitsOnly
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    int currentValue = int.parse(_controller.text);
                    setState(() {
                      currentValue++;
                      _controller.text =
                          (currentValue > 1 ? currentValue : 1)
                              .toString(); // decrementing value
                    });
                  },
                  child: Icon(
                    Icons.add,
                    size: 20.0,
                  ),
                ),
                /*
                Container(
                  height: 30.0,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              width: 0.3,
                            ),
                          ),
                        ),
                        child: InkWell(
                          onTap: () {
                            int currentValue = int.parse(_controller.text);
                            setState(() {
                              currentValue++;
                              _controller.text = (currentValue)
                                  .toString(); // incrementing value
                            });
                          },
                          child: Icon(
                            Icons.arrow_drop_up,
                            size: 15.0,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          int currentValue = int.parse(_controller.text);
                          setState(() {
                            print('Setting state');
                            currentValue--;
                            _controller.text =
                                (currentValue > 0 ? currentValue : 0)
                                    .toString(); // decrementing value
                          });
                        },
                        child: Icon(
                          Icons.arrow_drop_down,
                          size: 15.0,
                        ),
                      ),
                    ],
                  ),
                ),*/
              ],
            ),
    ))
    );
  }
}