
import 'categories/categories_by_filter_use_case_test.dart' as categories_by_filter_use_case_test;
import 'products/find_products_by_filter_use_case_test.dart' as find_products_by_filter_use_case_test;

void main() async {
  categories_by_filter_use_case_test.main();
  find_products_by_filter_use_case_test.main();
}
