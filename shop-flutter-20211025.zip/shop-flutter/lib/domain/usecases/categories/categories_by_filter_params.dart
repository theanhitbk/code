
class CategoriesByFilterParams {
  final String categoryId;

  CategoriesByFilterParams({
    this.categoryId
  });
}