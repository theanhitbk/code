class ProductRating {
  final double rating;
  final int quantity;

  ProductRating({
    this.rating,
    this.quantity,
  });
}
