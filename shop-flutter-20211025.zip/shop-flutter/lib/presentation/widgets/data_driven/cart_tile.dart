import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hosco/presentation/widgets/data_driven/flutter_masked_text.dart';
import 'package:hosco/presentation/widgets/independent/input_number_increase_decrease_field.dart';
import 'package:intl/intl.dart';
import 'package:hosco/config/app_settings.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/data/model/cart_item.dart';
import 'package:hosco/presentation/features/cart/views/selected_attribute_view.dart';

class OpenFlutterCartTile extends StatefulWidget {
  final CartItem item;
  final Function(double quantity) onChangeQuantity;
  final Function(int type, double value) onChangeDiscount;
  final Function() onAddToFav;
  final Function() onRemoveFromCart;
  final bool orderComplete;

  const OpenFlutterCartTile(
      {Key key,
      @required this.item,
      @required this.onChangeQuantity,
      @required this.onAddToFav,
      @required this.onRemoveFromCart,
        this.onChangeDiscount,
      this.orderComplete = false})
      : super(key: key);

  @override
  _OpenFlutterCartTileState createState() => _OpenFlutterCartTileState();
}

class _OpenFlutterCartTileState extends State<OpenFlutterCartTile> {
  bool showPopup = false;
  List<bool> isSelected = [true, false];
  num discount = 0;
  int discountType = 1;
  final TextEditingController _controller = TextEditingController();
  final TextEditingController _discountController = TextEditingController();
  var controller = MoneyMaskedTextController(initialValue: 0, precision: 0,decimalSeparator: '', thousandSeparator: '.');

  @override
  void initState() {
    //_discountController.text = discount.toString();
    super.initState();
    _controller.text = widget.item.productQuantity.quantity.toString();
    _controller.selection = TextSelection.fromPosition(TextPosition(offset: _controller.text.length));
  }

  @override
  void dispose() {
    _discountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _theme = Theme.of(context);
    var width = MediaQuery.of(context).size.width;

    if(widget.item.product.mDiscount != 0) {
      controller.text =
          NumberFormat.currency(locale: AppSettings.locale, symbol: 'đ').format(
              widget.item.product.mDiscount);
    }
    return Padding(
        padding: EdgeInsets.only(bottom: 0.0), //AppSizes.sidePadding),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: AppSizes.linePadding),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppSizes.imageRadius),
              boxShadow: [
                BoxShadow(
                    color: AppColors.lightGray.withOpacity(0.3),
                    blurRadius: AppSizes.imageRadius,
                    offset: Offset(0.0, AppSizes.imageRadius))
              ],
              color: AppColors.white),
          child: Stack(children: <Widget>[
            Row(
              children: <Widget>[
                Container(
                    width: width/4,
                    child: widget.item.product.mainImage.isLocal
                        ? Image.asset(widget.item.product.mainImage.address)
                        : Image.network(
                            widget.item.product.mainImage.address,
                      height: 100.0,
                    )
                ),
                Container(
                    padding: EdgeInsets.only(left: AppSizes.sidePadding, bottom: 5.0, top: 5.0),
                    width: MediaQuery.of(context).size.width * 0.65,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                  //width: width - 173,
                                  child: Text(widget.item.product.title.length > 25 ? widget.item.product.title.substring(0, 25) + '...' : widget.item.product.title,
                                      style: _theme.textTheme.display1
                                          .copyWith(
                                              fontWeight: FontWeight.bold,
                                              color: _theme.primaryColor)),
                                ),
                                /*
                                !widget.orderComplete
                                    ? InkWell(
                                        onTap: (() => {
                                              //TODO: show popup with add to favs and delete from cart
                                              showPopup = !showPopup,
                                              setState(() => {})
                                            }),
                                        child:
                                            Icon(Icons.more_vert, size: 24))
                                    : Container(),*/
                              ]),
                          Padding(
                              padding: EdgeInsets.only(
                                  bottom: 0)),
                          Wrap(
                              children: widget.item.selectedAttributes
                                  .map((key, value) => MapEntry(
                                      key,
                                      SelectedAttributeView(
                                        productAttribute: key,
                                        selectedValue: value,
                                      )))
                                  .values
                                  .toList()),
                          Padding(
                            padding: EdgeInsets.only(
                                bottom: AppSizes.linePadding * 2),
                          ),
                          Container(
                            //width: width,
                            alignment: Alignment.centerLeft,
                            child: Text('Giá bán: ' +
                                NumberFormat.currency(locale: AppSettings.locale, symbol: 'đ').format(widget.item.product.price) + ' / ' +widget.item.product.unit,
                                style: _theme.textTheme.headline6.copyWith(fontSize: 14.0)),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                bottom: AppSizes.linePadding * 2),
                          ),
                          Container(
                              child: Row(
                                children: <Widget>[
                                  widget.item.product.mDiscount != 0.0 ?
                                  Flexible(child: Container(
                                          width: widget.item.product.mDiscount != 0 ? 200 : 50,
                                          child: Text('Giảm giá' + (widget.item.product.mDiscount > 0 ? ': ' + NumberFormat.currency(locale: AppSettings.locale, symbol: 'đ').format(
                                              widget.item.product.mDiscount) : ''),
                                              style: _theme.textTheme.headline6.copyWith(fontSize: 12.0, fontWeight: FontWeight.normal))
                                      )
                                  ): Container(),
                                  !widget.orderComplete ?
                                  Container(
                                    alignment: Alignment.centerLeft,
                                    //width: 180,
                                    height: 26,
                                    child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            width: 96,
                                            padding: EdgeInsets.all(0.0),
                                            margin: EdgeInsets.all(0.0),
                                            alignment: Alignment.centerLeft,
                                            child: SizedBox.expand(child: ToggleButtons(
                                              borderColor: Colors.lightBlueAccent,
                                              fillColor: Colors.green,
                                              borderWidth: 0.0,
                                              selectedBorderColor:
                                              Colors.lightBlueAccent,
                                              selectedColor: Colors.white,
                                              borderRadius: BorderRadius.circular(0),
                                              onPressed: (int index) {
                                                setState(() {
                                                  for (int i = 0; i < isSelected.length;
                                                  i++) {
                                                    isSelected[i] = i == index;
                                                    if(!isSelected[i]) {
                                                      discountType = 1;
                                                    } else {
                                                      discountType = 0;
                                                    }
                                                  }
                                                  //controller.text = '';
                                                  
                                                  double disc = (controller.value.text != null && controller.value.text.isNotEmpty)
                                                      ? double.parse(controller.value.text.replaceAll('.', '')) : 0;

                                                  // if(discountType == 0) {
                                                  //   disc = ((widget.item.product.price * disc) / 100);
                                                  // }
                                                  // setState(() {
                                                  //   discount = disc;
                                                  // });
                                                  
                                                  widget.onChangeDiscount(discountType, disc);
                                                });

                                              },
                                              isSelected: isSelected,
                                              children: [
                                                Container(
                                                    padding: EdgeInsets.all(0.0),
                                                    margin: EdgeInsets.all(0.0),
                                                    alignment: Alignment.centerLeft,
                                                    child: Padding(
                                                      padding: EdgeInsets.all(0.0),
                                                      child: Text(
                                                        'VND',
                                                        style: TextStyle(fontSize: 10),
                                                      ),
                                                    )),
                                                Container(
                                                    padding: EdgeInsets.all(0.0),
                                                    margin: EdgeInsets.all(0.0),
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                      padding: EdgeInsets.all(0.0),
                                                      child: Text(
                                                        '%',
                                                        style: TextStyle(fontSize: 14),
                                                      ),
                                                    )),
                                              ],
                                            )),
                                          ),
                                          (widget.item.product.mDiscount == 0.0)? Container(
                                                  alignment: Alignment.centerRight,
                                                  width: 115,
                                                  height: 26,
                                                  child: TextField(
                                                      controller: controller,
                                                      keyboardType: TextInputType.number,
                                                      style: TextStyle(fontSize: 13.0, color: Colors.redAccent),
                                                      inputFormatters: [
                                                        FilteringTextInputFormatter.digitsOnly,
                                                      //MaskTextInputFormatter(mask: '###.###', filter: { "#": RegExp(r'[0-9]') })
                                                      ],
                                                      onChanged: (value) {
                                                        //Do something with the user input.
                                                        double disc = (value != null && value.isNotEmpty)? double.parse(value) : 0.0;
                                                        // if(discountType == 0) {
                                                        //   disc = ((widget.item.product.price * disc) / 100);
                                                        // }

                                                        // setState(() {
                                                        //   discount = disc;
                                                        // });
                                                        
                                                        widget.onChangeDiscount(discountType, disc);
                                                      },
                                                      decoration: InputDecoration(
                                                        contentPadding: EdgeInsets.only(left: 6.0),
                                                        border: OutlineInputBorder(
                                                          borderRadius: BorderRadius.all(Radius.circular(0.0)),
                                                        ),
                                                        enabledBorder: OutlineInputBorder(
                                                          borderSide:
                                                          BorderSide(color: Colors.lightBlueAccent, width: 0.0),
                                                          borderRadius: BorderRadius.all(Radius.circular(0.0)),
                                                        ),
                                                        focusedBorder: OutlineInputBorder(
                                                          borderSide:
                                                          BorderSide(color: Colors.lightBlueAccent, width: 0.0),
                                                          borderRadius: BorderRadius.all(Radius.circular(0.0)),
                                                        ),
                                                          hintText: 'Giảm giá',
                                                        hintStyle: TextStyle(fontSize: 10)
                                                      )
                                              )
                                          ) : Container(),
                                        ]),
                                  ) : Container(),

                                ],
                              )
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                                bottom: AppSizes.linePadding * 2),
                          ),
                          Row(children: <Widget>[
                            (widget.onChangeQuantity != null && !widget.orderComplete)
                                ? Flexible(child: Container(
                                  width: 120,
                                  child: Row(
                                    children: <Widget>[
                                  Flexible(child: Padding(
                                      padding: const EdgeInsets.all(0.0),
                                      child: Center(
                                          child: Container(
                                            width: 220.0,
                                            height: 36,
                                            foregroundDecoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(5.0),
                                              border: Border.all(
                                                color: Colors.blueGrey,
                                                width: 1.0,
                                              ),
                                            ),
                                            child: Row(
                                              children: <Widget>[
                                                InkWell(
                                                  onTap: () {
                                                    double currentValue = double.parse(_controller.text);
                                                    currentValue = currentValue > 1 ? currentValue : 1;
                                                    setState(() {
                                                      currentValue--;
                                                      _controller.text =
                                                          (currentValue > 1 ? currentValue : 1)
                                                              .toString(); // decrementing value
                                                    });
                                                    widget.onChangeQuantity(currentValue);
                                                  },
                                                  child: Icon(
                                                    Icons.remove,
                                                    size: 26.0,
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: TextFormField(
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(fontSize: 16, color: Colors.black),
                                                    decoration: InputDecoration(
                                                      contentPadding: EdgeInsets.all(4.0),
                                                      border: OutlineInputBorder(
                                                        borderRadius: BorderRadius.circular(5.0),
                                                      ),
                                                    ),
                                                    controller: _controller,
                                                    keyboardType: TextInputType.number,
                                                    inputFormatters: <TextInputFormatter>[
                                                      FilteringTextInputFormatter.allow((RegExp("[.0-9]")))
                                                    ],
                                                    onChanged: (value) {
                                                      setState(() {
                                                          _controller.text = value; // decrementing value
                                                      });
                                                      if(value != null && value.isNotEmpty) {
                                                        double currentValue = double.parse(value);
                                                        currentValue = currentValue > 0 ? currentValue : 0;
                                                        _controller.selection = TextSelection.fromPosition(TextPosition(offset: _controller.text.length));
                                                        widget.onChangeQuantity(double.parse(_controller.text));
                                                      }
                                                    },
                                                  ),
                                                ),
                                                InkWell(
                                                  onTap: () {
                                                    double currentValue = double.parse(_controller.text);
                                                    currentValue = currentValue > 1 ? currentValue : 1;
                                                    setState(() {
                                                      currentValue++;
                                                      _controller.text =
                                                          (currentValue > 1 ? currentValue : 1)
                                                              .toString(); // decrementing value
                                                    });
                                                    widget.onChangeQuantity(currentValue);
                                                  },
                                                  child: Icon(
                                                    Icons.add,
                                                    size: 26.0,
                                                  ),
                                                ),
                                                /*
                Container(
                  height: 30.0,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              width: 0.3,
                            ),
                          ),
                        ),
                        child: InkWell(
                          onTap: () {
                            int currentValue = int.parse(_controller.text);
                            setState(() {
                              currentValue++;
                              _controller.text = (currentValue)
                                  .toString(); // incrementing value
                            });
                          },
                          child: Icon(
                            Icons.arrow_drop_up,
                            size: 15.0,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          int currentValue = int.parse(_controller.text);
                          setState(() {
                            print('Setting state');
                            currentValue--;
                            _controller.text =
                                (currentValue > 0 ? currentValue : 0)
                                    .toString(); // decrementing value
                          });
                        },
                        child: Icon(
                          Icons.arrow_drop_down,
                          size: 15.0,
                        ),
                      ),
                    ],
                  ),
                ),*/
                                              ],
                                            ),
                                          ))
                                  )),
                                      /*
                                      Flexible(child:
                                      InkWell(
                                        onTap: () => {
                                          widget.onChangeQuantity(
                                            widget.item.productQuantity.quantity-1)
                                        },
                                        child: Container(
                                          alignment: Alignment.center,
                                          width: 32,
                                          height: 32,
                                          decoration: BoxDecoration(
                                            color: AppColors.white,
                                            borderRadius:
                                              BorderRadius.circular(18),
                                            boxShadow: [
                                              BoxShadow(
                                                color: AppColors
                                                  .lightGray
                                                  .withOpacity(
                                                      0.3),
                                                blurRadius: AppSizes
                                                  .imageRadius,
                                                offset: Offset(
                                                  0.0,
                                                  AppSizes
                                                    .imageRadius))
                                            ]),
                                          child: Icon(Icons.remove))),
                                      ),
                                      Flexible(child: Container(
                                        alignment: Alignment.center,
                                        padding: EdgeInsets.all(
                                            AppSizes.linePadding * 2),
                                        child: Text(widget.item.productQuantity.quantity.toString(),
                                            style:
                                                _theme.textTheme.display1),
                                      )),
                                      Flexible(child: InkWell(
                                        onTap: (() => {
                                          widget.onChangeQuantity(
                                            widget.item.productQuantity.quantity+1)
                                        }),
                                        child: Container(
                                          alignment: Alignment.center,
                                          width: 32,
                                          height: 32,
                                          decoration: BoxDecoration(
                                            color: AppColors.white,
                                            borderRadius:
                                              BorderRadius.circular(
                                                18),
                                            boxShadow: [
                                              BoxShadow(
                                                color: AppColors
                                                  .lightGray
                                                  .withOpacity(
                                                    0.3),
                                                blurRadius: AppSizes
                                                  .imageRadius,
                                                offset: Offset(
                                                  0.0,
                                                  AppSizes.imageRadius))
                                            ]),
                                          child: Icon(Icons.add)))),
                                      */
                                      ],
                                    ),
                                  ))
                                : Container(
                                    width: 110,
                                    child: Row(children: <Widget>[
                                      Text('Số lượng: ',
                                          style: _theme.textTheme.headline6.copyWith(fontSize: 12.0, fontWeight: FontWeight.normal)),
                                      Text(widget.item.productQuantity.quantity.toString(),
                                          style: _theme.textTheme.body1
                                              .copyWith(
                                                  color:
                                                      _theme.primaryColor)),
                                    ])),
                            !widget.orderComplete ? Flexible(child: Container(
                              width: width - 275,
                              alignment: Alignment.centerRight,
                              child: InkWell(
                                onTap: (() => {
                                  widget.onRemoveFromCart()
                                }),
                                child: Container(
                                    alignment: Alignment.center,
                                    width: 30,
                                    height: 30,
                                    decoration: BoxDecoration(
                                        color: AppColors.white,
                                        borderRadius:
                                        BorderRadius.circular(
                                            18),
                                        boxShadow: [
                                          BoxShadow(
                                              color: AppColors
                                                  .lightGray
                                                  .withOpacity(
                                                  0.3),
                                              blurRadius: AppSizes
                                                  .imageRadius,
                                              offset: Offset(
                                                  0.0,
                                                  AppSizes.imageRadius))
                                        ]),
                                    child: Icon(Icons.delete, color: Colors.red,))),
                            )) : Container(),
                            /*Container(
                              width: width - 280,
                              alignment: Alignment.centerRight,
                              child: Text(
                                  NumberFormat.currency(locale: AppSettings.locale, symbol: 'đ').format(widget.item.product.price),
                                  //'\$' + (widget.item.price).toStringAsFixed(0),
                                  style: _theme.textTheme.display1),
                            ),*/
                          ])
                        ]))
              ],
            ),
            showPopup
                ? Positioned(
                    top: 10,
                    right: 30,
                    child: Container(
                        height: 45, //90,
                        width: 140,
                        decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(AppSizes.imageRadius),
                            color: AppColors.white,
                            border:
                                Border.all(color: _theme.primaryColorLight)),
                        child: Column(
                          children: <Widget>[
                            /*
                            InkWell(
                                onTap: (() => {
                                      widget
                                          .onAddToFav(),
                                      showPopup = false,
                                      setState(() => {})
                                    }),
                                child: Container(
                                    width: 140,
                                    alignment: Alignment.center,
                                    padding:
                                        EdgeInsets.all(AppSizes.sidePadding),
                                    decoration: BoxDecoration(
                                      border: Border(
                                        bottom: BorderSide(
                                            color: _theme.primaryColorLight,
                                            width: 0.4),
                                      ),
                                    ),
                                    child: Text('Add to Favorites'))),*/
                            InkWell(
                                onTap: (() => {
                                      widget.onRemoveFromCart(),
                                      showPopup = false,
                                      setState(() => {})
                                    }),
                                child: Container(
                                    alignment: Alignment.center,
                                    padding:
                                        EdgeInsets.all(AppSizes.sidePadding),
                                    child: Text('Xóa khỏi giỏ hàng', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),))),
                          ],
                        )))
                : Container()
            ])));
  }
}
