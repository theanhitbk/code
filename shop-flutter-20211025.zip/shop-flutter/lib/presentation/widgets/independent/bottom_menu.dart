// Bottom menu widget for Open Flutter E-commerce App
// Author: openflutterproject@gmail.com
// Date: 2020-02-06

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:hosco/config/app_settings.dart';
import 'package:hosco/config/routes.dart';
import 'package:hosco/config/storage.dart';
import 'package:hosco/config/theme.dart';
import 'package:hosco/data/repositories/cart_repository_impl.dart';
import 'package:hosco/domain/usecases/cart/get_cart_products_use_case.dart';
import 'package:hosco/locator.dart';
import 'package:hosco/presentation/features/cart/cart.dart';
import 'package:hosco/presentation/features/home/home.dart';

class OpenFlutterBottomMenu extends StatelessWidget {
  final int menuIndex;

  OpenFlutterBottomMenu(this.menuIndex);

  String get item_count => null;

  Color colorByIndex(ThemeData theme, int index) {
    return index == menuIndex ? theme.accentColor : theme.primaryColorLight;
  }

  BottomNavigationBarItem getItem(
      String image, String title, ThemeData theme, int index) {

    return BottomNavigationBarItem(
      icon: /*index == 2 ? Stack(
          children: <Widget>[
            Icon(Icons.shopping_cart_outlined, color: colorByIndex(theme, index),),
            /*
            SvgPicture.asset(
              image,
              height: 24.0,
              width: 24.0,
              color: colorByIndex(theme, index),
            ),

             */
            /*
            Positioned(  // draw a red marble
              top: 0.0,
              right: 0.0,
              child: BlocBuilder<CartBloc, CartState>(builder: (context, state) {
                if (state is CartLoadedState) {
                  int total = 0;
                  for(int i = 0; i < state.cartProducts.length; i++) {
                    total += state.cartProducts[i].productQuantity.quantity;
                  }

                  return Container(
                    padding: EdgeInsets.all(1),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    constraints: BoxConstraints(
                      minWidth: 11,
                      minHeight: 11,
                    ),
                    child: Text(
                        '$total',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 8,
                        ),
                        textAlign: TextAlign.center,
                      )
                    );
                  }
                  return Container();
                },
              ),
            )*/
          ]
      ) : */(index == 1 ?
          Icon(Icons.category, color: colorByIndex(theme, index),)
       :
      SvgPicture.asset(
        image,
        height: 24.0,
        width: 24.0,
        color: colorByIndex(theme, index),
      )),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 10.0,
          color: colorByIndex(theme, index),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final _theme = Theme.of(context);

    List<BottomNavigationBarItem> menuItems =[
      getItem('assets/icons/bottom_menu/home.svg', 'Home', _theme, 0),
      getItem('assets/icons/bottom_menu/cart.svg', 'Danh mục', _theme, 1),
      //getItem('assets/icons/bottom_menu/bag.svg', 'Giỏ hàng', _theme, 2),
      // getItem('assets/icons/bottom_menu/favorites.svg', 'Yêu thích', _theme, 3),
    ];
    if ( AppSettings.profileEnabled ) {
      menuItems.add(getItem(
          'assets/icons/bottom_menu/profile.svg', 'Tài khoản', _theme, 2));
    }

      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(15), topLeft: Radius.circular(15)),
          boxShadow: [
            BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15.0),
            topRight: Radius.circular(15.0),
          ),
          child: BlocProvider(
    create: (_) => CartBloc()..add(CartLoadedEvent()),
    child:
          BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: menuIndex,
            onTap: (value) {
              if(value == menuIndex) {
                return;
              }
              switch (value) {
                case 0:
                  Navigator.pushNamed(context, hoscoRoutes.home);
                  break;
                case 1:
                  Navigator.pushNamed(context, hoscoRoutes.shop);
                  break;
                // case 2:
                //   Navigator.pushNamed(context, hoscoRoutes.cart);
                //   break;
              /*case 3:
                Navigator.pushNamed(
                    context, hoscoRoutes.favourites);
                break;*/
                case 2:
                  Navigator.pushNamed(
                      context, hoscoRoutes.profile);
                  break;
              }
            },
            items: menuItems,
          ),
        ),
      ));
  }
}
