import 'package:hosco/data/model/promo.dart';
import 'package:hosco/data/repositories/abstract/promo_repository.dart';

class LocalPromoRepository implements PromoRepository {
  @override
  Future<List<Promo>> getPromoList() {
    // TODO: implement getPromoList
    return null;
  }
  
}
